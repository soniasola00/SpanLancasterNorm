﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.1.4),
    on Wed Aug 14 18:33:17 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.1.4'
expName = 'SenstirEs_warningandinstructions'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = (1024, 768)
_loggingLevel = logging.getLevel('warning')
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # override logging level
    _loggingLevel = logging.getLevel(
        prefs.piloting['pilotLoggingLevel']
    )

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/soniasimon/Documents/thesis/PsychoPy_Eng/SenstirEs_Eng_warningandinstructions_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(_loggingLevel)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=_loggingLevel)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = False
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_resp') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "warning_Eng" ---
    warning_SentirEs = visual.TextStim(win=win, name='warning_SentirEs',
        text='WARNING\n\nThis study uses a wide range of words that are encountered in everyday life. Very occasionally, this means that some words may be offensive or explicit. If you feel that being exposed to such words will be distressing for you, we would like to remind you that you are free to end your participation in the study now or at any time you choose.\n\nIf you wish to continue, please press the "NEXT" button',
        font='Arial bold',
        units='norm', pos=(0,0), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next_warning = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next_warning',
        depth=-1
    )
    next_warning.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_intructions_Eng" ---
    intructions = visual.TextStim(win=win, name='intructions',
        text='INSTRUCTIONS\n\nYou will be asked to rate how much you experience everyday concepts using six different perceptual senses. There are no right or wrong answers so please use your own judgement. The rating scale runs from 0 (not experienced at all with that sense) to 5 (experienced greatly with that sense). Click on a number to select a rating for each scale, then click on the Next button to move on the next item.\n\nIf you do not know the meaning of a word, just check the “Don’t know the meaning of this word" box and click "NEXT" to move onto the next item.',
        font='Arial',
        units='norm', pos=(0, 0), height=0.075, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next_instructions = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next_instructions',
        depth=-1
    )
    next_instructions.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_Eng" ---
    text = visual.TextStim(win=win, name='text',
        text='To what extent do you experience ',
        font='Arial',
        units='norm', pos=(-0.65,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.60,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='by hearing',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='by tasting',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='by feeling through touch',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='by smelling',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='by seeing',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next',
        depth=-14
    )
    next.buttonClock = core.Clock()
    Dont_know = visual.ButtonStim(win, 
        text="Don't know this word", font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Dont_know',
        depth=-15
    )
    Dont_know.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Eng_1" ---
    catch_1 = visual.TextStim(win=win, name='catch_1',
        text='Which one of these animals flies?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    bear = visual.ButtonStim(win, 
        text='Bear', font='Arvo',
        pos=(-0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='bear',
        depth=-1
    )
    bear.buttonClock = core.Clock()
    bird = visual.ButtonStim(win, 
        text='Bird', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='bird',
        depth=-2
    )
    bird.buttonClock = core.Clock()
    fish = visual.ButtonStim(win, 
        text='Fish', font='Arvo',
        pos=(0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='fish',
        depth=-3
    )
    fish.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_Eng" ---
    text = visual.TextStim(win=win, name='text',
        text='To what extent do you experience ',
        font='Arial',
        units='norm', pos=(-0.65,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.60,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='by hearing',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='by tasting',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='by feeling through touch',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='by smelling',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='by seeing',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next',
        depth=-14
    )
    next.buttonClock = core.Clock()
    Dont_know = visual.ButtonStim(win, 
        text="Don't know this word", font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Dont_know',
        depth=-15
    )
    Dont_know.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Eng_2" ---
    catch_2 = visual.TextStim(win=win, name='catch_2',
        text='What is 5 x 3?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    fifteen = visual.ButtonStim(win, 
        text='15', font='Arvo',
        pos=(-0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='fifteen',
        depth=-1
    )
    fifteen.buttonClock = core.Clock()
    one_hundred = visual.ButtonStim(win, 
        text='100', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='one_hundred',
        depth=-2
    )
    one_hundred.buttonClock = core.Clock()
    seventy_two = visual.ButtonStim(win, 
        text='72 ', font='Arvo',
        pos=(0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='seventy_two',
        depth=-3
    )
    seventy_two.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_Eng" ---
    text = visual.TextStim(win=win, name='text',
        text='To what extent do you experience ',
        font='Arial',
        units='norm', pos=(-0.65,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.60,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='by hearing',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='by tasting',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='by feeling through touch',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='by smelling',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='by seeing',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next',
        depth=-14
    )
    next.buttonClock = core.Clock()
    Dont_know = visual.ButtonStim(win, 
        text="Don't know this word", font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Dont_know',
        depth=-15
    )
    Dont_know.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Eng_3" ---
    catch_3 = visual.TextStim(win=win, name='catch_3',
        text='Which of these is a fruit?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    sandwitch = visual.ButtonStim(win, 
        text='sandwitch', font='Arvo',
        pos=(-0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='sandwitch',
        depth=-1
    )
    sandwitch.buttonClock = core.Clock()
    apple = visual.ButtonStim(win, 
        text='apple', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='apple',
        depth=-2
    )
    apple.buttonClock = core.Clock()
    cauliflower = visual.ButtonStim(win, 
        text='cauliflower', font='Arvo',
        pos=(0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='cauliflower',
        depth=-3
    )
    cauliflower.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_Eng" ---
    text = visual.TextStim(win=win, name='text',
        text='To what extent do you experience ',
        font='Arial',
        units='norm', pos=(-0.65,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.60,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='by hearing',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='by tasting',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='by feeling through touch',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='by smelling',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='by seeing',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next = visual.ButtonStim(win, 
        text='NEXT', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next',
        depth=-14
    )
    next.buttonClock = core.Clock()
    Dont_know = visual.ButtonStim(win, 
        text="Don't know this word", font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Dont_know',
        depth=-15
    )
    Dont_know.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "end" ---
    readingtext = visual.TextStim(win=win, name='readingtext',
        text="THANK YOU FOR PARTICIPANTING!\n\nPress 'y' in your keyboard to end.",
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    key_resp = keyboard.Keyboard(deviceName='key_resp')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "warning_Eng" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('warning_Eng.started', globalClock.getTime(format='float'))
    # reset next_warning to account for continued clicks & clear times on/off
    next_warning.reset()
    # keep track of which components have finished
    warning_EngComponents = [warning_SentirEs, next_warning]
    for thisComponent in warning_EngComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "warning_Eng" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *warning_SentirEs* updates
        
        # if warning_SentirEs is starting this frame...
        if warning_SentirEs.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            warning_SentirEs.frameNStart = frameN  # exact frame index
            warning_SentirEs.tStart = t  # local t and not account for scr refresh
            warning_SentirEs.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(warning_SentirEs, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'warning_SentirEs.started')
            # update status
            warning_SentirEs.status = STARTED
            warning_SentirEs.setAutoDraw(True)
        
        # if warning_SentirEs is active this frame...
        if warning_SentirEs.status == STARTED:
            # update params
            pass
        # *next_warning* updates
        
        # if next_warning is starting this frame...
        if next_warning.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next_warning.frameNStart = frameN  # exact frame index
            next_warning.tStart = t  # local t and not account for scr refresh
            next_warning.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next_warning, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next_warning.started')
            # update status
            next_warning.status = STARTED
            next_warning.setAutoDraw(True)
        
        # if next_warning is active this frame...
        if next_warning.status == STARTED:
            # update params
            pass
            # check whether next_warning has been pressed
            if next_warning.isClicked:
                if not next_warning.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next_warning.timesOn.append(next_warning.buttonClock.getTime())
                    next_warning.timesOff.append(next_warning.buttonClock.getTime())
                elif len(next_warning.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next_warning.timesOff[-1] = next_warning.buttonClock.getTime()
                if not next_warning.wasClicked:
                    # end routine when next_warning is clicked
                    continueRoutine = False
                if not next_warning.wasClicked:
                    # run callback code when next_warning is clicked
                    Vision.rating
        # take note of whether next_warning was clicked, so that next frame we know if clicks are new
        next_warning.wasClicked = next_warning.isClicked and next_warning.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warning_EngComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "warning_Eng" ---
    for thisComponent in warning_EngComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('warning_Eng.stopped', globalClock.getTime(format='float'))
    thisExp.addData('next_warning.numClicks', next_warning.numClicks)
    if next_warning.numClicks:
       thisExp.addData('next_warning.timesOn', next_warning.timesOn)
       thisExp.addData('next_warning.timesOff', next_warning.timesOff)
    else:
       thisExp.addData('next_warning.timesOn', "")
       thisExp.addData('next_warning.timesOff', "")
    thisExp.nextEntry()
    # the Routine "warning_Eng" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "SentirEs_intructions_Eng" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SentirEs_intructions_Eng.started', globalClock.getTime(format='float'))
    # reset next_instructions to account for continued clicks & clear times on/off
    next_instructions.reset()
    # keep track of which components have finished
    SentirEs_intructions_EngComponents = [intructions, next_instructions]
    for thisComponent in SentirEs_intructions_EngComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SentirEs_intructions_Eng" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *intructions* updates
        
        # if intructions is starting this frame...
        if intructions.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            intructions.frameNStart = frameN  # exact frame index
            intructions.tStart = t  # local t and not account for scr refresh
            intructions.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(intructions, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'intructions.started')
            # update status
            intructions.status = STARTED
            intructions.setAutoDraw(True)
        
        # if intructions is active this frame...
        if intructions.status == STARTED:
            # update params
            pass
        # *next_instructions* updates
        
        # if next_instructions is starting this frame...
        if next_instructions.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next_instructions.frameNStart = frameN  # exact frame index
            next_instructions.tStart = t  # local t and not account for scr refresh
            next_instructions.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next_instructions, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next_instructions.started')
            # update status
            next_instructions.status = STARTED
            next_instructions.setAutoDraw(True)
        
        # if next_instructions is active this frame...
        if next_instructions.status == STARTED:
            # update params
            pass
            # check whether next_instructions has been pressed
            if next_instructions.isClicked:
                if not next_instructions.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next_instructions.timesOn.append(next_instructions.buttonClock.getTime())
                    next_instructions.timesOff.append(next_instructions.buttonClock.getTime())
                elif len(next_instructions.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next_instructions.timesOff[-1] = next_instructions.buttonClock.getTime()
                if not next_instructions.wasClicked:
                    # end routine when next_instructions is clicked
                    continueRoutine = False
                if not next_instructions.wasClicked:
                    # run callback code when next_instructions is clicked
                    Vision.rating
        # take note of whether next_instructions was clicked, so that next frame we know if clicks are new
        next_instructions.wasClicked = next_instructions.isClicked and next_instructions.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SentirEs_intructions_EngComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SentirEs_intructions_Eng" ---
    for thisComponent in SentirEs_intructions_EngComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SentirEs_intructions_Eng.stopped', globalClock.getTime(format='float'))
    thisExp.addData('next_instructions.numClicks', next_instructions.numClicks)
    if next_instructions.numClicks:
       thisExp.addData('next_instructions.timesOn', next_instructions.timesOn)
       thisExp.addData('next_instructions.timesOff', next_instructions.timesOff)
    else:
       thisExp.addData('next_instructions.timesOn', "")
       thisExp.addData('next_instructions.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SentirEs_intructions_Eng" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_19 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('stim_Eng/Stimuli_selection_Engl_19 - Sheet1.csv'),
        seed=None, name='SentirEs_19')
    thisExp.addLoop(SentirEs_19)  # add the loop to the experiment
    thisSentirE_19 = SentirEs_19.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_19.rgb)
    if thisSentirE_19 != None:
        for paramName in thisSentirE_19:
            globals()[paramName] = thisSentirE_19[paramName]
    
    for thisSentirE_19 in SentirEs_19:
        currentLoop = SentirEs_19
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_19.rgb)
        if thisSentirE_19 != None:
            for paramName in thisSentirE_19:
                globals()[paramName] = thisSentirE_19[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_Eng" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_Eng.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset next to account for continued clicks & clear times on/off
        next.reset()
        # reset Dont_know to account for continued clicks & clear times on/off
        Dont_know.reset()
        # keep track of which components have finished
        SentirEs_likert_EngComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, next, Dont_know]
        for thisComponent in SentirEs_likert_EngComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_Eng" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *next* updates
            
            # if next is starting this frame...
            if next.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next.frameNStart = frameN  # exact frame index
                next.tStart = t  # local t and not account for scr refresh
                next.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next.started')
                # update status
                next.status = STARTED
                next.setAutoDraw(True)
            
            # if next is active this frame...
            if next.status == STARTED:
                # update params
                pass
                # check whether next has been pressed
                if next.isClicked:
                    if not next.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next.timesOn.append(next.buttonClock.getTime())
                        next.timesOff.append(next.buttonClock.getTime())
                    elif len(next.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next.timesOff[-1] = next.buttonClock.getTime()
                    if not next.wasClicked:
                        # end routine when next is clicked
                        continueRoutine = False
                    if not next.wasClicked:
                        # run callback code when next is clicked
                        Vision.rating
            # take note of whether next was clicked, so that next frame we know if clicks are new
            next.wasClicked = next.isClicked and next.status == STARTED
            # *Dont_know* updates
            
            # if Dont_know is starting this frame...
            if Dont_know.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Dont_know.frameNStart = frameN  # exact frame index
                Dont_know.tStart = t  # local t and not account for scr refresh
                Dont_know.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Dont_know, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Dont_know.started')
                # update status
                Dont_know.status = STARTED
                Dont_know.setAutoDraw(True)
            
            # if Dont_know is active this frame...
            if Dont_know.status == STARTED:
                # update params
                pass
                # check whether Dont_know has been pressed
                if Dont_know.isClicked:
                    if not Dont_know.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Dont_know.timesOn.append(Dont_know.buttonClock.getTime())
                        Dont_know.timesOff.append(Dont_know.buttonClock.getTime())
                    elif len(Dont_know.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Dont_know.timesOff[-1] = Dont_know.buttonClock.getTime()
                    if not Dont_know.wasClicked:
                        # end routine when Dont_know is clicked
                        continueRoutine = False
                    if not Dont_know.wasClicked:
                        # run callback code when Dont_know is clicked
                        Vision.rating
            # take note of whether Dont_know was clicked, so that next frame we know if clicks are new
            Dont_know.wasClicked = Dont_know.isClicked and Dont_know.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_EngComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_Eng" ---
        for thisComponent in SentirEs_likert_EngComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_Eng.stopped', globalClock.getTime(format='float'))
        SentirEs_19.addData('Audition.response', Audition.getRating())
        SentirEs_19.addData('Audition.rt', Audition.getRT())
        SentirEs_19.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_19.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_19.addData('Haptic.response', Haptic.getRating())
        SentirEs_19.addData('Haptic.rt', Haptic.getRT())
        SentirEs_19.addData('Interoception.response', Interoception.getRating())
        SentirEs_19.addData('Interoception.rt', Interoception.getRT())
        SentirEs_19.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_19.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_19.addData('Vision.response', Vision.getRating())
        SentirEs_19.addData('Vision.rt', Vision.getRT())
        SentirEs_19.addData('next.numClicks', next.numClicks)
        if next.numClicks:
           SentirEs_19.addData('next.timesOn', next.timesOn)
           SentirEs_19.addData('next.timesOff', next.timesOff)
        else:
           SentirEs_19.addData('next.timesOn', "")
           SentirEs_19.addData('next.timesOff', "")
        SentirEs_19.addData('Dont_know.numClicks', Dont_know.numClicks)
        if Dont_know.numClicks:
           SentirEs_19.addData('Dont_know.timesOn', Dont_know.timesOn)
           SentirEs_19.addData('Dont_know.timesOff', Dont_know.timesOff)
        else:
           SentirEs_19.addData('Dont_know.timesOn', "")
           SentirEs_19.addData('Dont_know.timesOff', "")
        # the Routine "SentirEs_likert_Eng" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_19'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Eng_1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Eng_1.started', globalClock.getTime(format='float'))
    # reset bear to account for continued clicks & clear times on/off
    bear.reset()
    # reset bird to account for continued clicks & clear times on/off
    bird.reset()
    # reset fish to account for continued clicks & clear times on/off
    fish.reset()
    # keep track of which components have finished
    SenstirEs_catch_Eng_1Components = [catch_1, bear, bird, fish]
    for thisComponent in SenstirEs_catch_Eng_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Eng_1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_1* updates
        
        # if catch_1 is starting this frame...
        if catch_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_1.frameNStart = frameN  # exact frame index
            catch_1.tStart = t  # local t and not account for scr refresh
            catch_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_1.started')
            # update status
            catch_1.status = STARTED
            catch_1.setAutoDraw(True)
        
        # if catch_1 is active this frame...
        if catch_1.status == STARTED:
            # update params
            pass
        # *bear* updates
        
        # if bear is starting this frame...
        if bear.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            bear.frameNStart = frameN  # exact frame index
            bear.tStart = t  # local t and not account for scr refresh
            bear.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(bear, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'bear.started')
            # update status
            bear.status = STARTED
            bear.setAutoDraw(True)
        
        # if bear is active this frame...
        if bear.status == STARTED:
            # update params
            pass
            # check whether bear has been pressed
            if bear.isClicked:
                if not bear.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    bear.timesOn.append(bear.buttonClock.getTime())
                    bear.timesOff.append(bear.buttonClock.getTime())
                elif len(bear.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    bear.timesOff[-1] = bear.buttonClock.getTime()
                if not bear.wasClicked:
                    # end routine when bear is clicked
                    continueRoutine = False
                if not bear.wasClicked:
                    # run callback code when bear is clicked
                    pass
        # take note of whether bear was clicked, so that next frame we know if clicks are new
        bear.wasClicked = bear.isClicked and bear.status == STARTED
        # *bird* updates
        
        # if bird is starting this frame...
        if bird.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            bird.frameNStart = frameN  # exact frame index
            bird.tStart = t  # local t and not account for scr refresh
            bird.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(bird, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'bird.started')
            # update status
            bird.status = STARTED
            bird.setAutoDraw(True)
        
        # if bird is active this frame...
        if bird.status == STARTED:
            # update params
            pass
            # check whether bird has been pressed
            if bird.isClicked:
                if not bird.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    bird.timesOn.append(bird.buttonClock.getTime())
                    bird.timesOff.append(bird.buttonClock.getTime())
                elif len(bird.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    bird.timesOff[-1] = bird.buttonClock.getTime()
                if not bird.wasClicked:
                    # end routine when bird is clicked
                    continueRoutine = False
                if not bird.wasClicked:
                    # run callback code when bird is clicked
                    pass
        # take note of whether bird was clicked, so that next frame we know if clicks are new
        bird.wasClicked = bird.isClicked and bird.status == STARTED
        # *fish* updates
        
        # if fish is starting this frame...
        if fish.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            fish.frameNStart = frameN  # exact frame index
            fish.tStart = t  # local t and not account for scr refresh
            fish.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fish, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fish.started')
            # update status
            fish.status = STARTED
            fish.setAutoDraw(True)
        
        # if fish is active this frame...
        if fish.status == STARTED:
            # update params
            pass
            # check whether fish has been pressed
            if fish.isClicked:
                if not fish.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    fish.timesOn.append(fish.buttonClock.getTime())
                    fish.timesOff.append(fish.buttonClock.getTime())
                elif len(fish.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    fish.timesOff[-1] = fish.buttonClock.getTime()
                if not fish.wasClicked:
                    # end routine when fish is clicked
                    continueRoutine = False
                if not fish.wasClicked:
                    # run callback code when fish is clicked
                    pass
        # take note of whether fish was clicked, so that next frame we know if clicks are new
        fish.wasClicked = fish.isClicked and fish.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Eng_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Eng_1" ---
    for thisComponent in SenstirEs_catch_Eng_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Eng_1.stopped', globalClock.getTime(format='float'))
    thisExp.addData('bear.numClicks', bear.numClicks)
    if bear.numClicks:
       thisExp.addData('bear.timesOn', bear.timesOn)
       thisExp.addData('bear.timesOff', bear.timesOff)
    else:
       thisExp.addData('bear.timesOn', "")
       thisExp.addData('bear.timesOff', "")
    thisExp.addData('bird.numClicks', bird.numClicks)
    if bird.numClicks:
       thisExp.addData('bird.timesOn', bird.timesOn)
       thisExp.addData('bird.timesOff', bird.timesOff)
    else:
       thisExp.addData('bird.timesOn', "")
       thisExp.addData('bird.timesOff', "")
    thisExp.addData('fish.numClicks', fish.numClicks)
    if fish.numClicks:
       thisExp.addData('fish.timesOn', fish.timesOn)
       thisExp.addData('fish.timesOff', fish.timesOff)
    else:
       thisExp.addData('fish.timesOn', "")
       thisExp.addData('fish.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Eng_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_45 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('stim_Eng/Stimuli_selection_Engl_45 - Sheet1.csv'),
        seed=None, name='SentirEs_45')
    thisExp.addLoop(SentirEs_45)  # add the loop to the experiment
    thisSentirE_45 = SentirEs_45.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_45.rgb)
    if thisSentirE_45 != None:
        for paramName in thisSentirE_45:
            globals()[paramName] = thisSentirE_45[paramName]
    
    for thisSentirE_45 in SentirEs_45:
        currentLoop = SentirEs_45
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_45.rgb)
        if thisSentirE_45 != None:
            for paramName in thisSentirE_45:
                globals()[paramName] = thisSentirE_45[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_Eng" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_Eng.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset next to account for continued clicks & clear times on/off
        next.reset()
        # reset Dont_know to account for continued clicks & clear times on/off
        Dont_know.reset()
        # keep track of which components have finished
        SentirEs_likert_EngComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, next, Dont_know]
        for thisComponent in SentirEs_likert_EngComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_Eng" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *next* updates
            
            # if next is starting this frame...
            if next.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next.frameNStart = frameN  # exact frame index
                next.tStart = t  # local t and not account for scr refresh
                next.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next.started')
                # update status
                next.status = STARTED
                next.setAutoDraw(True)
            
            # if next is active this frame...
            if next.status == STARTED:
                # update params
                pass
                # check whether next has been pressed
                if next.isClicked:
                    if not next.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next.timesOn.append(next.buttonClock.getTime())
                        next.timesOff.append(next.buttonClock.getTime())
                    elif len(next.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next.timesOff[-1] = next.buttonClock.getTime()
                    if not next.wasClicked:
                        # end routine when next is clicked
                        continueRoutine = False
                    if not next.wasClicked:
                        # run callback code when next is clicked
                        Vision.rating
            # take note of whether next was clicked, so that next frame we know if clicks are new
            next.wasClicked = next.isClicked and next.status == STARTED
            # *Dont_know* updates
            
            # if Dont_know is starting this frame...
            if Dont_know.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Dont_know.frameNStart = frameN  # exact frame index
                Dont_know.tStart = t  # local t and not account for scr refresh
                Dont_know.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Dont_know, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Dont_know.started')
                # update status
                Dont_know.status = STARTED
                Dont_know.setAutoDraw(True)
            
            # if Dont_know is active this frame...
            if Dont_know.status == STARTED:
                # update params
                pass
                # check whether Dont_know has been pressed
                if Dont_know.isClicked:
                    if not Dont_know.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Dont_know.timesOn.append(Dont_know.buttonClock.getTime())
                        Dont_know.timesOff.append(Dont_know.buttonClock.getTime())
                    elif len(Dont_know.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Dont_know.timesOff[-1] = Dont_know.buttonClock.getTime()
                    if not Dont_know.wasClicked:
                        # end routine when Dont_know is clicked
                        continueRoutine = False
                    if not Dont_know.wasClicked:
                        # run callback code when Dont_know is clicked
                        Vision.rating
            # take note of whether Dont_know was clicked, so that next frame we know if clicks are new
            Dont_know.wasClicked = Dont_know.isClicked and Dont_know.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_EngComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_Eng" ---
        for thisComponent in SentirEs_likert_EngComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_Eng.stopped', globalClock.getTime(format='float'))
        SentirEs_45.addData('Audition.response', Audition.getRating())
        SentirEs_45.addData('Audition.rt', Audition.getRT())
        SentirEs_45.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_45.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_45.addData('Haptic.response', Haptic.getRating())
        SentirEs_45.addData('Haptic.rt', Haptic.getRT())
        SentirEs_45.addData('Interoception.response', Interoception.getRating())
        SentirEs_45.addData('Interoception.rt', Interoception.getRT())
        SentirEs_45.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_45.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_45.addData('Vision.response', Vision.getRating())
        SentirEs_45.addData('Vision.rt', Vision.getRT())
        SentirEs_45.addData('next.numClicks', next.numClicks)
        if next.numClicks:
           SentirEs_45.addData('next.timesOn', next.timesOn)
           SentirEs_45.addData('next.timesOff', next.timesOff)
        else:
           SentirEs_45.addData('next.timesOn', "")
           SentirEs_45.addData('next.timesOff', "")
        SentirEs_45.addData('Dont_know.numClicks', Dont_know.numClicks)
        if Dont_know.numClicks:
           SentirEs_45.addData('Dont_know.timesOn', Dont_know.timesOn)
           SentirEs_45.addData('Dont_know.timesOff', Dont_know.timesOff)
        else:
           SentirEs_45.addData('Dont_know.timesOn', "")
           SentirEs_45.addData('Dont_know.timesOff', "")
        # the Routine "SentirEs_likert_Eng" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_45'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Eng_2" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Eng_2.started', globalClock.getTime(format='float'))
    # reset fifteen to account for continued clicks & clear times on/off
    fifteen.reset()
    # reset one_hundred to account for continued clicks & clear times on/off
    one_hundred.reset()
    # reset seventy_two to account for continued clicks & clear times on/off
    seventy_two.reset()
    # keep track of which components have finished
    SenstirEs_catch_Eng_2Components = [catch_2, fifteen, one_hundred, seventy_two]
    for thisComponent in SenstirEs_catch_Eng_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Eng_2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_2* updates
        
        # if catch_2 is starting this frame...
        if catch_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_2.frameNStart = frameN  # exact frame index
            catch_2.tStart = t  # local t and not account for scr refresh
            catch_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_2.started')
            # update status
            catch_2.status = STARTED
            catch_2.setAutoDraw(True)
        
        # if catch_2 is active this frame...
        if catch_2.status == STARTED:
            # update params
            pass
        # *fifteen* updates
        
        # if fifteen is starting this frame...
        if fifteen.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            fifteen.frameNStart = frameN  # exact frame index
            fifteen.tStart = t  # local t and not account for scr refresh
            fifteen.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fifteen, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fifteen.started')
            # update status
            fifteen.status = STARTED
            fifteen.setAutoDraw(True)
        
        # if fifteen is active this frame...
        if fifteen.status == STARTED:
            # update params
            pass
            # check whether fifteen has been pressed
            if fifteen.isClicked:
                if not fifteen.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    fifteen.timesOn.append(fifteen.buttonClock.getTime())
                    fifteen.timesOff.append(fifteen.buttonClock.getTime())
                elif len(fifteen.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    fifteen.timesOff[-1] = fifteen.buttonClock.getTime()
                if not fifteen.wasClicked:
                    # end routine when fifteen is clicked
                    continueRoutine = False
                if not fifteen.wasClicked:
                    # run callback code when fifteen is clicked
                    pass
        # take note of whether fifteen was clicked, so that next frame we know if clicks are new
        fifteen.wasClicked = fifteen.isClicked and fifteen.status == STARTED
        # *one_hundred* updates
        
        # if one_hundred is starting this frame...
        if one_hundred.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            one_hundred.frameNStart = frameN  # exact frame index
            one_hundred.tStart = t  # local t and not account for scr refresh
            one_hundred.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(one_hundred, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'one_hundred.started')
            # update status
            one_hundred.status = STARTED
            one_hundred.setAutoDraw(True)
        
        # if one_hundred is active this frame...
        if one_hundred.status == STARTED:
            # update params
            pass
            # check whether one_hundred has been pressed
            if one_hundred.isClicked:
                if not one_hundred.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    one_hundred.timesOn.append(one_hundred.buttonClock.getTime())
                    one_hundred.timesOff.append(one_hundred.buttonClock.getTime())
                elif len(one_hundred.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    one_hundred.timesOff[-1] = one_hundred.buttonClock.getTime()
                if not one_hundred.wasClicked:
                    # end routine when one_hundred is clicked
                    continueRoutine = False
                if not one_hundred.wasClicked:
                    # run callback code when one_hundred is clicked
                    pass
        # take note of whether one_hundred was clicked, so that next frame we know if clicks are new
        one_hundred.wasClicked = one_hundred.isClicked and one_hundred.status == STARTED
        # *seventy_two* updates
        
        # if seventy_two is starting this frame...
        if seventy_two.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            seventy_two.frameNStart = frameN  # exact frame index
            seventy_two.tStart = t  # local t and not account for scr refresh
            seventy_two.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(seventy_two, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'seventy_two.started')
            # update status
            seventy_two.status = STARTED
            seventy_two.setAutoDraw(True)
        
        # if seventy_two is active this frame...
        if seventy_two.status == STARTED:
            # update params
            pass
            # check whether seventy_two has been pressed
            if seventy_two.isClicked:
                if not seventy_two.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    seventy_two.timesOn.append(seventy_two.buttonClock.getTime())
                    seventy_two.timesOff.append(seventy_two.buttonClock.getTime())
                elif len(seventy_two.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    seventy_two.timesOff[-1] = seventy_two.buttonClock.getTime()
                if not seventy_two.wasClicked:
                    # end routine when seventy_two is clicked
                    continueRoutine = False
                if not seventy_two.wasClicked:
                    # run callback code when seventy_two is clicked
                    pass
        # take note of whether seventy_two was clicked, so that next frame we know if clicks are new
        seventy_two.wasClicked = seventy_two.isClicked and seventy_two.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Eng_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Eng_2" ---
    for thisComponent in SenstirEs_catch_Eng_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Eng_2.stopped', globalClock.getTime(format='float'))
    thisExp.addData('fifteen.numClicks', fifteen.numClicks)
    if fifteen.numClicks:
       thisExp.addData('fifteen.timesOn', fifteen.timesOn)
       thisExp.addData('fifteen.timesOff', fifteen.timesOff)
    else:
       thisExp.addData('fifteen.timesOn', "")
       thisExp.addData('fifteen.timesOff', "")
    thisExp.addData('one_hundred.numClicks', one_hundred.numClicks)
    if one_hundred.numClicks:
       thisExp.addData('one_hundred.timesOn', one_hundred.timesOn)
       thisExp.addData('one_hundred.timesOff', one_hundred.timesOff)
    else:
       thisExp.addData('one_hundred.timesOn', "")
       thisExp.addData('one_hundred.timesOff', "")
    thisExp.addData('seventy_two.numClicks', seventy_two.numClicks)
    if seventy_two.numClicks:
       thisExp.addData('seventy_two.timesOn', seventy_two.timesOn)
       thisExp.addData('seventy_two.timesOff', seventy_two.timesOff)
    else:
       thisExp.addData('seventy_two.timesOn', "")
       thisExp.addData('seventy_two.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Eng_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_78 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('stim_Eng/Stimuli_selection_Engl_78 - Sheet1.csv'),
        seed=None, name='SentirEs_78')
    thisExp.addLoop(SentirEs_78)  # add the loop to the experiment
    thisSentirE_78 = SentirEs_78.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_78.rgb)
    if thisSentirE_78 != None:
        for paramName in thisSentirE_78:
            globals()[paramName] = thisSentirE_78[paramName]
    
    for thisSentirE_78 in SentirEs_78:
        currentLoop = SentirEs_78
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_78.rgb)
        if thisSentirE_78 != None:
            for paramName in thisSentirE_78:
                globals()[paramName] = thisSentirE_78[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_Eng" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_Eng.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset next to account for continued clicks & clear times on/off
        next.reset()
        # reset Dont_know to account for continued clicks & clear times on/off
        Dont_know.reset()
        # keep track of which components have finished
        SentirEs_likert_EngComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, next, Dont_know]
        for thisComponent in SentirEs_likert_EngComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_Eng" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *next* updates
            
            # if next is starting this frame...
            if next.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next.frameNStart = frameN  # exact frame index
                next.tStart = t  # local t and not account for scr refresh
                next.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next.started')
                # update status
                next.status = STARTED
                next.setAutoDraw(True)
            
            # if next is active this frame...
            if next.status == STARTED:
                # update params
                pass
                # check whether next has been pressed
                if next.isClicked:
                    if not next.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next.timesOn.append(next.buttonClock.getTime())
                        next.timesOff.append(next.buttonClock.getTime())
                    elif len(next.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next.timesOff[-1] = next.buttonClock.getTime()
                    if not next.wasClicked:
                        # end routine when next is clicked
                        continueRoutine = False
                    if not next.wasClicked:
                        # run callback code when next is clicked
                        Vision.rating
            # take note of whether next was clicked, so that next frame we know if clicks are new
            next.wasClicked = next.isClicked and next.status == STARTED
            # *Dont_know* updates
            
            # if Dont_know is starting this frame...
            if Dont_know.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Dont_know.frameNStart = frameN  # exact frame index
                Dont_know.tStart = t  # local t and not account for scr refresh
                Dont_know.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Dont_know, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Dont_know.started')
                # update status
                Dont_know.status = STARTED
                Dont_know.setAutoDraw(True)
            
            # if Dont_know is active this frame...
            if Dont_know.status == STARTED:
                # update params
                pass
                # check whether Dont_know has been pressed
                if Dont_know.isClicked:
                    if not Dont_know.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Dont_know.timesOn.append(Dont_know.buttonClock.getTime())
                        Dont_know.timesOff.append(Dont_know.buttonClock.getTime())
                    elif len(Dont_know.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Dont_know.timesOff[-1] = Dont_know.buttonClock.getTime()
                    if not Dont_know.wasClicked:
                        # end routine when Dont_know is clicked
                        continueRoutine = False
                    if not Dont_know.wasClicked:
                        # run callback code when Dont_know is clicked
                        Vision.rating
            # take note of whether Dont_know was clicked, so that next frame we know if clicks are new
            Dont_know.wasClicked = Dont_know.isClicked and Dont_know.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_EngComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_Eng" ---
        for thisComponent in SentirEs_likert_EngComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_Eng.stopped', globalClock.getTime(format='float'))
        SentirEs_78.addData('Audition.response', Audition.getRating())
        SentirEs_78.addData('Audition.rt', Audition.getRT())
        SentirEs_78.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_78.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_78.addData('Haptic.response', Haptic.getRating())
        SentirEs_78.addData('Haptic.rt', Haptic.getRT())
        SentirEs_78.addData('Interoception.response', Interoception.getRating())
        SentirEs_78.addData('Interoception.rt', Interoception.getRT())
        SentirEs_78.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_78.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_78.addData('Vision.response', Vision.getRating())
        SentirEs_78.addData('Vision.rt', Vision.getRT())
        SentirEs_78.addData('next.numClicks', next.numClicks)
        if next.numClicks:
           SentirEs_78.addData('next.timesOn', next.timesOn)
           SentirEs_78.addData('next.timesOff', next.timesOff)
        else:
           SentirEs_78.addData('next.timesOn', "")
           SentirEs_78.addData('next.timesOff', "")
        SentirEs_78.addData('Dont_know.numClicks', Dont_know.numClicks)
        if Dont_know.numClicks:
           SentirEs_78.addData('Dont_know.timesOn', Dont_know.timesOn)
           SentirEs_78.addData('Dont_know.timesOff', Dont_know.timesOff)
        else:
           SentirEs_78.addData('Dont_know.timesOn', "")
           SentirEs_78.addData('Dont_know.timesOff', "")
        # the Routine "SentirEs_likert_Eng" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_78'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Eng_3" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Eng_3.started', globalClock.getTime(format='float'))
    # reset sandwitch to account for continued clicks & clear times on/off
    sandwitch.reset()
    # reset apple to account for continued clicks & clear times on/off
    apple.reset()
    # reset cauliflower to account for continued clicks & clear times on/off
    cauliflower.reset()
    # keep track of which components have finished
    SenstirEs_catch_Eng_3Components = [catch_3, sandwitch, apple, cauliflower]
    for thisComponent in SenstirEs_catch_Eng_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Eng_3" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_3* updates
        
        # if catch_3 is starting this frame...
        if catch_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_3.frameNStart = frameN  # exact frame index
            catch_3.tStart = t  # local t and not account for scr refresh
            catch_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_3.started')
            # update status
            catch_3.status = STARTED
            catch_3.setAutoDraw(True)
        
        # if catch_3 is active this frame...
        if catch_3.status == STARTED:
            # update params
            pass
        # *sandwitch* updates
        
        # if sandwitch is starting this frame...
        if sandwitch.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            sandwitch.frameNStart = frameN  # exact frame index
            sandwitch.tStart = t  # local t and not account for scr refresh
            sandwitch.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sandwitch, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'sandwitch.started')
            # update status
            sandwitch.status = STARTED
            sandwitch.setAutoDraw(True)
        
        # if sandwitch is active this frame...
        if sandwitch.status == STARTED:
            # update params
            pass
            # check whether sandwitch has been pressed
            if sandwitch.isClicked:
                if not sandwitch.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    sandwitch.timesOn.append(sandwitch.buttonClock.getTime())
                    sandwitch.timesOff.append(sandwitch.buttonClock.getTime())
                elif len(sandwitch.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    sandwitch.timesOff[-1] = sandwitch.buttonClock.getTime()
                if not sandwitch.wasClicked:
                    # end routine when sandwitch is clicked
                    continueRoutine = False
                if not sandwitch.wasClicked:
                    # run callback code when sandwitch is clicked
                    pass
        # take note of whether sandwitch was clicked, so that next frame we know if clicks are new
        sandwitch.wasClicked = sandwitch.isClicked and sandwitch.status == STARTED
        # *apple* updates
        
        # if apple is starting this frame...
        if apple.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            apple.frameNStart = frameN  # exact frame index
            apple.tStart = t  # local t and not account for scr refresh
            apple.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(apple, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'apple.started')
            # update status
            apple.status = STARTED
            apple.setAutoDraw(True)
        
        # if apple is active this frame...
        if apple.status == STARTED:
            # update params
            pass
            # check whether apple has been pressed
            if apple.isClicked:
                if not apple.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    apple.timesOn.append(apple.buttonClock.getTime())
                    apple.timesOff.append(apple.buttonClock.getTime())
                elif len(apple.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    apple.timesOff[-1] = apple.buttonClock.getTime()
                if not apple.wasClicked:
                    # end routine when apple is clicked
                    continueRoutine = False
                if not apple.wasClicked:
                    # run callback code when apple is clicked
                    pass
        # take note of whether apple was clicked, so that next frame we know if clicks are new
        apple.wasClicked = apple.isClicked and apple.status == STARTED
        # *cauliflower* updates
        
        # if cauliflower is starting this frame...
        if cauliflower.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            cauliflower.frameNStart = frameN  # exact frame index
            cauliflower.tStart = t  # local t and not account for scr refresh
            cauliflower.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cauliflower, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'cauliflower.started')
            # update status
            cauliflower.status = STARTED
            cauliflower.setAutoDraw(True)
        
        # if cauliflower is active this frame...
        if cauliflower.status == STARTED:
            # update params
            pass
            # check whether cauliflower has been pressed
            if cauliflower.isClicked:
                if not cauliflower.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    cauliflower.timesOn.append(cauliflower.buttonClock.getTime())
                    cauliflower.timesOff.append(cauliflower.buttonClock.getTime())
                elif len(cauliflower.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    cauliflower.timesOff[-1] = cauliflower.buttonClock.getTime()
                if not cauliflower.wasClicked:
                    # end routine when cauliflower is clicked
                    continueRoutine = False
                if not cauliflower.wasClicked:
                    # run callback code when cauliflower is clicked
                    pass
        # take note of whether cauliflower was clicked, so that next frame we know if clicks are new
        cauliflower.wasClicked = cauliflower.isClicked and cauliflower.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Eng_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Eng_3" ---
    for thisComponent in SenstirEs_catch_Eng_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Eng_3.stopped', globalClock.getTime(format='float'))
    thisExp.addData('sandwitch.numClicks', sandwitch.numClicks)
    if sandwitch.numClicks:
       thisExp.addData('sandwitch.timesOn', sandwitch.timesOn)
       thisExp.addData('sandwitch.timesOff', sandwitch.timesOff)
    else:
       thisExp.addData('sandwitch.timesOn', "")
       thisExp.addData('sandwitch.timesOff', "")
    thisExp.addData('apple.numClicks', apple.numClicks)
    if apple.numClicks:
       thisExp.addData('apple.timesOn', apple.timesOn)
       thisExp.addData('apple.timesOff', apple.timesOff)
    else:
       thisExp.addData('apple.timesOn', "")
       thisExp.addData('apple.timesOff', "")
    thisExp.addData('cauliflower.numClicks', cauliflower.numClicks)
    if cauliflower.numClicks:
       thisExp.addData('cauliflower.timesOn', cauliflower.timesOn)
       thisExp.addData('cauliflower.timesOff', cauliflower.timesOff)
    else:
       thisExp.addData('cauliflower.timesOn', "")
       thisExp.addData('cauliflower.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Eng_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_80 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('stim_Eng/Stimuli_selection_Engl_80 - Sheet1.csv'),
        seed=None, name='SentirEs_80')
    thisExp.addLoop(SentirEs_80)  # add the loop to the experiment
    thisSentirE_80 = SentirEs_80.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_80.rgb)
    if thisSentirE_80 != None:
        for paramName in thisSentirE_80:
            globals()[paramName] = thisSentirE_80[paramName]
    
    for thisSentirE_80 in SentirEs_80:
        currentLoop = SentirEs_80
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_80.rgb)
        if thisSentirE_80 != None:
            for paramName in thisSentirE_80:
                globals()[paramName] = thisSentirE_80[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_Eng" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_Eng.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset next to account for continued clicks & clear times on/off
        next.reset()
        # reset Dont_know to account for continued clicks & clear times on/off
        Dont_know.reset()
        # keep track of which components have finished
        SentirEs_likert_EngComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, next, Dont_know]
        for thisComponent in SentirEs_likert_EngComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_Eng" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *next* updates
            
            # if next is starting this frame...
            if next.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next.frameNStart = frameN  # exact frame index
                next.tStart = t  # local t and not account for scr refresh
                next.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next.started')
                # update status
                next.status = STARTED
                next.setAutoDraw(True)
            
            # if next is active this frame...
            if next.status == STARTED:
                # update params
                pass
                # check whether next has been pressed
                if next.isClicked:
                    if not next.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next.timesOn.append(next.buttonClock.getTime())
                        next.timesOff.append(next.buttonClock.getTime())
                    elif len(next.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next.timesOff[-1] = next.buttonClock.getTime()
                    if not next.wasClicked:
                        # end routine when next is clicked
                        continueRoutine = False
                    if not next.wasClicked:
                        # run callback code when next is clicked
                        Vision.rating
            # take note of whether next was clicked, so that next frame we know if clicks are new
            next.wasClicked = next.isClicked and next.status == STARTED
            # *Dont_know* updates
            
            # if Dont_know is starting this frame...
            if Dont_know.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Dont_know.frameNStart = frameN  # exact frame index
                Dont_know.tStart = t  # local t and not account for scr refresh
                Dont_know.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Dont_know, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Dont_know.started')
                # update status
                Dont_know.status = STARTED
                Dont_know.setAutoDraw(True)
            
            # if Dont_know is active this frame...
            if Dont_know.status == STARTED:
                # update params
                pass
                # check whether Dont_know has been pressed
                if Dont_know.isClicked:
                    if not Dont_know.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Dont_know.timesOn.append(Dont_know.buttonClock.getTime())
                        Dont_know.timesOff.append(Dont_know.buttonClock.getTime())
                    elif len(Dont_know.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Dont_know.timesOff[-1] = Dont_know.buttonClock.getTime()
                    if not Dont_know.wasClicked:
                        # end routine when Dont_know is clicked
                        continueRoutine = False
                    if not Dont_know.wasClicked:
                        # run callback code when Dont_know is clicked
                        Vision.rating
            # take note of whether Dont_know was clicked, so that next frame we know if clicks are new
            Dont_know.wasClicked = Dont_know.isClicked and Dont_know.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_EngComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_Eng" ---
        for thisComponent in SentirEs_likert_EngComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_Eng.stopped', globalClock.getTime(format='float'))
        SentirEs_80.addData('Audition.response', Audition.getRating())
        SentirEs_80.addData('Audition.rt', Audition.getRT())
        SentirEs_80.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_80.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_80.addData('Haptic.response', Haptic.getRating())
        SentirEs_80.addData('Haptic.rt', Haptic.getRT())
        SentirEs_80.addData('Interoception.response', Interoception.getRating())
        SentirEs_80.addData('Interoception.rt', Interoception.getRT())
        SentirEs_80.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_80.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_80.addData('Vision.response', Vision.getRating())
        SentirEs_80.addData('Vision.rt', Vision.getRT())
        SentirEs_80.addData('next.numClicks', next.numClicks)
        if next.numClicks:
           SentirEs_80.addData('next.timesOn', next.timesOn)
           SentirEs_80.addData('next.timesOff', next.timesOff)
        else:
           SentirEs_80.addData('next.timesOn', "")
           SentirEs_80.addData('next.timesOff', "")
        SentirEs_80.addData('Dont_know.numClicks', Dont_know.numClicks)
        if Dont_know.numClicks:
           SentirEs_80.addData('Dont_know.timesOn', Dont_know.timesOn)
           SentirEs_80.addData('Dont_know.timesOff', Dont_know.timesOff)
        else:
           SentirEs_80.addData('Dont_know.timesOn', "")
           SentirEs_80.addData('Dont_know.timesOff', "")
        # the Routine "SentirEs_likert_Eng" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_80'
    
    
    # --- Prepare to start Routine "end" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('end.started', globalClock.getTime(format='float'))
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # keep track of which components have finished
    endComponents = [readingtext, key_resp]
    for thisComponent in endComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "end" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *readingtext* updates
        
        # if readingtext is starting this frame...
        if readingtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            readingtext.frameNStart = frameN  # exact frame index
            readingtext.tStart = t  # local t and not account for scr refresh
            readingtext.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(readingtext, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'readingtext.started')
            # update status
            readingtext.status = STARTED
            readingtext.setAutoDraw(True)
        
        # if readingtext is active this frame...
        if readingtext.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['y'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in endComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "end" ---
    for thisComponent in endComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('end.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
