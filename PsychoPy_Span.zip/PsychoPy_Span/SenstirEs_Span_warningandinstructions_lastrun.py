﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.1.4),
    on Wed Jul 17 19:50:30 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.1.4'
expName = 'SenstirEs_warningandinstructions'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = (1024, 768)
_loggingLevel = logging.getLevel('warning')
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # override logging level
    _loggingLevel = logging.getLevel(
        prefs.piloting['pilotLoggingLevel']
    )

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/soniasimon/Documents/thesis/PsychoPy_Span/SenstirEs_Span_warningandinstructions_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(_loggingLevel)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=_loggingLevel)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = False
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_resp') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "warning_span" ---
    warning_SentirEs = visual.TextStim(win=win, name='warning_SentirEs',
        text='ADERTENCIA\n\nEste estudio usa palabras cotidianas. De vez en cuando esto significa que aparecen palabras que pueden ser explicitas u ofensivas. Si se siente incomodo en cualquier momento eres libre de terminar la incuesta cerrando la ventana. \n\nPara continuar pulsa "Siguiente"',
        font='Arial bold',
        units='norm', pos=(0,0), height=0.1, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    Siguente = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente',
        depth=-1
    )
    Siguente.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_intructions_Span" ---
    intructions = visual.TextStim(win=win, name='intructions',
        text='INSTRUCCIONES\n\nLes vamos a preguntar cómo percibes palabras frecuentes usando seis sentidos corporales. No hay respuestas correctas ni incorrectas. La medida es de 0 (nunca lo percibes usando esa sensación corporal) hasta 5 (interactúas mucho usando esa sensación corporal). Haz click en el número y cuando ya haya rellenado las seis sensaciones pulsa el botón "Siguiente" para empezar la siguiente palabra\n\nSi no reconoce una palabra pulsa “No se esta palabra" y haz click al "Siguente" para continuar.',
        font='Arial',
        units='norm', pos=(0, 0), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    Siguente_instructions = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente_instructions',
        depth=-1
    )
    Siguente_instructions.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_span" ---
    text = visual.TextStim(win=win, name='text',
        text='Comó percibes ',
        font='Arial',
        units='norm', pos=(-0.75,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.70,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='usando audicion',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='usanando sabor',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='usando tacto',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='usando sensaciones \nintracorporales ',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='usando olor',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='usando vision',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    Siguente_stim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente_stim',
        depth=-14
    )
    Siguente_stim.buttonClock = core.Clock()
    No_se = visual.ButtonStim(win, 
        text='No se esta palabra', font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='No_se',
        depth=-15
    )
    No_se.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Span_1" ---
    catch_1 = visual.TextStim(win=win, name='catch_1',
        text='Cual de estos animales vuela?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    Oso = visual.ButtonStim(win, 
        text='Oso', font='Arvo',
        pos=(-0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Oso',
        depth=-1
    )
    Oso.buttonClock = core.Clock()
    Ave = visual.ButtonStim(win, 
        text='Ave', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Ave',
        depth=-2
    )
    Ave.buttonClock = core.Clock()
    Pez = visual.ButtonStim(win, 
        text='Pez', font='Arvo',
        pos=(0.5, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Pez',
        depth=-3
    )
    Pez.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_span" ---
    text = visual.TextStim(win=win, name='text',
        text='Comó percibes ',
        font='Arial',
        units='norm', pos=(-0.75,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.70,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='usando audicion',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='usanando sabor',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='usando tacto',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='usando sensaciones \nintracorporales ',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='usando olor',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='usando vision',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    Siguente_stim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente_stim',
        depth=-14
    )
    Siguente_stim.buttonClock = core.Clock()
    No_se = visual.ButtonStim(win, 
        text='No se esta palabra', font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='No_se',
        depth=-15
    )
    No_se.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Span_2" ---
    catch_2 = visual.TextStim(win=win, name='catch_2',
        text='Que es 5 x 3?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    quinze = visual.ButtonStim(win, 
        text='15', font='Arvo',
        pos=(-0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='quinze',
        depth=-1
    )
    quinze.buttonClock = core.Clock()
    cien = visual.ButtonStim(win, 
        text='100', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='cien',
        depth=-2
    )
    cien.buttonClock = core.Clock()
    setentaidos = visual.ButtonStim(win, 
        text='72 ', font='Arvo',
        pos=(0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='setentaidos',
        depth=-3
    )
    setentaidos.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_span" ---
    text = visual.TextStim(win=win, name='text',
        text='Comó percibes ',
        font='Arial',
        units='norm', pos=(-0.75,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.70,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='usando audicion',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='usanando sabor',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='usando tacto',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='usando sensaciones \nintracorporales ',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='usando olor',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='usando vision',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    Siguente_stim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente_stim',
        depth=-14
    )
    Siguente_stim.buttonClock = core.Clock()
    No_se = visual.ButtonStim(win, 
        text='No se esta palabra', font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='No_se',
        depth=-15
    )
    No_se.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SenstirEs_catch_Span_3" ---
    catch_3 = visual.TextStim(win=win, name='catch_3',
        text='Cual de estos es una fruta?',
        font='Arial',
        units='norm', pos=(0,0.8), height=0.08, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    bacadillo = visual.ButtonStim(win, 
        text='bocadillo', font='Arvo',
        pos=(-0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='bacadillo',
        depth=-1
    )
    bacadillo.buttonClock = core.Clock()
    manzana = visual.ButtonStim(win, 
        text='manzana', font='Arvo',
        pos=(0, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='manzana',
        depth=-2
    )
    manzana.buttonClock = core.Clock()
    coliflor = visual.ButtonStim(win, 
        text='coliflor', font='Arvo',
        pos=(0.3, -0.3),units='norm',
        letterHeight=0.08,
        size=(0.5, 0.5), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='coliflor',
        depth=-3
    )
    coliflor.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirEs_likert_span" ---
    text = visual.TextStim(win=win, name='text',
        text='Comó percibes ',
        font='Arial',
        units='norm', pos=(-0.75,0.8), height=0.07, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial bold',
        units='norm', pos=(-0.70,0.65), height=0.099, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    perceptual_audition = visual.TextStim(win=win, name='perceptual_audition',
        text='usando audicion',
        font='Arial',
        units='norm', pos=(-0.75,0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    perceptual_gustatory = visual.TextStim(win=win, name='perceptual_gustatory',
        text='usanando sabor',
        font='Arial',
        units='norm', pos=(-0.75,0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    perceptual_haptic = visual.TextStim(win=win, name='perceptual_haptic',
        text='usando tacto',
        font='Arial',
        units='norm', pos=(-0.75,0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    perceptual_interocepticve = visual.TextStim(win=win, name='perceptual_interocepticve',
        text='usando sensaciones \nintracorporales ',
        font='Arial',
        units='norm', pos=(-0.75,-0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    perceptual_olfaction = visual.TextStim(win=win, name='perceptual_olfaction',
        text='usando olor',
        font='Arial',
        units='norm', pos=(-0.75, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    perceptual_visual = visual.TextStim(win=win, name='perceptual_visual',
        text='usando vision',
        font='Arial',
        units='norm', pos=(-0.75, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    Audition = visual.Slider(win=win, name='Audition',
        startValue=None, size=(1.0, 0.1), pos=(0,0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    Gustatory = visual.Slider(win=win, name='Gustatory',
        startValue=None, size=(1.0, 0.1), pos=(0,0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    Haptic = visual.Slider(win=win, name='Haptic',
        startValue=None, size=(1.0, 0.1), pos=(0, 0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0, 1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    Interoception = visual.Slider(win=win, name='Interoception',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.1), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    Olfaction = visual.Slider(win=win, name='Olfaction',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.3), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    Vision = visual.Slider(win=win, name='Vision',
        startValue=None, size=(1.0, 0.1), pos=(0, -0.5), units='norm',
        labels=["nada", "totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='slider', styleTweaks=(), opacity=1.0,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.05,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    Siguente_stim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.4,-0.7),units='norm',
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Siguente_stim',
        depth=-14
    )
    Siguente_stim.buttonClock = core.Clock()
    No_se = visual.ButtonStim(win, 
        text='No se esta palabra', font='Arial',
        pos=(0.4,0.7),units='norm',
        letterHeight=0.05,
        size=(0.4, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='No_se',
        depth=-15
    )
    No_se.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "trial" ---
    readingtext = visual.TextStim(win=win, name='readingtext',
        text="Gracais por su particpacion!\n\nPulse 'y' en su techlado para terminar.\n",
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    key_resp = keyboard.Keyboard(deviceName='key_resp')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "warning_span" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('warning_span.started', globalClock.getTime(format='float'))
    # reset Siguente to account for continued clicks & clear times on/off
    Siguente.reset()
    # keep track of which components have finished
    warning_spanComponents = [warning_SentirEs, Siguente]
    for thisComponent in warning_spanComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "warning_span" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *warning_SentirEs* updates
        
        # if warning_SentirEs is starting this frame...
        if warning_SentirEs.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            warning_SentirEs.frameNStart = frameN  # exact frame index
            warning_SentirEs.tStart = t  # local t and not account for scr refresh
            warning_SentirEs.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(warning_SentirEs, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'warning_SentirEs.started')
            # update status
            warning_SentirEs.status = STARTED
            warning_SentirEs.setAutoDraw(True)
        
        # if warning_SentirEs is active this frame...
        if warning_SentirEs.status == STARTED:
            # update params
            pass
        # *Siguente* updates
        
        # if Siguente is starting this frame...
        if Siguente.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Siguente.frameNStart = frameN  # exact frame index
            Siguente.tStart = t  # local t and not account for scr refresh
            Siguente.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Siguente, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Siguente.started')
            # update status
            Siguente.status = STARTED
            Siguente.setAutoDraw(True)
        
        # if Siguente is active this frame...
        if Siguente.status == STARTED:
            # update params
            pass
            # check whether Siguente has been pressed
            if Siguente.isClicked:
                if not Siguente.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Siguente.timesOn.append(Siguente.buttonClock.getTime())
                    Siguente.timesOff.append(Siguente.buttonClock.getTime())
                elif len(Siguente.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Siguente.timesOff[-1] = Siguente.buttonClock.getTime()
                if not Siguente.wasClicked:
                    # end routine when Siguente is clicked
                    continueRoutine = False
                if not Siguente.wasClicked:
                    # run callback code when Siguente is clicked
                    Vision.rating
        # take note of whether Siguente was clicked, so that next frame we know if clicks are new
        Siguente.wasClicked = Siguente.isClicked and Siguente.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warning_spanComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "warning_span" ---
    for thisComponent in warning_spanComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('warning_span.stopped', globalClock.getTime(format='float'))
    thisExp.addData('Siguente.numClicks', Siguente.numClicks)
    if Siguente.numClicks:
       thisExp.addData('Siguente.timesOn', Siguente.timesOn)
       thisExp.addData('Siguente.timesOff', Siguente.timesOff)
    else:
       thisExp.addData('Siguente.timesOn', "")
       thisExp.addData('Siguente.timesOff', "")
    thisExp.nextEntry()
    # the Routine "warning_span" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "SentirEs_intructions_Span" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SentirEs_intructions_Span.started', globalClock.getTime(format='float'))
    # reset Siguente_instructions to account for continued clicks & clear times on/off
    Siguente_instructions.reset()
    # keep track of which components have finished
    SentirEs_intructions_SpanComponents = [intructions, Siguente_instructions]
    for thisComponent in SentirEs_intructions_SpanComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SentirEs_intructions_Span" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *intructions* updates
        
        # if intructions is starting this frame...
        if intructions.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            intructions.frameNStart = frameN  # exact frame index
            intructions.tStart = t  # local t and not account for scr refresh
            intructions.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(intructions, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'intructions.started')
            # update status
            intructions.status = STARTED
            intructions.setAutoDraw(True)
        
        # if intructions is active this frame...
        if intructions.status == STARTED:
            # update params
            pass
        # *Siguente_instructions* updates
        
        # if Siguente_instructions is starting this frame...
        if Siguente_instructions.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Siguente_instructions.frameNStart = frameN  # exact frame index
            Siguente_instructions.tStart = t  # local t and not account for scr refresh
            Siguente_instructions.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Siguente_instructions, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Siguente_instructions.started')
            # update status
            Siguente_instructions.status = STARTED
            Siguente_instructions.setAutoDraw(True)
        
        # if Siguente_instructions is active this frame...
        if Siguente_instructions.status == STARTED:
            # update params
            pass
            # check whether Siguente_instructions has been pressed
            if Siguente_instructions.isClicked:
                if not Siguente_instructions.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Siguente_instructions.timesOn.append(Siguente_instructions.buttonClock.getTime())
                    Siguente_instructions.timesOff.append(Siguente_instructions.buttonClock.getTime())
                elif len(Siguente_instructions.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Siguente_instructions.timesOff[-1] = Siguente_instructions.buttonClock.getTime()
                if not Siguente_instructions.wasClicked:
                    # end routine when Siguente_instructions is clicked
                    continueRoutine = False
                if not Siguente_instructions.wasClicked:
                    # run callback code when Siguente_instructions is clicked
                    Vision.rating
        # take note of whether Siguente_instructions was clicked, so that next frame we know if clicks are new
        Siguente_instructions.wasClicked = Siguente_instructions.isClicked and Siguente_instructions.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SentirEs_intructions_SpanComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SentirEs_intructions_Span" ---
    for thisComponent in SentirEs_intructions_SpanComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SentirEs_intructions_Span.stopped', globalClock.getTime(format='float'))
    thisExp.addData('Siguente_instructions.numClicks', Siguente_instructions.numClicks)
    if Siguente_instructions.numClicks:
       thisExp.addData('Siguente_instructions.timesOn', Siguente_instructions.timesOn)
       thisExp.addData('Siguente_instructions.timesOff', Siguente_instructions.timesOff)
    else:
       thisExp.addData('Siguente_instructions.timesOn', "")
       thisExp.addData('Siguente_instructions.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SentirEs_intructions_Span" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_19 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('stim_Span/Stimuli_selection_Span_19 - Sheet1.csv'),
        seed=None, name='SentirEs_19')
    thisExp.addLoop(SentirEs_19)  # add the loop to the experiment
    thisSentirE_19 = SentirEs_19.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_19.rgb)
    if thisSentirE_19 != None:
        for paramName in thisSentirE_19:
            globals()[paramName] = thisSentirE_19[paramName]
    
    for thisSentirE_19 in SentirEs_19:
        currentLoop = SentirEs_19
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_19.rgb)
        if thisSentirE_19 != None:
            for paramName in thisSentirE_19:
                globals()[paramName] = thisSentirE_19[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_span" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_span.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset Siguente_stim to account for continued clicks & clear times on/off
        Siguente_stim.reset()
        # reset No_se to account for continued clicks & clear times on/off
        No_se.reset()
        # keep track of which components have finished
        SentirEs_likert_spanComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, Siguente_stim, No_se]
        for thisComponent in SentirEs_likert_spanComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_span" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *Siguente_stim* updates
            
            # if Siguente_stim is starting this frame...
            if Siguente_stim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Siguente_stim.frameNStart = frameN  # exact frame index
                Siguente_stim.tStart = t  # local t and not account for scr refresh
                Siguente_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Siguente_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Siguente_stim.started')
                # update status
                Siguente_stim.status = STARTED
                Siguente_stim.setAutoDraw(True)
            
            # if Siguente_stim is active this frame...
            if Siguente_stim.status == STARTED:
                # update params
                pass
                # check whether Siguente_stim has been pressed
                if Siguente_stim.isClicked:
                    if not Siguente_stim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Siguente_stim.timesOn.append(Siguente_stim.buttonClock.getTime())
                        Siguente_stim.timesOff.append(Siguente_stim.buttonClock.getTime())
                    elif len(Siguente_stim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Siguente_stim.timesOff[-1] = Siguente_stim.buttonClock.getTime()
                    if not Siguente_stim.wasClicked:
                        # end routine when Siguente_stim is clicked
                        continueRoutine = False
                    if not Siguente_stim.wasClicked:
                        # run callback code when Siguente_stim is clicked
                        Vision.rating
            # take note of whether Siguente_stim was clicked, so that next frame we know if clicks are new
            Siguente_stim.wasClicked = Siguente_stim.isClicked and Siguente_stim.status == STARTED
            # *No_se* updates
            
            # if No_se is starting this frame...
            if No_se.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                No_se.frameNStart = frameN  # exact frame index
                No_se.tStart = t  # local t and not account for scr refresh
                No_se.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(No_se, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'No_se.started')
                # update status
                No_se.status = STARTED
                No_se.setAutoDraw(True)
            
            # if No_se is active this frame...
            if No_se.status == STARTED:
                # update params
                pass
                # check whether No_se has been pressed
                if No_se.isClicked:
                    if not No_se.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        No_se.timesOn.append(No_se.buttonClock.getTime())
                        No_se.timesOff.append(No_se.buttonClock.getTime())
                    elif len(No_se.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        No_se.timesOff[-1] = No_se.buttonClock.getTime()
                    if not No_se.wasClicked:
                        # run callback code when No_se is clicked
                        pass
            # take note of whether No_se was clicked, so that next frame we know if clicks are new
            No_se.wasClicked = No_se.isClicked and No_se.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_spanComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_span" ---
        for thisComponent in SentirEs_likert_spanComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_span.stopped', globalClock.getTime(format='float'))
        SentirEs_19.addData('Audition.response', Audition.getRating())
        SentirEs_19.addData('Audition.rt', Audition.getRT())
        SentirEs_19.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_19.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_19.addData('Haptic.response', Haptic.getRating())
        SentirEs_19.addData('Haptic.rt', Haptic.getRT())
        SentirEs_19.addData('Interoception.response', Interoception.getRating())
        SentirEs_19.addData('Interoception.rt', Interoception.getRT())
        SentirEs_19.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_19.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_19.addData('Vision.response', Vision.getRating())
        SentirEs_19.addData('Vision.rt', Vision.getRT())
        SentirEs_19.addData('Siguente_stim.numClicks', Siguente_stim.numClicks)
        if Siguente_stim.numClicks:
           SentirEs_19.addData('Siguente_stim.timesOn', Siguente_stim.timesOn)
           SentirEs_19.addData('Siguente_stim.timesOff', Siguente_stim.timesOff)
        else:
           SentirEs_19.addData('Siguente_stim.timesOn', "")
           SentirEs_19.addData('Siguente_stim.timesOff', "")
        SentirEs_19.addData('No_se.numClicks', No_se.numClicks)
        if No_se.numClicks:
           SentirEs_19.addData('No_se.timesOn', No_se.timesOn)
           SentirEs_19.addData('No_se.timesOff', No_se.timesOff)
        else:
           SentirEs_19.addData('No_se.timesOn', "")
           SentirEs_19.addData('No_se.timesOff', "")
        # the Routine "SentirEs_likert_span" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_19'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Span_1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Span_1.started', globalClock.getTime(format='float'))
    # reset Oso to account for continued clicks & clear times on/off
    Oso.reset()
    # reset Ave to account for continued clicks & clear times on/off
    Ave.reset()
    # reset Pez to account for continued clicks & clear times on/off
    Pez.reset()
    # keep track of which components have finished
    SenstirEs_catch_Span_1Components = [catch_1, Oso, Ave, Pez]
    for thisComponent in SenstirEs_catch_Span_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Span_1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_1* updates
        
        # if catch_1 is starting this frame...
        if catch_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_1.frameNStart = frameN  # exact frame index
            catch_1.tStart = t  # local t and not account for scr refresh
            catch_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_1.started')
            # update status
            catch_1.status = STARTED
            catch_1.setAutoDraw(True)
        
        # if catch_1 is active this frame...
        if catch_1.status == STARTED:
            # update params
            pass
        # *Oso* updates
        
        # if Oso is starting this frame...
        if Oso.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Oso.frameNStart = frameN  # exact frame index
            Oso.tStart = t  # local t and not account for scr refresh
            Oso.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Oso, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Oso.started')
            # update status
            Oso.status = STARTED
            Oso.setAutoDraw(True)
        
        # if Oso is active this frame...
        if Oso.status == STARTED:
            # update params
            pass
            # check whether Oso has been pressed
            if Oso.isClicked:
                if not Oso.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Oso.timesOn.append(Oso.buttonClock.getTime())
                    Oso.timesOff.append(Oso.buttonClock.getTime())
                elif len(Oso.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Oso.timesOff[-1] = Oso.buttonClock.getTime()
                if not Oso.wasClicked:
                    # end routine when Oso is clicked
                    continueRoutine = False
                if not Oso.wasClicked:
                    # run callback code when Oso is clicked
                    pass
        # take note of whether Oso was clicked, so that next frame we know if clicks are new
        Oso.wasClicked = Oso.isClicked and Oso.status == STARTED
        # *Ave* updates
        
        # if Ave is starting this frame...
        if Ave.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ave.frameNStart = frameN  # exact frame index
            Ave.tStart = t  # local t and not account for scr refresh
            Ave.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ave, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Ave.started')
            # update status
            Ave.status = STARTED
            Ave.setAutoDraw(True)
        
        # if Ave is active this frame...
        if Ave.status == STARTED:
            # update params
            pass
            # check whether Ave has been pressed
            if Ave.isClicked:
                if not Ave.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Ave.timesOn.append(Ave.buttonClock.getTime())
                    Ave.timesOff.append(Ave.buttonClock.getTime())
                elif len(Ave.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Ave.timesOff[-1] = Ave.buttonClock.getTime()
                if not Ave.wasClicked:
                    # end routine when Ave is clicked
                    continueRoutine = False
                if not Ave.wasClicked:
                    # run callback code when Ave is clicked
                    pass
        # take note of whether Ave was clicked, so that next frame we know if clicks are new
        Ave.wasClicked = Ave.isClicked and Ave.status == STARTED
        # *Pez* updates
        
        # if Pez is starting this frame...
        if Pez.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Pez.frameNStart = frameN  # exact frame index
            Pez.tStart = t  # local t and not account for scr refresh
            Pez.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Pez, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Pez.started')
            # update status
            Pez.status = STARTED
            Pez.setAutoDraw(True)
        
        # if Pez is active this frame...
        if Pez.status == STARTED:
            # update params
            pass
            # check whether Pez has been pressed
            if Pez.isClicked:
                if not Pez.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Pez.timesOn.append(Pez.buttonClock.getTime())
                    Pez.timesOff.append(Pez.buttonClock.getTime())
                elif len(Pez.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Pez.timesOff[-1] = Pez.buttonClock.getTime()
                if not Pez.wasClicked:
                    # end routine when Pez is clicked
                    continueRoutine = False
                if not Pez.wasClicked:
                    # run callback code when Pez is clicked
                    pass
        # take note of whether Pez was clicked, so that next frame we know if clicks are new
        Pez.wasClicked = Pez.isClicked and Pez.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Span_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Span_1" ---
    for thisComponent in SenstirEs_catch_Span_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Span_1.stopped', globalClock.getTime(format='float'))
    thisExp.addData('Oso.numClicks', Oso.numClicks)
    if Oso.numClicks:
       thisExp.addData('Oso.timesOn', Oso.timesOn)
       thisExp.addData('Oso.timesOff', Oso.timesOff)
    else:
       thisExp.addData('Oso.timesOn', "")
       thisExp.addData('Oso.timesOff', "")
    thisExp.addData('Ave.numClicks', Ave.numClicks)
    if Ave.numClicks:
       thisExp.addData('Ave.timesOn', Ave.timesOn)
       thisExp.addData('Ave.timesOff', Ave.timesOff)
    else:
       thisExp.addData('Ave.timesOn', "")
       thisExp.addData('Ave.timesOff', "")
    thisExp.addData('Pez.numClicks', Pez.numClicks)
    if Pez.numClicks:
       thisExp.addData('Pez.timesOn', Pez.timesOn)
       thisExp.addData('Pez.timesOff', Pez.timesOff)
    else:
       thisExp.addData('Pez.timesOn', "")
       thisExp.addData('Pez.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Span_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_45 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Stimuli_selection_Span_45 - Sheet1.csv'),
        seed=None, name='SentirEs_45')
    thisExp.addLoop(SentirEs_45)  # add the loop to the experiment
    thisSentirE_45 = SentirEs_45.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_45.rgb)
    if thisSentirE_45 != None:
        for paramName in thisSentirE_45:
            globals()[paramName] = thisSentirE_45[paramName]
    
    for thisSentirE_45 in SentirEs_45:
        currentLoop = SentirEs_45
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_45.rgb)
        if thisSentirE_45 != None:
            for paramName in thisSentirE_45:
                globals()[paramName] = thisSentirE_45[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_span" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_span.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset Siguente_stim to account for continued clicks & clear times on/off
        Siguente_stim.reset()
        # reset No_se to account for continued clicks & clear times on/off
        No_se.reset()
        # keep track of which components have finished
        SentirEs_likert_spanComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, Siguente_stim, No_se]
        for thisComponent in SentirEs_likert_spanComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_span" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *Siguente_stim* updates
            
            # if Siguente_stim is starting this frame...
            if Siguente_stim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Siguente_stim.frameNStart = frameN  # exact frame index
                Siguente_stim.tStart = t  # local t and not account for scr refresh
                Siguente_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Siguente_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Siguente_stim.started')
                # update status
                Siguente_stim.status = STARTED
                Siguente_stim.setAutoDraw(True)
            
            # if Siguente_stim is active this frame...
            if Siguente_stim.status == STARTED:
                # update params
                pass
                # check whether Siguente_stim has been pressed
                if Siguente_stim.isClicked:
                    if not Siguente_stim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Siguente_stim.timesOn.append(Siguente_stim.buttonClock.getTime())
                        Siguente_stim.timesOff.append(Siguente_stim.buttonClock.getTime())
                    elif len(Siguente_stim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Siguente_stim.timesOff[-1] = Siguente_stim.buttonClock.getTime()
                    if not Siguente_stim.wasClicked:
                        # end routine when Siguente_stim is clicked
                        continueRoutine = False
                    if not Siguente_stim.wasClicked:
                        # run callback code when Siguente_stim is clicked
                        Vision.rating
            # take note of whether Siguente_stim was clicked, so that next frame we know if clicks are new
            Siguente_stim.wasClicked = Siguente_stim.isClicked and Siguente_stim.status == STARTED
            # *No_se* updates
            
            # if No_se is starting this frame...
            if No_se.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                No_se.frameNStart = frameN  # exact frame index
                No_se.tStart = t  # local t and not account for scr refresh
                No_se.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(No_se, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'No_se.started')
                # update status
                No_se.status = STARTED
                No_se.setAutoDraw(True)
            
            # if No_se is active this frame...
            if No_se.status == STARTED:
                # update params
                pass
                # check whether No_se has been pressed
                if No_se.isClicked:
                    if not No_se.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        No_se.timesOn.append(No_se.buttonClock.getTime())
                        No_se.timesOff.append(No_se.buttonClock.getTime())
                    elif len(No_se.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        No_se.timesOff[-1] = No_se.buttonClock.getTime()
                    if not No_se.wasClicked:
                        # run callback code when No_se is clicked
                        pass
            # take note of whether No_se was clicked, so that next frame we know if clicks are new
            No_se.wasClicked = No_se.isClicked and No_se.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_spanComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_span" ---
        for thisComponent in SentirEs_likert_spanComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_span.stopped', globalClock.getTime(format='float'))
        SentirEs_45.addData('Audition.response', Audition.getRating())
        SentirEs_45.addData('Audition.rt', Audition.getRT())
        SentirEs_45.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_45.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_45.addData('Haptic.response', Haptic.getRating())
        SentirEs_45.addData('Haptic.rt', Haptic.getRT())
        SentirEs_45.addData('Interoception.response', Interoception.getRating())
        SentirEs_45.addData('Interoception.rt', Interoception.getRT())
        SentirEs_45.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_45.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_45.addData('Vision.response', Vision.getRating())
        SentirEs_45.addData('Vision.rt', Vision.getRT())
        SentirEs_45.addData('Siguente_stim.numClicks', Siguente_stim.numClicks)
        if Siguente_stim.numClicks:
           SentirEs_45.addData('Siguente_stim.timesOn', Siguente_stim.timesOn)
           SentirEs_45.addData('Siguente_stim.timesOff', Siguente_stim.timesOff)
        else:
           SentirEs_45.addData('Siguente_stim.timesOn', "")
           SentirEs_45.addData('Siguente_stim.timesOff', "")
        SentirEs_45.addData('No_se.numClicks', No_se.numClicks)
        if No_se.numClicks:
           SentirEs_45.addData('No_se.timesOn', No_se.timesOn)
           SentirEs_45.addData('No_se.timesOff', No_se.timesOff)
        else:
           SentirEs_45.addData('No_se.timesOn', "")
           SentirEs_45.addData('No_se.timesOff', "")
        # the Routine "SentirEs_likert_span" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_45'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Span_2" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Span_2.started', globalClock.getTime(format='float'))
    # reset quinze to account for continued clicks & clear times on/off
    quinze.reset()
    # reset cien to account for continued clicks & clear times on/off
    cien.reset()
    # reset setentaidos to account for continued clicks & clear times on/off
    setentaidos.reset()
    # keep track of which components have finished
    SenstirEs_catch_Span_2Components = [catch_2, quinze, cien, setentaidos]
    for thisComponent in SenstirEs_catch_Span_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Span_2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_2* updates
        
        # if catch_2 is starting this frame...
        if catch_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_2.frameNStart = frameN  # exact frame index
            catch_2.tStart = t  # local t and not account for scr refresh
            catch_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_2.started')
            # update status
            catch_2.status = STARTED
            catch_2.setAutoDraw(True)
        
        # if catch_2 is active this frame...
        if catch_2.status == STARTED:
            # update params
            pass
        # *quinze* updates
        
        # if quinze is starting this frame...
        if quinze.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            quinze.frameNStart = frameN  # exact frame index
            quinze.tStart = t  # local t and not account for scr refresh
            quinze.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(quinze, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'quinze.started')
            # update status
            quinze.status = STARTED
            quinze.setAutoDraw(True)
        
        # if quinze is active this frame...
        if quinze.status == STARTED:
            # update params
            pass
            # check whether quinze has been pressed
            if quinze.isClicked:
                if not quinze.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    quinze.timesOn.append(quinze.buttonClock.getTime())
                    quinze.timesOff.append(quinze.buttonClock.getTime())
                elif len(quinze.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    quinze.timesOff[-1] = quinze.buttonClock.getTime()
                if not quinze.wasClicked:
                    # end routine when quinze is clicked
                    continueRoutine = False
                if not quinze.wasClicked:
                    # run callback code when quinze is clicked
                    pass
        # take note of whether quinze was clicked, so that next frame we know if clicks are new
        quinze.wasClicked = quinze.isClicked and quinze.status == STARTED
        # *cien* updates
        
        # if cien is starting this frame...
        if cien.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            cien.frameNStart = frameN  # exact frame index
            cien.tStart = t  # local t and not account for scr refresh
            cien.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cien, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'cien.started')
            # update status
            cien.status = STARTED
            cien.setAutoDraw(True)
        
        # if cien is active this frame...
        if cien.status == STARTED:
            # update params
            pass
            # check whether cien has been pressed
            if cien.isClicked:
                if not cien.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    cien.timesOn.append(cien.buttonClock.getTime())
                    cien.timesOff.append(cien.buttonClock.getTime())
                elif len(cien.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    cien.timesOff[-1] = cien.buttonClock.getTime()
                if not cien.wasClicked:
                    # end routine when cien is clicked
                    continueRoutine = False
                if not cien.wasClicked:
                    # run callback code when cien is clicked
                    pass
        # take note of whether cien was clicked, so that next frame we know if clicks are new
        cien.wasClicked = cien.isClicked and cien.status == STARTED
        # *setentaidos* updates
        
        # if setentaidos is starting this frame...
        if setentaidos.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            setentaidos.frameNStart = frameN  # exact frame index
            setentaidos.tStart = t  # local t and not account for scr refresh
            setentaidos.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(setentaidos, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'setentaidos.started')
            # update status
            setentaidos.status = STARTED
            setentaidos.setAutoDraw(True)
        
        # if setentaidos is active this frame...
        if setentaidos.status == STARTED:
            # update params
            pass
            # check whether setentaidos has been pressed
            if setentaidos.isClicked:
                if not setentaidos.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    setentaidos.timesOn.append(setentaidos.buttonClock.getTime())
                    setentaidos.timesOff.append(setentaidos.buttonClock.getTime())
                elif len(setentaidos.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    setentaidos.timesOff[-1] = setentaidos.buttonClock.getTime()
                if not setentaidos.wasClicked:
                    # end routine when setentaidos is clicked
                    continueRoutine = False
                if not setentaidos.wasClicked:
                    # run callback code when setentaidos is clicked
                    pass
        # take note of whether setentaidos was clicked, so that next frame we know if clicks are new
        setentaidos.wasClicked = setentaidos.isClicked and setentaidos.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Span_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Span_2" ---
    for thisComponent in SenstirEs_catch_Span_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Span_2.stopped', globalClock.getTime(format='float'))
    thisExp.addData('quinze.numClicks', quinze.numClicks)
    if quinze.numClicks:
       thisExp.addData('quinze.timesOn', quinze.timesOn)
       thisExp.addData('quinze.timesOff', quinze.timesOff)
    else:
       thisExp.addData('quinze.timesOn', "")
       thisExp.addData('quinze.timesOff', "")
    thisExp.addData('cien.numClicks', cien.numClicks)
    if cien.numClicks:
       thisExp.addData('cien.timesOn', cien.timesOn)
       thisExp.addData('cien.timesOff', cien.timesOff)
    else:
       thisExp.addData('cien.timesOn', "")
       thisExp.addData('cien.timesOff', "")
    thisExp.addData('setentaidos.numClicks', setentaidos.numClicks)
    if setentaidos.numClicks:
       thisExp.addData('setentaidos.timesOn', setentaidos.timesOn)
       thisExp.addData('setentaidos.timesOff', setentaidos.timesOff)
    else:
       thisExp.addData('setentaidos.timesOn', "")
       thisExp.addData('setentaidos.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Span_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirEs_78 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Stimuli_selection_Span_78 - Sheet1.csv'),
        seed=None, name='SentirEs_78')
    thisExp.addLoop(SentirEs_78)  # add the loop to the experiment
    thisSentirE_78 = SentirEs_78.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirE_78.rgb)
    if thisSentirE_78 != None:
        for paramName in thisSentirE_78:
            globals()[paramName] = thisSentirE_78[paramName]
    
    for thisSentirE_78 in SentirEs_78:
        currentLoop = SentirEs_78
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisSentirE_78.rgb)
        if thisSentirE_78 != None:
            for paramName in thisSentirE_78:
                globals()[paramName] = thisSentirE_78[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_span" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_span.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset Siguente_stim to account for continued clicks & clear times on/off
        Siguente_stim.reset()
        # reset No_se to account for continued clicks & clear times on/off
        No_se.reset()
        # keep track of which components have finished
        SentirEs_likert_spanComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, Siguente_stim, No_se]
        for thisComponent in SentirEs_likert_spanComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_span" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *Siguente_stim* updates
            
            # if Siguente_stim is starting this frame...
            if Siguente_stim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Siguente_stim.frameNStart = frameN  # exact frame index
                Siguente_stim.tStart = t  # local t and not account for scr refresh
                Siguente_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Siguente_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Siguente_stim.started')
                # update status
                Siguente_stim.status = STARTED
                Siguente_stim.setAutoDraw(True)
            
            # if Siguente_stim is active this frame...
            if Siguente_stim.status == STARTED:
                # update params
                pass
                # check whether Siguente_stim has been pressed
                if Siguente_stim.isClicked:
                    if not Siguente_stim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Siguente_stim.timesOn.append(Siguente_stim.buttonClock.getTime())
                        Siguente_stim.timesOff.append(Siguente_stim.buttonClock.getTime())
                    elif len(Siguente_stim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Siguente_stim.timesOff[-1] = Siguente_stim.buttonClock.getTime()
                    if not Siguente_stim.wasClicked:
                        # end routine when Siguente_stim is clicked
                        continueRoutine = False
                    if not Siguente_stim.wasClicked:
                        # run callback code when Siguente_stim is clicked
                        Vision.rating
            # take note of whether Siguente_stim was clicked, so that next frame we know if clicks are new
            Siguente_stim.wasClicked = Siguente_stim.isClicked and Siguente_stim.status == STARTED
            # *No_se* updates
            
            # if No_se is starting this frame...
            if No_se.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                No_se.frameNStart = frameN  # exact frame index
                No_se.tStart = t  # local t and not account for scr refresh
                No_se.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(No_se, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'No_se.started')
                # update status
                No_se.status = STARTED
                No_se.setAutoDraw(True)
            
            # if No_se is active this frame...
            if No_se.status == STARTED:
                # update params
                pass
                # check whether No_se has been pressed
                if No_se.isClicked:
                    if not No_se.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        No_se.timesOn.append(No_se.buttonClock.getTime())
                        No_se.timesOff.append(No_se.buttonClock.getTime())
                    elif len(No_se.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        No_se.timesOff[-1] = No_se.buttonClock.getTime()
                    if not No_se.wasClicked:
                        # run callback code when No_se is clicked
                        pass
            # take note of whether No_se was clicked, so that next frame we know if clicks are new
            No_se.wasClicked = No_se.isClicked and No_se.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_spanComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_span" ---
        for thisComponent in SentirEs_likert_spanComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_span.stopped', globalClock.getTime(format='float'))
        SentirEs_78.addData('Audition.response', Audition.getRating())
        SentirEs_78.addData('Audition.rt', Audition.getRT())
        SentirEs_78.addData('Gustatory.response', Gustatory.getRating())
        SentirEs_78.addData('Gustatory.rt', Gustatory.getRT())
        SentirEs_78.addData('Haptic.response', Haptic.getRating())
        SentirEs_78.addData('Haptic.rt', Haptic.getRT())
        SentirEs_78.addData('Interoception.response', Interoception.getRating())
        SentirEs_78.addData('Interoception.rt', Interoception.getRT())
        SentirEs_78.addData('Olfaction.response', Olfaction.getRating())
        SentirEs_78.addData('Olfaction.rt', Olfaction.getRT())
        SentirEs_78.addData('Vision.response', Vision.getRating())
        SentirEs_78.addData('Vision.rt', Vision.getRT())
        SentirEs_78.addData('Siguente_stim.numClicks', Siguente_stim.numClicks)
        if Siguente_stim.numClicks:
           SentirEs_78.addData('Siguente_stim.timesOn', Siguente_stim.timesOn)
           SentirEs_78.addData('Siguente_stim.timesOff', Siguente_stim.timesOff)
        else:
           SentirEs_78.addData('Siguente_stim.timesOn', "")
           SentirEs_78.addData('Siguente_stim.timesOff', "")
        SentirEs_78.addData('No_se.numClicks', No_se.numClicks)
        if No_se.numClicks:
           SentirEs_78.addData('No_se.timesOn', No_se.timesOn)
           SentirEs_78.addData('No_se.timesOff', No_se.timesOff)
        else:
           SentirEs_78.addData('No_se.timesOn', "")
           SentirEs_78.addData('No_se.timesOff', "")
        # the Routine "SentirEs_likert_span" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'SentirEs_78'
    
    
    # --- Prepare to start Routine "SenstirEs_catch_Span_3" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('SenstirEs_catch_Span_3.started', globalClock.getTime(format='float'))
    # reset bacadillo to account for continued clicks & clear times on/off
    bacadillo.reset()
    # reset manzana to account for continued clicks & clear times on/off
    manzana.reset()
    # reset coliflor to account for continued clicks & clear times on/off
    coliflor.reset()
    # keep track of which components have finished
    SenstirEs_catch_Span_3Components = [catch_3, bacadillo, manzana, coliflor]
    for thisComponent in SenstirEs_catch_Span_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SenstirEs_catch_Span_3" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch_3* updates
        
        # if catch_3 is starting this frame...
        if catch_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch_3.frameNStart = frameN  # exact frame index
            catch_3.tStart = t  # local t and not account for scr refresh
            catch_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch_3.started')
            # update status
            catch_3.status = STARTED
            catch_3.setAutoDraw(True)
        
        # if catch_3 is active this frame...
        if catch_3.status == STARTED:
            # update params
            pass
        # *bacadillo* updates
        
        # if bacadillo is starting this frame...
        if bacadillo.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            bacadillo.frameNStart = frameN  # exact frame index
            bacadillo.tStart = t  # local t and not account for scr refresh
            bacadillo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(bacadillo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'bacadillo.started')
            # update status
            bacadillo.status = STARTED
            bacadillo.setAutoDraw(True)
        
        # if bacadillo is active this frame...
        if bacadillo.status == STARTED:
            # update params
            pass
            # check whether bacadillo has been pressed
            if bacadillo.isClicked:
                if not bacadillo.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    bacadillo.timesOn.append(bacadillo.buttonClock.getTime())
                    bacadillo.timesOff.append(bacadillo.buttonClock.getTime())
                elif len(bacadillo.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    bacadillo.timesOff[-1] = bacadillo.buttonClock.getTime()
                if not bacadillo.wasClicked:
                    # end routine when bacadillo is clicked
                    continueRoutine = False
                if not bacadillo.wasClicked:
                    # run callback code when bacadillo is clicked
                    pass
        # take note of whether bacadillo was clicked, so that next frame we know if clicks are new
        bacadillo.wasClicked = bacadillo.isClicked and bacadillo.status == STARTED
        # *manzana* updates
        
        # if manzana is starting this frame...
        if manzana.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            manzana.frameNStart = frameN  # exact frame index
            manzana.tStart = t  # local t and not account for scr refresh
            manzana.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(manzana, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'manzana.started')
            # update status
            manzana.status = STARTED
            manzana.setAutoDraw(True)
        
        # if manzana is active this frame...
        if manzana.status == STARTED:
            # update params
            pass
            # check whether manzana has been pressed
            if manzana.isClicked:
                if not manzana.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    manzana.timesOn.append(manzana.buttonClock.getTime())
                    manzana.timesOff.append(manzana.buttonClock.getTime())
                elif len(manzana.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    manzana.timesOff[-1] = manzana.buttonClock.getTime()
                if not manzana.wasClicked:
                    # end routine when manzana is clicked
                    continueRoutine = False
                if not manzana.wasClicked:
                    # run callback code when manzana is clicked
                    pass
        # take note of whether manzana was clicked, so that next frame we know if clicks are new
        manzana.wasClicked = manzana.isClicked and manzana.status == STARTED
        # *coliflor* updates
        
        # if coliflor is starting this frame...
        if coliflor.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            coliflor.frameNStart = frameN  # exact frame index
            coliflor.tStart = t  # local t and not account for scr refresh
            coliflor.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(coliflor, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'coliflor.started')
            # update status
            coliflor.status = STARTED
            coliflor.setAutoDraw(True)
        
        # if coliflor is active this frame...
        if coliflor.status == STARTED:
            # update params
            pass
            # check whether coliflor has been pressed
            if coliflor.isClicked:
                if not coliflor.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    coliflor.timesOn.append(coliflor.buttonClock.getTime())
                    coliflor.timesOff.append(coliflor.buttonClock.getTime())
                elif len(coliflor.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    coliflor.timesOff[-1] = coliflor.buttonClock.getTime()
                if not coliflor.wasClicked:
                    # end routine when coliflor is clicked
                    continueRoutine = False
                if not coliflor.wasClicked:
                    # run callback code when coliflor is clicked
                    pass
        # take note of whether coliflor was clicked, so that next frame we know if clicks are new
        coliflor.wasClicked = coliflor.isClicked and coliflor.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SenstirEs_catch_Span_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SenstirEs_catch_Span_3" ---
    for thisComponent in SenstirEs_catch_Span_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('SenstirEs_catch_Span_3.stopped', globalClock.getTime(format='float'))
    thisExp.addData('bacadillo.numClicks', bacadillo.numClicks)
    if bacadillo.numClicks:
       thisExp.addData('bacadillo.timesOn', bacadillo.timesOn)
       thisExp.addData('bacadillo.timesOff', bacadillo.timesOff)
    else:
       thisExp.addData('bacadillo.timesOn', "")
       thisExp.addData('bacadillo.timesOff', "")
    thisExp.addData('manzana.numClicks', manzana.numClicks)
    if manzana.numClicks:
       thisExp.addData('manzana.timesOn', manzana.timesOn)
       thisExp.addData('manzana.timesOff', manzana.timesOff)
    else:
       thisExp.addData('manzana.timesOn', "")
       thisExp.addData('manzana.timesOff', "")
    thisExp.addData('coliflor.numClicks', coliflor.numClicks)
    if coliflor.numClicks:
       thisExp.addData('coliflor.timesOn', coliflor.timesOn)
       thisExp.addData('coliflor.timesOff', coliflor.timesOff)
    else:
       thisExp.addData('coliflor.timesOn', "")
       thisExp.addData('coliflor.timesOff', "")
    thisExp.nextEntry()
    # the Routine "SenstirEs_catch_Span_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Stimuli_selection_Span_80 - Sheet1.csv'),
        seed=None, name='trials')
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            globals()[paramName] = thisTrial[paramName]
    
    for thisTrial in trials:
        currentLoop = trials
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        
        # --- Prepare to start Routine "SentirEs_likert_span" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('SentirEs_likert_span.started', globalClock.getTime(format='float'))
        stimuli.setText(Word)
        Audition.reset()
        Gustatory.reset()
        Haptic.reset()
        Interoception.reset()
        Olfaction.reset()
        Vision.reset()
        # reset Siguente_stim to account for continued clicks & clear times on/off
        Siguente_stim.reset()
        # reset No_se to account for continued clicks & clear times on/off
        No_se.reset()
        # keep track of which components have finished
        SentirEs_likert_spanComponents = [text, stimuli, perceptual_audition, perceptual_gustatory, perceptual_haptic, perceptual_interocepticve, perceptual_olfaction, perceptual_visual, Audition, Gustatory, Haptic, Interoception, Olfaction, Vision, Siguente_stim, No_se]
        for thisComponent in SentirEs_likert_spanComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirEs_likert_span" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *perceptual_audition* updates
            
            # if perceptual_audition is starting this frame...
            if perceptual_audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_audition.frameNStart = frameN  # exact frame index
                perceptual_audition.tStart = t  # local t and not account for scr refresh
                perceptual_audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_audition.started')
                # update status
                perceptual_audition.status = STARTED
                perceptual_audition.setAutoDraw(True)
            
            # if perceptual_audition is active this frame...
            if perceptual_audition.status == STARTED:
                # update params
                pass
            
            # *perceptual_gustatory* updates
            
            # if perceptual_gustatory is starting this frame...
            if perceptual_gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_gustatory.frameNStart = frameN  # exact frame index
                perceptual_gustatory.tStart = t  # local t and not account for scr refresh
                perceptual_gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_gustatory.started')
                # update status
                perceptual_gustatory.status = STARTED
                perceptual_gustatory.setAutoDraw(True)
            
            # if perceptual_gustatory is active this frame...
            if perceptual_gustatory.status == STARTED:
                # update params
                pass
            
            # *perceptual_haptic* updates
            
            # if perceptual_haptic is starting this frame...
            if perceptual_haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_haptic.frameNStart = frameN  # exact frame index
                perceptual_haptic.tStart = t  # local t and not account for scr refresh
                perceptual_haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_haptic.started')
                # update status
                perceptual_haptic.status = STARTED
                perceptual_haptic.setAutoDraw(True)
            
            # if perceptual_haptic is active this frame...
            if perceptual_haptic.status == STARTED:
                # update params
                pass
            
            # *perceptual_interocepticve* updates
            
            # if perceptual_interocepticve is starting this frame...
            if perceptual_interocepticve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_interocepticve.frameNStart = frameN  # exact frame index
                perceptual_interocepticve.tStart = t  # local t and not account for scr refresh
                perceptual_interocepticve.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_interocepticve, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_interocepticve.started')
                # update status
                perceptual_interocepticve.status = STARTED
                perceptual_interocepticve.setAutoDraw(True)
            
            # if perceptual_interocepticve is active this frame...
            if perceptual_interocepticve.status == STARTED:
                # update params
                pass
            
            # *perceptual_olfaction* updates
            
            # if perceptual_olfaction is starting this frame...
            if perceptual_olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_olfaction.frameNStart = frameN  # exact frame index
                perceptual_olfaction.tStart = t  # local t and not account for scr refresh
                perceptual_olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_olfaction.started')
                # update status
                perceptual_olfaction.status = STARTED
                perceptual_olfaction.setAutoDraw(True)
            
            # if perceptual_olfaction is active this frame...
            if perceptual_olfaction.status == STARTED:
                # update params
                pass
            
            # *perceptual_visual* updates
            
            # if perceptual_visual is starting this frame...
            if perceptual_visual.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                perceptual_visual.frameNStart = frameN  # exact frame index
                perceptual_visual.tStart = t  # local t and not account for scr refresh
                perceptual_visual.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(perceptual_visual, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'perceptual_visual.started')
                # update status
                perceptual_visual.status = STARTED
                perceptual_visual.setAutoDraw(True)
            
            # if perceptual_visual is active this frame...
            if perceptual_visual.status == STARTED:
                # update params
                pass
            
            # *Audition* updates
            
            # if Audition is starting this frame...
            if Audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Audition.frameNStart = frameN  # exact frame index
                Audition.tStart = t  # local t and not account for scr refresh
                Audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Audition.started')
                # update status
                Audition.status = STARTED
                Audition.setAutoDraw(True)
            
            # if Audition is active this frame...
            if Audition.status == STARTED:
                # update params
                pass
            
            # *Gustatory* updates
            
            # if Gustatory is starting this frame...
            if Gustatory.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Gustatory.frameNStart = frameN  # exact frame index
                Gustatory.tStart = t  # local t and not account for scr refresh
                Gustatory.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Gustatory, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Gustatory.started')
                # update status
                Gustatory.status = STARTED
                Gustatory.setAutoDraw(True)
            
            # if Gustatory is active this frame...
            if Gustatory.status == STARTED:
                # update params
                pass
            
            # *Haptic* updates
            
            # if Haptic is starting this frame...
            if Haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Haptic.frameNStart = frameN  # exact frame index
                Haptic.tStart = t  # local t and not account for scr refresh
                Haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Haptic.started')
                # update status
                Haptic.status = STARTED
                Haptic.setAutoDraw(True)
            
            # if Haptic is active this frame...
            if Haptic.status == STARTED:
                # update params
                pass
            
            # *Interoception* updates
            
            # if Interoception is starting this frame...
            if Interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Interoception.frameNStart = frameN  # exact frame index
                Interoception.tStart = t  # local t and not account for scr refresh
                Interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Interoception.started')
                # update status
                Interoception.status = STARTED
                Interoception.setAutoDraw(True)
            
            # if Interoception is active this frame...
            if Interoception.status == STARTED:
                # update params
                pass
            
            # *Olfaction* updates
            
            # if Olfaction is starting this frame...
            if Olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Olfaction.frameNStart = frameN  # exact frame index
                Olfaction.tStart = t  # local t and not account for scr refresh
                Olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Olfaction.started')
                # update status
                Olfaction.status = STARTED
                Olfaction.setAutoDraw(True)
            
            # if Olfaction is active this frame...
            if Olfaction.status == STARTED:
                # update params
                pass
            
            # *Vision* updates
            
            # if Vision is starting this frame...
            if Vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Vision.frameNStart = frameN  # exact frame index
                Vision.tStart = t  # local t and not account for scr refresh
                Vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Vision.started')
                # update status
                Vision.status = STARTED
                Vision.setAutoDraw(True)
            
            # if Vision is active this frame...
            if Vision.status == STARTED:
                # update params
                pass
            # *Siguente_stim* updates
            
            # if Siguente_stim is starting this frame...
            if Siguente_stim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Siguente_stim.frameNStart = frameN  # exact frame index
                Siguente_stim.tStart = t  # local t and not account for scr refresh
                Siguente_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Siguente_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Siguente_stim.started')
                # update status
                Siguente_stim.status = STARTED
                Siguente_stim.setAutoDraw(True)
            
            # if Siguente_stim is active this frame...
            if Siguente_stim.status == STARTED:
                # update params
                pass
                # check whether Siguente_stim has been pressed
                if Siguente_stim.isClicked:
                    if not Siguente_stim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        Siguente_stim.timesOn.append(Siguente_stim.buttonClock.getTime())
                        Siguente_stim.timesOff.append(Siguente_stim.buttonClock.getTime())
                    elif len(Siguente_stim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        Siguente_stim.timesOff[-1] = Siguente_stim.buttonClock.getTime()
                    if not Siguente_stim.wasClicked:
                        # end routine when Siguente_stim is clicked
                        continueRoutine = False
                    if not Siguente_stim.wasClicked:
                        # run callback code when Siguente_stim is clicked
                        Vision.rating
            # take note of whether Siguente_stim was clicked, so that next frame we know if clicks are new
            Siguente_stim.wasClicked = Siguente_stim.isClicked and Siguente_stim.status == STARTED
            # *No_se* updates
            
            # if No_se is starting this frame...
            if No_se.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                No_se.frameNStart = frameN  # exact frame index
                No_se.tStart = t  # local t and not account for scr refresh
                No_se.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(No_se, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'No_se.started')
                # update status
                No_se.status = STARTED
                No_se.setAutoDraw(True)
            
            # if No_se is active this frame...
            if No_se.status == STARTED:
                # update params
                pass
                # check whether No_se has been pressed
                if No_se.isClicked:
                    if not No_se.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        No_se.timesOn.append(No_se.buttonClock.getTime())
                        No_se.timesOff.append(No_se.buttonClock.getTime())
                    elif len(No_se.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        No_se.timesOff[-1] = No_se.buttonClock.getTime()
                    if not No_se.wasClicked:
                        # run callback code when No_se is clicked
                        pass
            # take note of whether No_se was clicked, so that next frame we know if clicks are new
            No_se.wasClicked = No_se.isClicked and No_se.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirEs_likert_spanComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirEs_likert_span" ---
        for thisComponent in SentirEs_likert_spanComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('SentirEs_likert_span.stopped', globalClock.getTime(format='float'))
        trials.addData('Audition.response', Audition.getRating())
        trials.addData('Audition.rt', Audition.getRT())
        trials.addData('Gustatory.response', Gustatory.getRating())
        trials.addData('Gustatory.rt', Gustatory.getRT())
        trials.addData('Haptic.response', Haptic.getRating())
        trials.addData('Haptic.rt', Haptic.getRT())
        trials.addData('Interoception.response', Interoception.getRating())
        trials.addData('Interoception.rt', Interoception.getRT())
        trials.addData('Olfaction.response', Olfaction.getRating())
        trials.addData('Olfaction.rt', Olfaction.getRT())
        trials.addData('Vision.response', Vision.getRating())
        trials.addData('Vision.rt', Vision.getRT())
        trials.addData('Siguente_stim.numClicks', Siguente_stim.numClicks)
        if Siguente_stim.numClicks:
           trials.addData('Siguente_stim.timesOn', Siguente_stim.timesOn)
           trials.addData('Siguente_stim.timesOff', Siguente_stim.timesOff)
        else:
           trials.addData('Siguente_stim.timesOn', "")
           trials.addData('Siguente_stim.timesOff', "")
        trials.addData('No_se.numClicks', No_se.numClicks)
        if No_se.numClicks:
           trials.addData('No_se.timesOn', No_se.timesOn)
           trials.addData('No_se.timesOff', No_se.timesOff)
        else:
           trials.addData('No_se.timesOn', "")
           trials.addData('No_se.timesOff', "")
        # the Routine "SentirEs_likert_span" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'trials'
    
    
    # --- Prepare to start Routine "trial" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('trial.started', globalClock.getTime(format='float'))
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # keep track of which components have finished
    trialComponents = [readingtext, key_resp]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "trial" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *readingtext* updates
        
        # if readingtext is starting this frame...
        if readingtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            readingtext.frameNStart = frameN  # exact frame index
            readingtext.tStart = t  # local t and not account for scr refresh
            readingtext.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(readingtext, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'readingtext.started')
            # update status
            readingtext.status = STARTED
            readingtext.setAutoDraw(True)
        
        # if readingtext is active this frame...
        if readingtext.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['y'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "trial" ---
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('trial.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
