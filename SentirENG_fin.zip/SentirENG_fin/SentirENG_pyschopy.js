/*************************** 
 * Sentireng_Pyschopy *
 ***************************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2024.2.1.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'SentirENG_pyschopy';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0,0,0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(warning3NGRoutineBegin());
flowScheduler.add(warning3NGRoutineEachFrame());
flowScheduler.add(warning3NGRoutineEnd());
flowScheduler.add(instructions3NGRoutineBegin());
flowScheduler.add(instructions3NGRoutineEachFrame());
flowScheduler.add(instructions3NGRoutineEnd());
const SentirENG19LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirENG19LoopBegin(SentirENG19LoopScheduler));
flowScheduler.add(SentirENG19LoopScheduler);
flowScheduler.add(SentirENG19LoopEnd);


flowScheduler.add(catch3NG1RoutineBegin());
flowScheduler.add(catch3NG1RoutineEachFrame());
flowScheduler.add(catch3NG1RoutineEnd());
const SentirENG45LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirENG45LoopBegin(SentirENG45LoopScheduler));
flowScheduler.add(SentirENG45LoopScheduler);
flowScheduler.add(SentirENG45LoopEnd);


flowScheduler.add(catch3NG2RoutineBegin());
flowScheduler.add(catch3NG2RoutineEachFrame());
flowScheduler.add(catch3NG2RoutineEnd());
flowScheduler.add(break3NGRoutineBegin());
flowScheduler.add(break3NGRoutineEachFrame());
flowScheduler.add(break3NGRoutineEnd());
const SentirENG72LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirENG72LoopBegin(SentirENG72LoopScheduler));
flowScheduler.add(SentirENG72LoopScheduler);
flowScheduler.add(SentirENG72LoopEnd);


flowScheduler.add(catch3NG3RoutineBegin());
flowScheduler.add(catch3NG3RoutineEachFrame());
flowScheduler.add(catch3NG3RoutineEnd());
const SenitENG80LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SenitENG80LoopBegin(SenitENG80LoopScheduler));
flowScheduler.add(SenitENG80LoopScheduler);
flowScheduler.add(SenitENG80LoopEnd);


flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(quitPsychoJS, 'Thank you for your patience.', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, 'Thank you for your patience.', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
    {'name': 'stimENG/Stimuli3ENG19.csv', 'path': 'stimENG/Stimuli3ENG19.csv'},
    {'name': 'stimENG/Stimuli3ENG45.csv', 'path': 'stimENG/Stimuli3ENG45.csv'},
    {'name': 'stimENG/Stimuli3ENG72.csv', 'path': 'stimENG/Stimuli3ENG72.csv'},
    {'name': 'stimENG/Stimuli3ENG80.csv', 'path': 'stimENG/Stimuli3ENG80.csv'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.INFO);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2024.2.1';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var warning3NGClock;
var warning3NGtext;
var next3NG;
var instructions3NGClock;
var instructions3NGtext;
var next3NGinstr;
var SentirENG_psychopyClock;
var question;
var stimuli;
var audition;
var taste;
var haptic;
var olfaction;
var vision;
var interoception;
var auditionslider;
var tasteslider;
var hapticslider;
var olfactionslider;
var visionslider;
var interoceptionslider;
var next3NGstim;
var donotknow3NG;
var catch3NG1Clock;
var catch3NGanimal;
var Bear;
var Fish;
var Bird;
var catch3NG2Clock;
var catch3NGmath;
var fifthteen;
var seventytwo;
var onehundred;
var break3NGClock;
var SentirENGbreak;
var next3NGbreak;
var catch3NG3Clock;
var catch3NGfruit;
var sandwitch;
var coliflower;
var apple;
var endClock;
var end_y;
var end3NG;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "warning3NG"
  warning3NGClock = new util.Clock();
  warning3NGtext = new visual.TextStim({
    win: psychoJS.window,
    name: 'warning3NGtext',
    text: 'WARNING\nThis study uses a wide range of words that are encountered in everyday life. Very occasionally, this means that some words may be offensive or explicit. If you feel that being exposed to such words will be distressing for you, we would like to remind you that you are free to end your participation in the study now or at any time you choose.\nIf you wish to continue, please press the "NEXT" button',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next3NG = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next3NG',
    text: 'Next',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next3NG.clock = new util.Clock();
  
  // Initialize components for Routine "instructions3NG"
  instructions3NGClock = new util.Clock();
  instructions3NGtext = new visual.TextStim({
    win: psychoJS.window,
    name: 'instructions3NGtext',
    text: 'INSTRUCTIONS\nYou will be asked to rate how much you experience everyday concepts using six different perceptual senses. There are no right or wrong answers so please use your own judgement. The rating scale runs from 0 (not experienced at all with that sense) to 5 (experienced greatly with that sense). Click on a number to select a rating for each scale, then click on the Next button to move on the next item.\nIf you do not know the meaning of a word, just check the “Don’t know the meaning of this word" box and click "NEXT" to move onto the next item.',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next3NGinstr = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next3NGinstr',
    text: 'Next',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next3NGinstr.clock = new util.Clock();
  
  // Initialize components for Routine "SentirENG_psychopy"
  SentirENG_psychopyClock = new util.Clock();
  question = new visual.TextStim({
    win: psychoJS.window,
    name: 'question',
    text: 'To what extent do you experience',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.4), 0.4], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  stimuli = new visual.TextStim({
    win: psychoJS.window,
    name: 'stimuli',
    text: '',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.4), 0.3], draggable: false, height: 0.045,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -1.0 
  });
  
  audition = new visual.TextStim({
    win: psychoJS.window,
    name: 'audition',
    text: 'by hearing',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0.2], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -2.0 
  });
  
  taste = new visual.TextStim({
    win: psychoJS.window,
    name: 'taste',
    text: 'by tasting',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0.1], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -3.0 
  });
  
  haptic = new visual.TextStim({
    win: psychoJS.window,
    name: 'haptic',
    text: 'by feeling through touch',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -4.0 
  });
  
  olfaction = new visual.TextStim({
    win: psychoJS.window,
    name: 'olfaction',
    text: 'by smelling',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -5.0 
  });
  
  vision = new visual.TextStim({
    win: psychoJS.window,
    name: 'vision',
    text: 'by seeing',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -6.0 
  });
  
  interoception = new visual.TextStim({
    win: psychoJS.window,
    name: 'interoception',
    text: 'by internal bodidly\nsensations',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.3)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -7.0 
  });
  
  auditionslider = new visual.Slider({
    win: psychoJS.window, name: 'auditionslider',
    startValue: 0,
    size: [0.7, 0.05], pos: [0, 0.2], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -8, 
    flip: false,
  });
  
  tasteslider = new visual.Slider({
    win: psychoJS.window, name: 'tasteslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, 0.1], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -9, 
    flip: false,
  });
  
  hapticslider = new visual.Slider({
    win: psychoJS.window, name: 'hapticslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, 0], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -10, 
    flip: false,
  });
  
  olfactionslider = new visual.Slider({
    win: psychoJS.window, name: 'olfactionslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.1)], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -11, 
    flip: false,
  });
  
  visionslider = new visual.Slider({
    win: psychoJS.window, name: 'visionslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.2)], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -12, 
    flip: false,
  });
  
  interoceptionslider = new visual.Slider({
    win: psychoJS.window, name: 'interoceptionslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.3)], ori: 0.0, units: 'height',
    labels: ["nothing", "totally"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -13, 
    flip: false,
  });
  
  next3NGstim = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next3NGstim',
    text: 'Next',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -14
  });
  next3NGstim.clock = new util.Clock();
  
  donotknow3NG = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'donotknow3NG',
    text: 'do not know this word',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, 0.3],
    letterHeight: 0.03,
    size: [0.4, 0.2],
    ori: 0.0
    ,
    depth: -15
  });
  donotknow3NG.clock = new util.Clock();
  
  // Initialize components for Routine "catch3NG1"
  catch3NG1Clock = new util.Clock();
  catch3NGanimal = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch3NGanimal',
    text: 'Which one of these animals flies?',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  Bear = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Bear',
    text: 'Bear',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  Bear.clock = new util.Clock();
  
  Fish = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Fish',
    text: 'Fish',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  Fish.clock = new util.Clock();
  
  Bird = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Bird',
    text: 'Bird',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  Bird.clock = new util.Clock();
  
  // Initialize components for Routine "catch3NG2"
  catch3NG2Clock = new util.Clock();
  catch3NGmath = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch3NGmath',
    text: 'What is 5 x 3?',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  fifthteen = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'fifthteen',
    text: '15',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  fifthteen.clock = new util.Clock();
  
  seventytwo = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'seventytwo',
    text: '72',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  seventytwo.clock = new util.Clock();
  
  onehundred = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'onehundred',
    text: '100',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  onehundred.clock = new util.Clock();
  
  // Initialize components for Routine "break3NG"
  break3NGClock = new util.Clock();
  SentirENGbreak = new visual.TextStim({
    win: psychoJS.window,
    name: 'SentirENGbreak',
    text: 'If you need, you can take a short break now. Push "Next" to continue the experiment',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next3NGbreak = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next3NGbreak',
    text: 'Next',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next3NGbreak.clock = new util.Clock();
  
  // Initialize components for Routine "catch3NG3"
  catch3NG3Clock = new util.Clock();
  catch3NGfruit = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch3NGfruit',
    text: 'Which of these is a fruit?',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  sandwitch = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'sandwitch',
    text: 'sandwitch',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  sandwitch.clock = new util.Clock();
  
  coliflower = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'coliflower',
    text: 'cauliflower',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  coliflower.clock = new util.Clock();
  
  apple = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'apple',
    text: 'apple',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  apple.clock = new util.Clock();
  
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  end_y = new visual.TextStim({
    win: psychoJS.window,
    name: 'end_y',
    text: 'Thank you for your participation! To finish the experiment click end. ',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  end3NG = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'end3NG',
    text: 'fin',
    fillColor: [(- 1.0), 0.0902, 0.0902],
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.05,
    size: [0.5, 0.5],
    ori: 0.0
    ,
    depth: -1
  });
  end3NG.clock = new util.Clock();
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var warning3NGMaxDurationReached;
var warning3NGMaxDuration;
var warning3NGComponents;
function warning3NGRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'warning3NG' ---
    t = 0;
    warning3NGClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    warning3NGMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next3NG to account for continued clicks & clear times on/off
    next3NG.reset()
    psychoJS.experiment.addData('warning3NG.started', globalClock.getTime());
    warning3NGMaxDuration = null
    // keep track of which components have finished
    warning3NGComponents = [];
    warning3NGComponents.push(warning3NGtext);
    warning3NGComponents.push(next3NG);
    
    for (const thisComponent of warning3NGComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function warning3NGRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'warning3NG' ---
    // get current time
    t = warning3NGClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *warning3NGtext* updates
    if (t >= 0.0 && warning3NGtext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      warning3NGtext.tStart = t;  // (not accounting for frame time here)
      warning3NGtext.frameNStart = frameN;  // exact frame index
      
      warning3NGtext.setAutoDraw(true);
    }
    
    
    // *next3NG* updates
    if (t >= 0 && next3NG.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next3NG.tStart = t;  // (not accounting for frame time here)
      next3NG.frameNStart = frameN;  // exact frame index
      
      next3NG.setAutoDraw(true);
    }
    
    if (next3NG.status === PsychoJS.Status.STARTED) {
      // check whether next3NG has been pressed
      if (next3NG.isClicked) {
        if (!next3NG.wasClicked) {
          // store time of first click
          next3NG.timesOn.push(next3NG.clock.getTime());
          // store time clicked until
          next3NG.timesOff.push(next3NG.clock.getTime());
        } else {
          // update time clicked until;
          next3NG.timesOff[next3NG.timesOff.length - 1] = next3NG.clock.getTime();
        }
        if (!next3NG.wasClicked) {
          // end routine when next3NG is clicked
          continueRoutine = false;
          
        }
        // if next3NG is still clicked next frame, it is not a new click
        next3NG.wasClicked = true;
      } else {
        // if next3NG is clicked next frame, it is a new click
        next3NG.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next3NG hasn't started / has finished
      next3NG.clock.reset();
      // if next3NG is clicked next frame, it is a new click
      next3NG.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of warning3NGComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function warning3NGRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'warning3NG' ---
    for (const thisComponent of warning3NGComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('warning3NG.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next3NG.numClicks', next3NG.numClicks);
    psychoJS.experiment.addData('next3NG.timesOn', next3NG.timesOn);
    psychoJS.experiment.addData('next3NG.timesOff', next3NG.timesOff);
    // the Routine "warning3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var instructions3NGMaxDurationReached;
var instructions3NGMaxDuration;
var instructions3NGComponents;
function instructions3NGRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions3NG' ---
    t = 0;
    instructions3NGClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    instructions3NGMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next3NGinstr to account for continued clicks & clear times on/off
    next3NGinstr.reset()
    psychoJS.experiment.addData('instructions3NG.started', globalClock.getTime());
    instructions3NGMaxDuration = null
    // keep track of which components have finished
    instructions3NGComponents = [];
    instructions3NGComponents.push(instructions3NGtext);
    instructions3NGComponents.push(next3NGinstr);
    
    for (const thisComponent of instructions3NGComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instructions3NGRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions3NG' ---
    // get current time
    t = instructions3NGClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instructions3NGtext* updates
    if (t >= 0.0 && instructions3NGtext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instructions3NGtext.tStart = t;  // (not accounting for frame time here)
      instructions3NGtext.frameNStart = frameN;  // exact frame index
      
      instructions3NGtext.setAutoDraw(true);
    }
    
    
    // *next3NGinstr* updates
    if (t >= 0 && next3NGinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next3NGinstr.tStart = t;  // (not accounting for frame time here)
      next3NGinstr.frameNStart = frameN;  // exact frame index
      
      next3NGinstr.setAutoDraw(true);
    }
    
    if (next3NGinstr.status === PsychoJS.Status.STARTED) {
      // check whether next3NGinstr has been pressed
      if (next3NGinstr.isClicked) {
        if (!next3NGinstr.wasClicked) {
          // store time of first click
          next3NGinstr.timesOn.push(next3NGinstr.clock.getTime());
          // store time clicked until
          next3NGinstr.timesOff.push(next3NGinstr.clock.getTime());
        } else {
          // update time clicked until;
          next3NGinstr.timesOff[next3NGinstr.timesOff.length - 1] = next3NGinstr.clock.getTime();
        }
        if (!next3NGinstr.wasClicked) {
          // end routine when next3NGinstr is clicked
          continueRoutine = false;
          
        }
        // if next3NGinstr is still clicked next frame, it is not a new click
        next3NGinstr.wasClicked = true;
      } else {
        // if next3NGinstr is clicked next frame, it is a new click
        next3NGinstr.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next3NGinstr hasn't started / has finished
      next3NGinstr.clock.reset();
      // if next3NGinstr is clicked next frame, it is a new click
      next3NGinstr.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructions3NGComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructions3NGRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions3NG' ---
    for (const thisComponent of instructions3NGComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('instructions3NG.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next3NGinstr.numClicks', next3NGinstr.numClicks);
    psychoJS.experiment.addData('next3NGinstr.timesOn', next3NGinstr.timesOn);
    psychoJS.experiment.addData('next3NGinstr.timesOff', next3NGinstr.timesOff);
    // the Routine "instructions3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SentirENG19;
function SentirENG19LoopBegin(SentirENG19LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirENG19 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimENG/Stimuli3ENG19.csv',
      seed: undefined, name: 'SentirENG19'
    });
    psychoJS.experiment.addLoop(SentirENG19); // add the loop to the experiment
    currentLoop = SentirENG19;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirENG19 of SentirENG19) {
      snapshot = SentirENG19.getSnapshot();
      SentirENG19LoopScheduler.add(importConditions(snapshot));
      SentirENG19LoopScheduler.add(SentirENG_psychopyRoutineBegin(snapshot));
      SentirENG19LoopScheduler.add(SentirENG_psychopyRoutineEachFrame());
      SentirENG19LoopScheduler.add(SentirENG_psychopyRoutineEnd(snapshot));
      SentirENG19LoopScheduler.add(SentirENG19LoopEndIteration(SentirENG19LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirENG19LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirENG19);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirENG19LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirENG45;
function SentirENG45LoopBegin(SentirENG45LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirENG45 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimENG/Stimuli3ENG45.csv',
      seed: undefined, name: 'SentirENG45'
    });
    psychoJS.experiment.addLoop(SentirENG45); // add the loop to the experiment
    currentLoop = SentirENG45;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirENG45 of SentirENG45) {
      snapshot = SentirENG45.getSnapshot();
      SentirENG45LoopScheduler.add(importConditions(snapshot));
      SentirENG45LoopScheduler.add(SentirENG_psychopyRoutineBegin(snapshot));
      SentirENG45LoopScheduler.add(SentirENG_psychopyRoutineEachFrame());
      SentirENG45LoopScheduler.add(SentirENG_psychopyRoutineEnd(snapshot));
      SentirENG45LoopScheduler.add(SentirENG45LoopEndIteration(SentirENG45LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirENG45LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirENG45);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirENG45LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirENG72;
function SentirENG72LoopBegin(SentirENG72LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirENG72 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimENG/Stimuli3ENG72.csv',
      seed: undefined, name: 'SentirENG72'
    });
    psychoJS.experiment.addLoop(SentirENG72); // add the loop to the experiment
    currentLoop = SentirENG72;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirENG72 of SentirENG72) {
      snapshot = SentirENG72.getSnapshot();
      SentirENG72LoopScheduler.add(importConditions(snapshot));
      SentirENG72LoopScheduler.add(SentirENG_psychopyRoutineBegin(snapshot));
      SentirENG72LoopScheduler.add(SentirENG_psychopyRoutineEachFrame());
      SentirENG72LoopScheduler.add(SentirENG_psychopyRoutineEnd(snapshot));
      SentirENG72LoopScheduler.add(SentirENG72LoopEndIteration(SentirENG72LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirENG72LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirENG72);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirENG72LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SenitENG80;
function SenitENG80LoopBegin(SenitENG80LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SenitENG80 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimENG/Stimuli3ENG80.csv',
      seed: undefined, name: 'SenitENG80'
    });
    psychoJS.experiment.addLoop(SenitENG80); // add the loop to the experiment
    currentLoop = SenitENG80;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSenitENG80 of SenitENG80) {
      snapshot = SenitENG80.getSnapshot();
      SenitENG80LoopScheduler.add(importConditions(snapshot));
      SenitENG80LoopScheduler.add(SentirENG_psychopyRoutineBegin(snapshot));
      SenitENG80LoopScheduler.add(SentirENG_psychopyRoutineEachFrame());
      SenitENG80LoopScheduler.add(SentirENG_psychopyRoutineEnd(snapshot));
      SenitENG80LoopScheduler.add(SenitENG80LoopEndIteration(SenitENG80LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SenitENG80LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SenitENG80);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SenitENG80LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirENG_psychopyMaxDurationReached;
var SentirENG_psychopyMaxDuration;
var SentirENG_psychopyComponents;
function SentirENG_psychopyRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SentirENG_psychopy' ---
    t = 0;
    SentirENG_psychopyClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    SentirENG_psychopyMaxDurationReached = false;
    // update component parameters for each repeat
    stimuli.setText(Word);
    auditionslider.reset()
    tasteslider.reset()
    hapticslider.reset()
    olfactionslider.reset()
    visionslider.reset()
    interoceptionslider.reset()
    // reset next3NGstim to account for continued clicks & clear times on/off
    next3NGstim.reset()
    // reset donotknow3NG to account for continued clicks & clear times on/off
    donotknow3NG.reset()
    psychoJS.experiment.addData('SentirENG_psychopy.started', globalClock.getTime());
    SentirENG_psychopyMaxDuration = null
    // keep track of which components have finished
    SentirENG_psychopyComponents = [];
    SentirENG_psychopyComponents.push(question);
    SentirENG_psychopyComponents.push(stimuli);
    SentirENG_psychopyComponents.push(audition);
    SentirENG_psychopyComponents.push(taste);
    SentirENG_psychopyComponents.push(haptic);
    SentirENG_psychopyComponents.push(olfaction);
    SentirENG_psychopyComponents.push(vision);
    SentirENG_psychopyComponents.push(interoception);
    SentirENG_psychopyComponents.push(auditionslider);
    SentirENG_psychopyComponents.push(tasteslider);
    SentirENG_psychopyComponents.push(hapticslider);
    SentirENG_psychopyComponents.push(olfactionslider);
    SentirENG_psychopyComponents.push(visionslider);
    SentirENG_psychopyComponents.push(interoceptionslider);
    SentirENG_psychopyComponents.push(next3NGstim);
    SentirENG_psychopyComponents.push(donotknow3NG);
    
    for (const thisComponent of SentirENG_psychopyComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function SentirENG_psychopyRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'SentirENG_psychopy' ---
    // get current time
    t = SentirENG_psychopyClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *question* updates
    if (t >= 0.0 && question.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      question.tStart = t;  // (not accounting for frame time here)
      question.frameNStart = frameN;  // exact frame index
      
      question.setAutoDraw(true);
    }
    
    
    // *stimuli* updates
    if (t >= 0.0 && stimuli.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      stimuli.tStart = t;  // (not accounting for frame time here)
      stimuli.frameNStart = frameN;  // exact frame index
      
      stimuli.setAutoDraw(true);
    }
    
    
    // *audition* updates
    if (t >= 0.0 && audition.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      audition.tStart = t;  // (not accounting for frame time here)
      audition.frameNStart = frameN;  // exact frame index
      
      audition.setAutoDraw(true);
    }
    
    
    // *taste* updates
    if (t >= 0.0 && taste.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      taste.tStart = t;  // (not accounting for frame time here)
      taste.frameNStart = frameN;  // exact frame index
      
      taste.setAutoDraw(true);
    }
    
    
    // *haptic* updates
    if (t >= 0.0 && haptic.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      haptic.tStart = t;  // (not accounting for frame time here)
      haptic.frameNStart = frameN;  // exact frame index
      
      haptic.setAutoDraw(true);
    }
    
    
    // *olfaction* updates
    if (t >= 0.0 && olfaction.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      olfaction.tStart = t;  // (not accounting for frame time here)
      olfaction.frameNStart = frameN;  // exact frame index
      
      olfaction.setAutoDraw(true);
    }
    
    
    // *vision* updates
    if (t >= 0.0 && vision.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vision.tStart = t;  // (not accounting for frame time here)
      vision.frameNStart = frameN;  // exact frame index
      
      vision.setAutoDraw(true);
    }
    
    
    // *interoception* updates
    if (t >= 0.0 && interoception.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      interoception.tStart = t;  // (not accounting for frame time here)
      interoception.frameNStart = frameN;  // exact frame index
      
      interoception.setAutoDraw(true);
    }
    
    
    // *auditionslider* updates
    if (t >= 0.0 && auditionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      auditionslider.tStart = t;  // (not accounting for frame time here)
      auditionslider.frameNStart = frameN;  // exact frame index
      
      auditionslider.setAutoDraw(true);
    }
    
    
    // *tasteslider* updates
    if (t >= 0.0 && tasteslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      tasteslider.tStart = t;  // (not accounting for frame time here)
      tasteslider.frameNStart = frameN;  // exact frame index
      
      tasteslider.setAutoDraw(true);
    }
    
    
    // *hapticslider* updates
    if (t >= 0.0 && hapticslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      hapticslider.tStart = t;  // (not accounting for frame time here)
      hapticslider.frameNStart = frameN;  // exact frame index
      
      hapticslider.setAutoDraw(true);
    }
    
    
    // *olfactionslider* updates
    if (t >= 0.0 && olfactionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      olfactionslider.tStart = t;  // (not accounting for frame time here)
      olfactionslider.frameNStart = frameN;  // exact frame index
      
      olfactionslider.setAutoDraw(true);
    }
    
    
    // *visionslider* updates
    if (t >= 0.0 && visionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      visionslider.tStart = t;  // (not accounting for frame time here)
      visionslider.frameNStart = frameN;  // exact frame index
      
      visionslider.setAutoDraw(true);
    }
    
    
    // *interoceptionslider* updates
    if (t >= 0.0 && interoceptionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      interoceptionslider.tStart = t;  // (not accounting for frame time here)
      interoceptionslider.frameNStart = frameN;  // exact frame index
      
      interoceptionslider.setAutoDraw(true);
    }
    
    
    // *next3NGstim* updates
    if (t >= 0 && next3NGstim.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next3NGstim.tStart = t;  // (not accounting for frame time here)
      next3NGstim.frameNStart = frameN;  // exact frame index
      
      next3NGstim.setAutoDraw(true);
    }
    
    if (next3NGstim.status === PsychoJS.Status.STARTED) {
      // check whether next3NGstim has been pressed
      if (next3NGstim.isClicked) {
        if (!next3NGstim.wasClicked) {
          // store time of first click
          next3NGstim.timesOn.push(next3NGstim.clock.getTime());
          // store time clicked until
          next3NGstim.timesOff.push(next3NGstim.clock.getTime());
        } else {
          // update time clicked until;
          next3NGstim.timesOff[next3NGstim.timesOff.length - 1] = next3NGstim.clock.getTime();
        }
        if (!next3NGstim.wasClicked) {
          // end routine when next3NGstim is clicked
          continueRoutine = false;
          
        }
        // if next3NGstim is still clicked next frame, it is not a new click
        next3NGstim.wasClicked = true;
      } else {
        // if next3NGstim is clicked next frame, it is a new click
        next3NGstim.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next3NGstim hasn't started / has finished
      next3NGstim.clock.reset();
      // if next3NGstim is clicked next frame, it is a new click
      next3NGstim.wasClicked = false;
    }
    
    // *donotknow3NG* updates
    if (t >= 0 && donotknow3NG.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      donotknow3NG.tStart = t;  // (not accounting for frame time here)
      donotknow3NG.frameNStart = frameN;  // exact frame index
      
      donotknow3NG.setAutoDraw(true);
    }
    
    if (donotknow3NG.status === PsychoJS.Status.STARTED) {
      // check whether donotknow3NG has been pressed
      if (donotknow3NG.isClicked) {
        if (!donotknow3NG.wasClicked) {
          // store time of first click
          donotknow3NG.timesOn.push(donotknow3NG.clock.getTime());
          // store time clicked until
          donotknow3NG.timesOff.push(donotknow3NG.clock.getTime());
        } else {
          // update time clicked until;
          donotknow3NG.timesOff[donotknow3NG.timesOff.length - 1] = donotknow3NG.clock.getTime();
        }
        if (!donotknow3NG.wasClicked) {
          // end routine when donotknow3NG is clicked
          continueRoutine = false;
          
        }
        // if donotknow3NG is still clicked next frame, it is not a new click
        donotknow3NG.wasClicked = true;
      } else {
        // if donotknow3NG is clicked next frame, it is a new click
        donotknow3NG.wasClicked = false;
      }
    } else {
      // keep clock at 0 if donotknow3NG hasn't started / has finished
      donotknow3NG.clock.reset();
      // if donotknow3NG is clicked next frame, it is a new click
      donotknow3NG.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of SentirENG_psychopyComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function SentirENG_psychopyRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SentirENG_psychopy' ---
    for (const thisComponent of SentirENG_psychopyComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('SentirENG_psychopy.stopped', globalClock.getTime());
    psychoJS.experiment.addData('auditionslider.response', auditionslider.getRating());
    psychoJS.experiment.addData('auditionslider.rt', auditionslider.getRT());
    psychoJS.experiment.addData('tasteslider.response', tasteslider.getRating());
    psychoJS.experiment.addData('tasteslider.rt', tasteslider.getRT());
    psychoJS.experiment.addData('hapticslider.response', hapticslider.getRating());
    psychoJS.experiment.addData('hapticslider.rt', hapticslider.getRT());
    psychoJS.experiment.addData('olfactionslider.response', olfactionslider.getRating());
    psychoJS.experiment.addData('olfactionslider.rt', olfactionslider.getRT());
    psychoJS.experiment.addData('visionslider.response', visionslider.getRating());
    psychoJS.experiment.addData('visionslider.rt', visionslider.getRT());
    psychoJS.experiment.addData('interoceptionslider.response', interoceptionslider.getRating());
    psychoJS.experiment.addData('interoceptionslider.rt', interoceptionslider.getRT());
    psychoJS.experiment.addData('next3NGstim.numClicks', next3NGstim.numClicks);
    psychoJS.experiment.addData('next3NGstim.timesOn', next3NGstim.timesOn);
    psychoJS.experiment.addData('next3NGstim.timesOff', next3NGstim.timesOff);
    psychoJS.experiment.addData('donotknow3NG.numClicks', donotknow3NG.numClicks);
    psychoJS.experiment.addData('donotknow3NG.timesOn', donotknow3NG.timesOn);
    psychoJS.experiment.addData('donotknow3NG.timesOff', donotknow3NG.timesOff);
    // the Routine "SentirENG_psychopy" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch3NG1MaxDurationReached;
var catch3NG1MaxDuration;
var catch3NG1Components;
function catch3NG1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch3NG1' ---
    t = 0;
    catch3NG1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch3NG1MaxDurationReached = false;
    // update component parameters for each repeat
    // reset Bear to account for continued clicks & clear times on/off
    Bear.reset()
    // reset Fish to account for continued clicks & clear times on/off
    Fish.reset()
    // reset Bird to account for continued clicks & clear times on/off
    Bird.reset()
    psychoJS.experiment.addData('catch3NG1.started', globalClock.getTime());
    catch3NG1MaxDuration = null
    // keep track of which components have finished
    catch3NG1Components = [];
    catch3NG1Components.push(catch3NGanimal);
    catch3NG1Components.push(Bear);
    catch3NG1Components.push(Fish);
    catch3NG1Components.push(Bird);
    
    for (const thisComponent of catch3NG1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch3NG1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch3NG1' ---
    // get current time
    t = catch3NG1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch3NGanimal* updates
    if (t >= 0.0 && catch3NGanimal.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch3NGanimal.tStart = t;  // (not accounting for frame time here)
      catch3NGanimal.frameNStart = frameN;  // exact frame index
      
      catch3NGanimal.setAutoDraw(true);
    }
    
    
    // *Bear* updates
    if (t >= 0 && Bear.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Bear.tStart = t;  // (not accounting for frame time here)
      Bear.frameNStart = frameN;  // exact frame index
      
      Bear.setAutoDraw(true);
    }
    
    if (Bear.status === PsychoJS.Status.STARTED) {
      // check whether Bear has been pressed
      if (Bear.isClicked) {
        if (!Bear.wasClicked) {
          // store time of first click
          Bear.timesOn.push(Bear.clock.getTime());
          // store time clicked until
          Bear.timesOff.push(Bear.clock.getTime());
        } else {
          // update time clicked until;
          Bear.timesOff[Bear.timesOff.length - 1] = Bear.clock.getTime();
        }
        if (!Bear.wasClicked) {
          // end routine when Bear is clicked
          continueRoutine = false;
          
        }
        // if Bear is still clicked next frame, it is not a new click
        Bear.wasClicked = true;
      } else {
        // if Bear is clicked next frame, it is a new click
        Bear.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Bear hasn't started / has finished
      Bear.clock.reset();
      // if Bear is clicked next frame, it is a new click
      Bear.wasClicked = false;
    }
    
    // *Fish* updates
    if (t >= 0 && Fish.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Fish.tStart = t;  // (not accounting for frame time here)
      Fish.frameNStart = frameN;  // exact frame index
      
      Fish.setAutoDraw(true);
    }
    
    if (Fish.status === PsychoJS.Status.STARTED) {
      // check whether Fish has been pressed
      if (Fish.isClicked) {
        if (!Fish.wasClicked) {
          // store time of first click
          Fish.timesOn.push(Fish.clock.getTime());
          // store time clicked until
          Fish.timesOff.push(Fish.clock.getTime());
        } else {
          // update time clicked until;
          Fish.timesOff[Fish.timesOff.length - 1] = Fish.clock.getTime();
        }
        if (!Fish.wasClicked) {
          // end routine when Fish is clicked
          continueRoutine = false;
          
        }
        // if Fish is still clicked next frame, it is not a new click
        Fish.wasClicked = true;
      } else {
        // if Fish is clicked next frame, it is a new click
        Fish.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Fish hasn't started / has finished
      Fish.clock.reset();
      // if Fish is clicked next frame, it is a new click
      Fish.wasClicked = false;
    }
    
    // *Bird* updates
    if (t >= 0 && Bird.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Bird.tStart = t;  // (not accounting for frame time here)
      Bird.frameNStart = frameN;  // exact frame index
      
      Bird.setAutoDraw(true);
    }
    
    if (Bird.status === PsychoJS.Status.STARTED) {
      // check whether Bird has been pressed
      if (Bird.isClicked) {
        if (!Bird.wasClicked) {
          // store time of first click
          Bird.timesOn.push(Bird.clock.getTime());
          // store time clicked until
          Bird.timesOff.push(Bird.clock.getTime());
        } else {
          // update time clicked until;
          Bird.timesOff[Bird.timesOff.length - 1] = Bird.clock.getTime();
        }
        if (!Bird.wasClicked) {
          // end routine when Bird is clicked
          continueRoutine = false;
          
        }
        // if Bird is still clicked next frame, it is not a new click
        Bird.wasClicked = true;
      } else {
        // if Bird is clicked next frame, it is a new click
        Bird.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Bird hasn't started / has finished
      Bird.clock.reset();
      // if Bird is clicked next frame, it is a new click
      Bird.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch3NG1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch3NG1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch3NG1' ---
    for (const thisComponent of catch3NG1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch3NG1.stopped', globalClock.getTime());
    psychoJS.experiment.addData('Bear.numClicks', Bear.numClicks);
    psychoJS.experiment.addData('Bear.timesOn', Bear.timesOn);
    psychoJS.experiment.addData('Bear.timesOff', Bear.timesOff);
    psychoJS.experiment.addData('Fish.numClicks', Fish.numClicks);
    psychoJS.experiment.addData('Fish.timesOn', Fish.timesOn);
    psychoJS.experiment.addData('Fish.timesOff', Fish.timesOff);
    psychoJS.experiment.addData('Bird.numClicks', Bird.numClicks);
    psychoJS.experiment.addData('Bird.timesOn', Bird.timesOn);
    psychoJS.experiment.addData('Bird.timesOff', Bird.timesOff);
    // the Routine "catch3NG1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch3NG2MaxDurationReached;
var catch3NG2MaxDuration;
var catch3NG2Components;
function catch3NG2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch3NG2' ---
    t = 0;
    catch3NG2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch3NG2MaxDurationReached = false;
    // update component parameters for each repeat
    // reset fifthteen to account for continued clicks & clear times on/off
    fifthteen.reset()
    // reset seventytwo to account for continued clicks & clear times on/off
    seventytwo.reset()
    // reset onehundred to account for continued clicks & clear times on/off
    onehundred.reset()
    psychoJS.experiment.addData('catch3NG2.started', globalClock.getTime());
    catch3NG2MaxDuration = null
    // keep track of which components have finished
    catch3NG2Components = [];
    catch3NG2Components.push(catch3NGmath);
    catch3NG2Components.push(fifthteen);
    catch3NG2Components.push(seventytwo);
    catch3NG2Components.push(onehundred);
    
    for (const thisComponent of catch3NG2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch3NG2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch3NG2' ---
    // get current time
    t = catch3NG2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch3NGmath* updates
    if (t >= 0.0 && catch3NGmath.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch3NGmath.tStart = t;  // (not accounting for frame time here)
      catch3NGmath.frameNStart = frameN;  // exact frame index
      
      catch3NGmath.setAutoDraw(true);
    }
    
    
    // *fifthteen* updates
    if (t >= 0 && fifthteen.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fifthteen.tStart = t;  // (not accounting for frame time here)
      fifthteen.frameNStart = frameN;  // exact frame index
      
      fifthteen.setAutoDraw(true);
    }
    
    if (fifthteen.status === PsychoJS.Status.STARTED) {
      // check whether fifthteen has been pressed
      if (fifthteen.isClicked) {
        if (!fifthteen.wasClicked) {
          // store time of first click
          fifthteen.timesOn.push(fifthteen.clock.getTime());
          // store time clicked until
          fifthteen.timesOff.push(fifthteen.clock.getTime());
        } else {
          // update time clicked until;
          fifthteen.timesOff[fifthteen.timesOff.length - 1] = fifthteen.clock.getTime();
        }
        if (!fifthteen.wasClicked) {
          // end routine when fifthteen is clicked
          continueRoutine = false;
          
        }
        // if fifthteen is still clicked next frame, it is not a new click
        fifthteen.wasClicked = true;
      } else {
        // if fifthteen is clicked next frame, it is a new click
        fifthteen.wasClicked = false;
      }
    } else {
      // keep clock at 0 if fifthteen hasn't started / has finished
      fifthteen.clock.reset();
      // if fifthteen is clicked next frame, it is a new click
      fifthteen.wasClicked = false;
    }
    
    // *seventytwo* updates
    if (t >= 0 && seventytwo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      seventytwo.tStart = t;  // (not accounting for frame time here)
      seventytwo.frameNStart = frameN;  // exact frame index
      
      seventytwo.setAutoDraw(true);
    }
    
    if (seventytwo.status === PsychoJS.Status.STARTED) {
      // check whether seventytwo has been pressed
      if (seventytwo.isClicked) {
        if (!seventytwo.wasClicked) {
          // store time of first click
          seventytwo.timesOn.push(seventytwo.clock.getTime());
          // store time clicked until
          seventytwo.timesOff.push(seventytwo.clock.getTime());
        } else {
          // update time clicked until;
          seventytwo.timesOff[seventytwo.timesOff.length - 1] = seventytwo.clock.getTime();
        }
        if (!seventytwo.wasClicked) {
          // end routine when seventytwo is clicked
          continueRoutine = false;
          
        }
        // if seventytwo is still clicked next frame, it is not a new click
        seventytwo.wasClicked = true;
      } else {
        // if seventytwo is clicked next frame, it is a new click
        seventytwo.wasClicked = false;
      }
    } else {
      // keep clock at 0 if seventytwo hasn't started / has finished
      seventytwo.clock.reset();
      // if seventytwo is clicked next frame, it is a new click
      seventytwo.wasClicked = false;
    }
    
    // *onehundred* updates
    if (t >= 0 && onehundred.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      onehundred.tStart = t;  // (not accounting for frame time here)
      onehundred.frameNStart = frameN;  // exact frame index
      
      onehundred.setAutoDraw(true);
    }
    
    if (onehundred.status === PsychoJS.Status.STARTED) {
      // check whether onehundred has been pressed
      if (onehundred.isClicked) {
        if (!onehundred.wasClicked) {
          // store time of first click
          onehundred.timesOn.push(onehundred.clock.getTime());
          // store time clicked until
          onehundred.timesOff.push(onehundred.clock.getTime());
        } else {
          // update time clicked until;
          onehundred.timesOff[onehundred.timesOff.length - 1] = onehundred.clock.getTime();
        }
        if (!onehundred.wasClicked) {
          // end routine when onehundred is clicked
          continueRoutine = false;
          
        }
        // if onehundred is still clicked next frame, it is not a new click
        onehundred.wasClicked = true;
      } else {
        // if onehundred is clicked next frame, it is a new click
        onehundred.wasClicked = false;
      }
    } else {
      // keep clock at 0 if onehundred hasn't started / has finished
      onehundred.clock.reset();
      // if onehundred is clicked next frame, it is a new click
      onehundred.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch3NG2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch3NG2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch3NG2' ---
    for (const thisComponent of catch3NG2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch3NG2.stopped', globalClock.getTime());
    psychoJS.experiment.addData('fifthteen.numClicks', fifthteen.numClicks);
    psychoJS.experiment.addData('fifthteen.timesOn', fifthteen.timesOn);
    psychoJS.experiment.addData('fifthteen.timesOff', fifthteen.timesOff);
    psychoJS.experiment.addData('seventytwo.numClicks', seventytwo.numClicks);
    psychoJS.experiment.addData('seventytwo.timesOn', seventytwo.timesOn);
    psychoJS.experiment.addData('seventytwo.timesOff', seventytwo.timesOff);
    psychoJS.experiment.addData('onehundred.numClicks', onehundred.numClicks);
    psychoJS.experiment.addData('onehundred.timesOn', onehundred.timesOn);
    psychoJS.experiment.addData('onehundred.timesOff', onehundred.timesOff);
    // the Routine "catch3NG2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var break3NGMaxDurationReached;
var break3NGMaxDuration;
var break3NGComponents;
function break3NGRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'break3NG' ---
    t = 0;
    break3NGClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    break3NGMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next3NGbreak to account for continued clicks & clear times on/off
    next3NGbreak.reset()
    psychoJS.experiment.addData('break3NG.started', globalClock.getTime());
    break3NGMaxDuration = null
    // keep track of which components have finished
    break3NGComponents = [];
    break3NGComponents.push(SentirENGbreak);
    break3NGComponents.push(next3NGbreak);
    
    for (const thisComponent of break3NGComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function break3NGRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'break3NG' ---
    // get current time
    t = break3NGClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *SentirENGbreak* updates
    if (t >= 0.0 && SentirENGbreak.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      SentirENGbreak.tStart = t;  // (not accounting for frame time here)
      SentirENGbreak.frameNStart = frameN;  // exact frame index
      
      SentirENGbreak.setAutoDraw(true);
    }
    
    
    // *next3NGbreak* updates
    if (t >= 0 && next3NGbreak.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next3NGbreak.tStart = t;  // (not accounting for frame time here)
      next3NGbreak.frameNStart = frameN;  // exact frame index
      
      next3NGbreak.setAutoDraw(true);
    }
    
    if (next3NGbreak.status === PsychoJS.Status.STARTED) {
      // check whether next3NGbreak has been pressed
      if (next3NGbreak.isClicked) {
        if (!next3NGbreak.wasClicked) {
          // store time of first click
          next3NGbreak.timesOn.push(next3NGbreak.clock.getTime());
          // store time clicked until
          next3NGbreak.timesOff.push(next3NGbreak.clock.getTime());
        } else {
          // update time clicked until;
          next3NGbreak.timesOff[next3NGbreak.timesOff.length - 1] = next3NGbreak.clock.getTime();
        }
        if (!next3NGbreak.wasClicked) {
          // end routine when next3NGbreak is clicked
          continueRoutine = false;
          
        }
        // if next3NGbreak is still clicked next frame, it is not a new click
        next3NGbreak.wasClicked = true;
      } else {
        // if next3NGbreak is clicked next frame, it is a new click
        next3NGbreak.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next3NGbreak hasn't started / has finished
      next3NGbreak.clock.reset();
      // if next3NGbreak is clicked next frame, it is a new click
      next3NGbreak.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of break3NGComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function break3NGRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'break3NG' ---
    for (const thisComponent of break3NGComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('break3NG.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next3NGbreak.numClicks', next3NGbreak.numClicks);
    psychoJS.experiment.addData('next3NGbreak.timesOn', next3NGbreak.timesOn);
    psychoJS.experiment.addData('next3NGbreak.timesOff', next3NGbreak.timesOff);
    // the Routine "break3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch3NG3MaxDurationReached;
var catch3NG3MaxDuration;
var catch3NG3Components;
function catch3NG3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch3NG3' ---
    t = 0;
    catch3NG3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch3NG3MaxDurationReached = false;
    // update component parameters for each repeat
    // reset sandwitch to account for continued clicks & clear times on/off
    sandwitch.reset()
    // reset coliflower to account for continued clicks & clear times on/off
    coliflower.reset()
    // reset apple to account for continued clicks & clear times on/off
    apple.reset()
    psychoJS.experiment.addData('catch3NG3.started', globalClock.getTime());
    catch3NG3MaxDuration = null
    // keep track of which components have finished
    catch3NG3Components = [];
    catch3NG3Components.push(catch3NGfruit);
    catch3NG3Components.push(sandwitch);
    catch3NG3Components.push(coliflower);
    catch3NG3Components.push(apple);
    
    for (const thisComponent of catch3NG3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch3NG3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch3NG3' ---
    // get current time
    t = catch3NG3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch3NGfruit* updates
    if (t >= 0.0 && catch3NGfruit.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch3NGfruit.tStart = t;  // (not accounting for frame time here)
      catch3NGfruit.frameNStart = frameN;  // exact frame index
      
      catch3NGfruit.setAutoDraw(true);
    }
    
    
    // *sandwitch* updates
    if (t >= 0 && sandwitch.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sandwitch.tStart = t;  // (not accounting for frame time here)
      sandwitch.frameNStart = frameN;  // exact frame index
      
      sandwitch.setAutoDraw(true);
    }
    
    if (sandwitch.status === PsychoJS.Status.STARTED) {
      // check whether sandwitch has been pressed
      if (sandwitch.isClicked) {
        if (!sandwitch.wasClicked) {
          // store time of first click
          sandwitch.timesOn.push(sandwitch.clock.getTime());
          // store time clicked until
          sandwitch.timesOff.push(sandwitch.clock.getTime());
        } else {
          // update time clicked until;
          sandwitch.timesOff[sandwitch.timesOff.length - 1] = sandwitch.clock.getTime();
        }
        if (!sandwitch.wasClicked) {
          // end routine when sandwitch is clicked
          continueRoutine = false;
          
        }
        // if sandwitch is still clicked next frame, it is not a new click
        sandwitch.wasClicked = true;
      } else {
        // if sandwitch is clicked next frame, it is a new click
        sandwitch.wasClicked = false;
      }
    } else {
      // keep clock at 0 if sandwitch hasn't started / has finished
      sandwitch.clock.reset();
      // if sandwitch is clicked next frame, it is a new click
      sandwitch.wasClicked = false;
    }
    
    // *coliflower* updates
    if (t >= 0 && coliflower.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      coliflower.tStart = t;  // (not accounting for frame time here)
      coliflower.frameNStart = frameN;  // exact frame index
      
      coliflower.setAutoDraw(true);
    }
    
    if (coliflower.status === PsychoJS.Status.STARTED) {
      // check whether coliflower has been pressed
      if (coliflower.isClicked) {
        if (!coliflower.wasClicked) {
          // store time of first click
          coliflower.timesOn.push(coliflower.clock.getTime());
          // store time clicked until
          coliflower.timesOff.push(coliflower.clock.getTime());
        } else {
          // update time clicked until;
          coliflower.timesOff[coliflower.timesOff.length - 1] = coliflower.clock.getTime();
        }
        if (!coliflower.wasClicked) {
          // end routine when coliflower is clicked
          continueRoutine = false;
          
        }
        // if coliflower is still clicked next frame, it is not a new click
        coliflower.wasClicked = true;
      } else {
        // if coliflower is clicked next frame, it is a new click
        coliflower.wasClicked = false;
      }
    } else {
      // keep clock at 0 if coliflower hasn't started / has finished
      coliflower.clock.reset();
      // if coliflower is clicked next frame, it is a new click
      coliflower.wasClicked = false;
    }
    
    // *apple* updates
    if (t >= 0 && apple.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      apple.tStart = t;  // (not accounting for frame time here)
      apple.frameNStart = frameN;  // exact frame index
      
      apple.setAutoDraw(true);
    }
    
    if (apple.status === PsychoJS.Status.STARTED) {
      // check whether apple has been pressed
      if (apple.isClicked) {
        if (!apple.wasClicked) {
          // store time of first click
          apple.timesOn.push(apple.clock.getTime());
          // store time clicked until
          apple.timesOff.push(apple.clock.getTime());
        } else {
          // update time clicked until;
          apple.timesOff[apple.timesOff.length - 1] = apple.clock.getTime();
        }
        if (!apple.wasClicked) {
          // end routine when apple is clicked
          continueRoutine = false;
          
        }
        // if apple is still clicked next frame, it is not a new click
        apple.wasClicked = true;
      } else {
        // if apple is clicked next frame, it is a new click
        apple.wasClicked = false;
      }
    } else {
      // keep clock at 0 if apple hasn't started / has finished
      apple.clock.reset();
      // if apple is clicked next frame, it is a new click
      apple.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch3NG3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch3NG3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch3NG3' ---
    for (const thisComponent of catch3NG3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch3NG3.stopped', globalClock.getTime());
    psychoJS.experiment.addData('sandwitch.numClicks', sandwitch.numClicks);
    psychoJS.experiment.addData('sandwitch.timesOn', sandwitch.timesOn);
    psychoJS.experiment.addData('sandwitch.timesOff', sandwitch.timesOff);
    psychoJS.experiment.addData('coliflower.numClicks', coliflower.numClicks);
    psychoJS.experiment.addData('coliflower.timesOn', coliflower.timesOn);
    psychoJS.experiment.addData('coliflower.timesOff', coliflower.timesOff);
    psychoJS.experiment.addData('apple.numClicks', apple.numClicks);
    psychoJS.experiment.addData('apple.timesOn', apple.timesOn);
    psychoJS.experiment.addData('apple.timesOff', apple.timesOff);
    // the Routine "catch3NG3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var endMaxDurationReached;
var endMaxDuration;
var endComponents;
function endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'end' ---
    t = 0;
    endClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    endMaxDurationReached = false;
    // update component parameters for each repeat
    // reset end3NG to account for continued clicks & clear times on/off
    end3NG.reset()
    psychoJS.experiment.addData('end.started', globalClock.getTime());
    endMaxDuration = null
    // keep track of which components have finished
    endComponents = [];
    endComponents.push(end_y);
    endComponents.push(end3NG);
    
    for (const thisComponent of endComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function endRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'end' ---
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *end_y* updates
    if (t >= 0.0 && end_y.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      end_y.tStart = t;  // (not accounting for frame time here)
      end_y.frameNStart = frameN;  // exact frame index
      
      end_y.setAutoDraw(true);
    }
    
    
    // *end3NG* updates
    if (t >= 0 && end3NG.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      end3NG.tStart = t;  // (not accounting for frame time here)
      end3NG.frameNStart = frameN;  // exact frame index
      
      end3NG.setAutoDraw(true);
    }
    
    if (end3NG.status === PsychoJS.Status.STARTED) {
      // check whether end3NG has been pressed
      if (end3NG.isClicked) {
        if (!end3NG.wasClicked) {
          // store time of first click
          end3NG.timesOn.push(end3NG.clock.getTime());
          // store time clicked until
          end3NG.timesOff.push(end3NG.clock.getTime());
        } else {
          // update time clicked until;
          end3NG.timesOff[end3NG.timesOff.length - 1] = end3NG.clock.getTime();
        }
        if (!end3NG.wasClicked) {
          // end routine when end3NG is clicked
          continueRoutine = false;
          
        }
        // if end3NG is still clicked next frame, it is not a new click
        end3NG.wasClicked = true;
      } else {
        // if end3NG is clicked next frame, it is a new click
        end3NG.wasClicked = false;
      }
    } else {
      // keep clock at 0 if end3NG hasn't started / has finished
      end3NG.clock.reset();
      // if end3NG is clicked next frame, it is a new click
      end3NG.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of endComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'end' ---
    for (const thisComponent of endComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('end.stopped', globalClock.getTime());
    psychoJS.experiment.addData('end3NG.numClicks', end3NG.numClicks);
    psychoJS.experiment.addData('end3NG.timesOn', end3NG.timesOn);
    psychoJS.experiment.addData('end3NG.timesOff', end3NG.timesOff);
    // the Routine "end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
