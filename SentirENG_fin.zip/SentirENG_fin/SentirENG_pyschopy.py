#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.2.1),
    on Mon Sep  9 14:30:48 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.2.1'
expName = 'SentirENG_pyschopy'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1680, 1050]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/soniasimon/Documents/thesis/SentirENG_fin/SentirENG_pyschopy.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = True
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='event'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='Pyglet',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='Pyglet'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "warning3NG" ---
    warning3NGtext = visual.TextStim(win=win, name='warning3NGtext',
        text='WARNING\nThis study uses a wide range of words that are encountered in everyday life. Very occasionally, this means that some words may be offensive or explicit. If you feel that being exposed to such words will be distressing for you, we would like to remind you that you are free to end your participation in the study now or at any time you choose.\nIf you wish to continue, please press the "NEXT" button',
        font='Arial',
        units='height', pos=(0, 0), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next3NG = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NG',
        depth=-1
    )
    next3NG.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "instructions3NG" ---
    instructions3NGtext = visual.TextStim(win=win, name='instructions3NGtext',
        text='INSTRUCTIONS\nYou will be asked to rate how much you experience everyday concepts using six different perceptual senses. There are no right or wrong answers so please use your own judgement. The rating scale runs from 0 (not experienced at all with that sense) to 5 (experienced greatly with that sense). Click on a number to select a rating for each scale, then click on the Next button to move on the next item.\nIf you do not know the meaning of a word, just check the “Don’t know the meaning of this word" box and click "NEXT" to move onto the next item.',
        font='Arial',
        units='height', pos=(0, 0), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next3NGinstr = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGinstr',
        depth=-1
    )
    next3NGinstr.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirENG_psychopy" ---
    question = visual.TextStim(win=win, name='question',
        text='To what extent do you experience',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='by hearing',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='by tasting',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='by feeling through touch',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='by smelling',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='by seeing',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionslider = visual.Slider(win=win, name='interoceptionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next3NGstim = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGstim',
        depth=-14
    )
    next3NGstim.buttonClock = core.Clock()
    donotknow3NG = visual.ButtonStim(win, 
        text='do not know this word', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='donotknow3NG',
        depth=-15
    )
    donotknow3NG.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch3NG1" ---
    catch3NGanimal = visual.TextStim(win=win, name='catch3NGanimal',
        text='Which one of these animals flies?',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    Bear = visual.ButtonStim(win, 
        text='Bear', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Bear',
        depth=-1
    )
    Bear.buttonClock = core.Clock()
    Fish = visual.ButtonStim(win, 
        text='Fish', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Fish',
        depth=-2
    )
    Fish.buttonClock = core.Clock()
    Bird = visual.ButtonStim(win, 
        text='Bird', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Bird',
        depth=-3
    )
    Bird.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirENG_psychopy" ---
    question = visual.TextStim(win=win, name='question',
        text='To what extent do you experience',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='by hearing',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='by tasting',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='by feeling through touch',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='by smelling',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='by seeing',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionslider = visual.Slider(win=win, name='interoceptionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next3NGstim = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGstim',
        depth=-14
    )
    next3NGstim.buttonClock = core.Clock()
    donotknow3NG = visual.ButtonStim(win, 
        text='do not know this word', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='donotknow3NG',
        depth=-15
    )
    donotknow3NG.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch3NG2" ---
    catch3NGmath = visual.TextStim(win=win, name='catch3NGmath',
        text='What is 5 x 3?',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    fifthteen = visual.ButtonStim(win, 
        text='15', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='fifthteen',
        depth=-1
    )
    fifthteen.buttonClock = core.Clock()
    seventytwo = visual.ButtonStim(win, 
        text='72', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='seventytwo',
        depth=-2
    )
    seventytwo.buttonClock = core.Clock()
    onehundred = visual.ButtonStim(win, 
        text='100', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='onehundred',
        depth=-3
    )
    onehundred.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "break3NG" ---
    SentirENGbreak = visual.TextStim(win=win, name='SentirENGbreak',
        text='If you need, you can take a short break now. Push "Next" to continue the experiment',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next3NGbreak = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGbreak',
        depth=-1
    )
    next3NGbreak.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirENG_psychopy" ---
    question = visual.TextStim(win=win, name='question',
        text='To what extent do you experience',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='by hearing',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='by tasting',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='by feeling through touch',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='by smelling',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='by seeing',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionslider = visual.Slider(win=win, name='interoceptionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next3NGstim = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGstim',
        depth=-14
    )
    next3NGstim.buttonClock = core.Clock()
    donotknow3NG = visual.ButtonStim(win, 
        text='do not know this word', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='donotknow3NG',
        depth=-15
    )
    donotknow3NG.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch3NG3" ---
    catch3NGfruit = visual.TextStim(win=win, name='catch3NGfruit',
        text='Which of these is a fruit?',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    sandwitch = visual.ButtonStim(win, 
        text='sandwitch', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='sandwitch',
        depth=-1
    )
    sandwitch.buttonClock = core.Clock()
    coliflower = visual.ButtonStim(win, 
        text='cauliflower', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='coliflower',
        depth=-2
    )
    coliflower.buttonClock = core.Clock()
    apple = visual.ButtonStim(win, 
        text='apple', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='apple',
        depth=-3
    )
    apple.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirENG_psychopy" ---
    question = visual.TextStim(win=win, name='question',
        text='To what extent do you experience',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='by hearing',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='by tasting',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='by feeling through touch',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='by smelling',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='by seeing',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='by internal bodidly\nsensations',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionslider = visual.Slider(win=win, name='interoceptionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nothing", "totally"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next3NGstim = visual.ButtonStim(win, 
        text='Next', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next3NGstim',
        depth=-14
    )
    next3NGstim.buttonClock = core.Clock()
    donotknow3NG = visual.ButtonStim(win, 
        text='do not know this word', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='donotknow3NG',
        depth=-15
    )
    donotknow3NG.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "end" ---
    end_y = visual.TextStim(win=win, name='end_y',
        text='Thank you for your participation! To finish the experiment click end. ',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    end3NG = visual.ButtonStim(win, 
        text='fin', font='Arial',
        pos=(0, 0),units='height',
        letterHeight=0.05,
        size=(0.5, 0.5), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor=[-1.0000, 0.0902, 0.0902], borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='end3NG',
        depth=-1
    )
    end3NG.buttonClock = core.Clock()
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "warning3NG" ---
    # create an object to store info about Routine warning3NG
    warning3NG = data.Routine(
        name='warning3NG',
        components=[warning3NGtext, next3NG],
    )
    warning3NG.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next3NG to account for continued clicks & clear times on/off
    next3NG.reset()
    # store start times for warning3NG
    warning3NG.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    warning3NG.tStart = globalClock.getTime(format='float')
    warning3NG.status = STARTED
    thisExp.addData('warning3NG.started', warning3NG.tStart)
    warning3NG.maxDuration = None
    # keep track of which components have finished
    warning3NGComponents = warning3NG.components
    for thisComponent in warning3NG.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "warning3NG" ---
    warning3NG.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *warning3NGtext* updates
        
        # if warning3NGtext is starting this frame...
        if warning3NGtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            warning3NGtext.frameNStart = frameN  # exact frame index
            warning3NGtext.tStart = t  # local t and not account for scr refresh
            warning3NGtext.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(warning3NGtext, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'warning3NGtext.started')
            # update status
            warning3NGtext.status = STARTED
            warning3NGtext.setAutoDraw(True)
        
        # if warning3NGtext is active this frame...
        if warning3NGtext.status == STARTED:
            # update params
            pass
        # *next3NG* updates
        
        # if next3NG is starting this frame...
        if next3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next3NG.frameNStart = frameN  # exact frame index
            next3NG.tStart = t  # local t and not account for scr refresh
            next3NG.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next3NG, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next3NG.started')
            # update status
            next3NG.status = STARTED
            win.callOnFlip(next3NG.buttonClock.reset)
            next3NG.setAutoDraw(True)
        
        # if next3NG is active this frame...
        if next3NG.status == STARTED:
            # update params
            pass
            # check whether next3NG has been pressed
            if next3NG.isClicked:
                if not next3NG.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next3NG.timesOn.append(next3NG.buttonClock.getTime())
                    next3NG.timesOff.append(next3NG.buttonClock.getTime())
                elif len(next3NG.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next3NG.timesOff[-1] = next3NG.buttonClock.getTime()
                if not next3NG.wasClicked:
                    # end routine when next3NG is clicked
                    continueRoutine = False
                if not next3NG.wasClicked:
                    # run callback code when next3NG is clicked
                    pass
        # take note of whether next3NG was clicked, so that next frame we know if clicks are new
        next3NG.wasClicked = next3NG.isClicked and next3NG.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            warning3NG.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warning3NG.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "warning3NG" ---
    for thisComponent in warning3NG.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for warning3NG
    warning3NG.tStop = globalClock.getTime(format='float')
    warning3NG.tStopRefresh = tThisFlipGlobal
    thisExp.addData('warning3NG.stopped', warning3NG.tStop)
    thisExp.addData('next3NG.numClicks', next3NG.numClicks)
    if next3NG.numClicks:
       thisExp.addData('next3NG.timesOn', next3NG.timesOn)
       thisExp.addData('next3NG.timesOff', next3NG.timesOff)
    else:
       thisExp.addData('next3NG.timesOn', "")
       thisExp.addData('next3NG.timesOff', "")
    thisExp.nextEntry()
    # the Routine "warning3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "instructions3NG" ---
    # create an object to store info about Routine instructions3NG
    instructions3NG = data.Routine(
        name='instructions3NG',
        components=[instructions3NGtext, next3NGinstr],
    )
    instructions3NG.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next3NGinstr to account for continued clicks & clear times on/off
    next3NGinstr.reset()
    # store start times for instructions3NG
    instructions3NG.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    instructions3NG.tStart = globalClock.getTime(format='float')
    instructions3NG.status = STARTED
    thisExp.addData('instructions3NG.started', instructions3NG.tStart)
    instructions3NG.maxDuration = None
    # keep track of which components have finished
    instructions3NGComponents = instructions3NG.components
    for thisComponent in instructions3NG.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instructions3NG" ---
    instructions3NG.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instructions3NGtext* updates
        
        # if instructions3NGtext is starting this frame...
        if instructions3NGtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructions3NGtext.frameNStart = frameN  # exact frame index
            instructions3NGtext.tStart = t  # local t and not account for scr refresh
            instructions3NGtext.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructions3NGtext, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructions3NGtext.started')
            # update status
            instructions3NGtext.status = STARTED
            instructions3NGtext.setAutoDraw(True)
        
        # if instructions3NGtext is active this frame...
        if instructions3NGtext.status == STARTED:
            # update params
            pass
        # *next3NGinstr* updates
        
        # if next3NGinstr is starting this frame...
        if next3NGinstr.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next3NGinstr.frameNStart = frameN  # exact frame index
            next3NGinstr.tStart = t  # local t and not account for scr refresh
            next3NGinstr.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next3NGinstr, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next3NGinstr.started')
            # update status
            next3NGinstr.status = STARTED
            win.callOnFlip(next3NGinstr.buttonClock.reset)
            next3NGinstr.setAutoDraw(True)
        
        # if next3NGinstr is active this frame...
        if next3NGinstr.status == STARTED:
            # update params
            pass
            # check whether next3NGinstr has been pressed
            if next3NGinstr.isClicked:
                if not next3NGinstr.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next3NGinstr.timesOn.append(next3NGinstr.buttonClock.getTime())
                    next3NGinstr.timesOff.append(next3NGinstr.buttonClock.getTime())
                elif len(next3NGinstr.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next3NGinstr.timesOff[-1] = next3NGinstr.buttonClock.getTime()
                if not next3NGinstr.wasClicked:
                    # end routine when next3NGinstr is clicked
                    continueRoutine = False
                if not next3NGinstr.wasClicked:
                    # run callback code when next3NGinstr is clicked
                    pass
        # take note of whether next3NGinstr was clicked, so that next frame we know if clicks are new
        next3NGinstr.wasClicked = next3NGinstr.isClicked and next3NGinstr.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            instructions3NG.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructions3NG.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instructions3NG" ---
    for thisComponent in instructions3NG.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for instructions3NG
    instructions3NG.tStop = globalClock.getTime(format='float')
    instructions3NG.tStopRefresh = tThisFlipGlobal
    thisExp.addData('instructions3NG.stopped', instructions3NG.tStop)
    thisExp.addData('next3NGinstr.numClicks', next3NGinstr.numClicks)
    if next3NGinstr.numClicks:
       thisExp.addData('next3NGinstr.timesOn', next3NGinstr.timesOn)
       thisExp.addData('next3NGinstr.timesOff', next3NGinstr.timesOff)
    else:
       thisExp.addData('next3NGinstr.timesOn', "")
       thisExp.addData('next3NGinstr.timesOff', "")
    thisExp.nextEntry()
    # the Routine "instructions3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirENG19 = data.TrialHandler2(
        name='SentirENG19',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimENG/Stimuli3ENG19.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirENG19)  # add the loop to the experiment
    thisSentirENG19 = SentirENG19.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirENG19.rgb)
    if thisSentirENG19 != None:
        for paramName in thisSentirENG19:
            globals()[paramName] = thisSentirENG19[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirENG19 in SentirENG19:
        currentLoop = SentirENG19
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirENG19.rgb)
        if thisSentirENG19 != None:
            for paramName in thisSentirENG19:
                globals()[paramName] = thisSentirENG19[paramName]
        
        # --- Prepare to start Routine "SentirENG_psychopy" ---
        # create an object to store info about Routine SentirENG_psychopy
        SentirENG_psychopy = data.Routine(
            name='SentirENG_psychopy',
            components=[question, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionslider, next3NGstim, donotknow3NG],
        )
        SentirENG_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionslider.reset()
        # reset next3NGstim to account for continued clicks & clear times on/off
        next3NGstim.reset()
        # reset donotknow3NG to account for continued clicks & clear times on/off
        donotknow3NG.reset()
        # store start times for SentirENG_psychopy
        SentirENG_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirENG_psychopy.tStart = globalClock.getTime(format='float')
        SentirENG_psychopy.status = STARTED
        thisExp.addData('SentirENG_psychopy.started', SentirENG_psychopy.tStart)
        SentirENG_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirENG_psychopyComponents = SentirENG_psychopy.components
        for thisComponent in SentirENG_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirENG_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirENG19, data.TrialHandler2) and thisSentirENG19.thisN != SentirENG19.thisTrial.thisN:
            continueRoutine = False
        SentirENG_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *question* updates
            
            # if question is starting this frame...
            if question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                question.frameNStart = frameN  # exact frame index
                question.tStart = t  # local t and not account for scr refresh
                question.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(question, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'question.started')
                # update status
                question.status = STARTED
                question.setAutoDraw(True)
            
            # if question is active this frame...
            if question.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionslider* updates
            
            # if interoceptionslider is starting this frame...
            if interoceptionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionslider.frameNStart = frameN  # exact frame index
                interoceptionslider.tStart = t  # local t and not account for scr refresh
                interoceptionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionslider.started')
                # update status
                interoceptionslider.status = STARTED
                interoceptionslider.setAutoDraw(True)
            
            # if interoceptionslider is active this frame...
            if interoceptionslider.status == STARTED:
                # update params
                pass
            # *next3NGstim* updates
            
            # if next3NGstim is starting this frame...
            if next3NGstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next3NGstim.frameNStart = frameN  # exact frame index
                next3NGstim.tStart = t  # local t and not account for scr refresh
                next3NGstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next3NGstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next3NGstim.started')
                # update status
                next3NGstim.status = STARTED
                win.callOnFlip(next3NGstim.buttonClock.reset)
                next3NGstim.setAutoDraw(True)
            
            # if next3NGstim is active this frame...
            if next3NGstim.status == STARTED:
                # update params
                pass
                # check whether next3NGstim has been pressed
                if next3NGstim.isClicked:
                    if not next3NGstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next3NGstim.timesOn.append(next3NGstim.buttonClock.getTime())
                        next3NGstim.timesOff.append(next3NGstim.buttonClock.getTime())
                    elif len(next3NGstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next3NGstim.timesOff[-1] = next3NGstim.buttonClock.getTime()
                    if not next3NGstim.wasClicked:
                        # end routine when next3NGstim is clicked
                        continueRoutine = False
                    if not next3NGstim.wasClicked:
                        # run callback code when next3NGstim is clicked
                        pass
            # take note of whether next3NGstim was clicked, so that next frame we know if clicks are new
            next3NGstim.wasClicked = next3NGstim.isClicked and next3NGstim.status == STARTED
            # *donotknow3NG* updates
            
            # if donotknow3NG is starting this frame...
            if donotknow3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                donotknow3NG.frameNStart = frameN  # exact frame index
                donotknow3NG.tStart = t  # local t and not account for scr refresh
                donotknow3NG.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(donotknow3NG, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'donotknow3NG.started')
                # update status
                donotknow3NG.status = STARTED
                win.callOnFlip(donotknow3NG.buttonClock.reset)
                donotknow3NG.setAutoDraw(True)
            
            # if donotknow3NG is active this frame...
            if donotknow3NG.status == STARTED:
                # update params
                pass
                # check whether donotknow3NG has been pressed
                if donotknow3NG.isClicked:
                    if not donotknow3NG.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        donotknow3NG.timesOn.append(donotknow3NG.buttonClock.getTime())
                        donotknow3NG.timesOff.append(donotknow3NG.buttonClock.getTime())
                    elif len(donotknow3NG.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        donotknow3NG.timesOff[-1] = donotknow3NG.buttonClock.getTime()
                    if not donotknow3NG.wasClicked:
                        # end routine when donotknow3NG is clicked
                        continueRoutine = False
                    if not donotknow3NG.wasClicked:
                        # run callback code when donotknow3NG is clicked
                        pass
            # take note of whether donotknow3NG was clicked, so that next frame we know if clicks are new
            donotknow3NG.wasClicked = donotknow3NG.isClicked and donotknow3NG.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirENG_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirENG_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirENG_psychopy" ---
        for thisComponent in SentirENG_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirENG_psychopy
        SentirENG_psychopy.tStop = globalClock.getTime(format='float')
        SentirENG_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirENG_psychopy.stopped', SentirENG_psychopy.tStop)
        SentirENG19.addData('auditionslider.response', auditionslider.getRating())
        SentirENG19.addData('auditionslider.rt', auditionslider.getRT())
        SentirENG19.addData('tasteslider.response', tasteslider.getRating())
        SentirENG19.addData('tasteslider.rt', tasteslider.getRT())
        SentirENG19.addData('hapticslider.response', hapticslider.getRating())
        SentirENG19.addData('hapticslider.rt', hapticslider.getRT())
        SentirENG19.addData('olfactionslider.response', olfactionslider.getRating())
        SentirENG19.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirENG19.addData('visionslider.response', visionslider.getRating())
        SentirENG19.addData('visionslider.rt', visionslider.getRT())
        SentirENG19.addData('interoceptionslider.response', interoceptionslider.getRating())
        SentirENG19.addData('interoceptionslider.rt', interoceptionslider.getRT())
        SentirENG19.addData('next3NGstim.numClicks', next3NGstim.numClicks)
        if next3NGstim.numClicks:
           SentirENG19.addData('next3NGstim.timesOn', next3NGstim.timesOn)
           SentirENG19.addData('next3NGstim.timesOff', next3NGstim.timesOff)
        else:
           SentirENG19.addData('next3NGstim.timesOn', "")
           SentirENG19.addData('next3NGstim.timesOff', "")
        SentirENG19.addData('donotknow3NG.numClicks', donotknow3NG.numClicks)
        if donotknow3NG.numClicks:
           SentirENG19.addData('donotknow3NG.timesOn', donotknow3NG.timesOn)
           SentirENG19.addData('donotknow3NG.timesOff', donotknow3NG.timesOff)
        else:
           SentirENG19.addData('donotknow3NG.timesOn', "")
           SentirENG19.addData('donotknow3NG.timesOff', "")
        # the Routine "SentirENG_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirENG19'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "catch3NG1" ---
    # create an object to store info about Routine catch3NG1
    catch3NG1 = data.Routine(
        name='catch3NG1',
        components=[catch3NGanimal, Bear, Fish, Bird],
    )
    catch3NG1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset Bear to account for continued clicks & clear times on/off
    Bear.reset()
    # reset Fish to account for continued clicks & clear times on/off
    Fish.reset()
    # reset Bird to account for continued clicks & clear times on/off
    Bird.reset()
    # store start times for catch3NG1
    catch3NG1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch3NG1.tStart = globalClock.getTime(format='float')
    catch3NG1.status = STARTED
    thisExp.addData('catch3NG1.started', catch3NG1.tStart)
    catch3NG1.maxDuration = None
    # keep track of which components have finished
    catch3NG1Components = catch3NG1.components
    for thisComponent in catch3NG1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch3NG1" ---
    catch3NG1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch3NGanimal* updates
        
        # if catch3NGanimal is starting this frame...
        if catch3NGanimal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch3NGanimal.frameNStart = frameN  # exact frame index
            catch3NGanimal.tStart = t  # local t and not account for scr refresh
            catch3NGanimal.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch3NGanimal, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch3NGanimal.started')
            # update status
            catch3NGanimal.status = STARTED
            catch3NGanimal.setAutoDraw(True)
        
        # if catch3NGanimal is active this frame...
        if catch3NGanimal.status == STARTED:
            # update params
            pass
        # *Bear* updates
        
        # if Bear is starting this frame...
        if Bear.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Bear.frameNStart = frameN  # exact frame index
            Bear.tStart = t  # local t and not account for scr refresh
            Bear.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Bear, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Bear.started')
            # update status
            Bear.status = STARTED
            win.callOnFlip(Bear.buttonClock.reset)
            Bear.setAutoDraw(True)
        
        # if Bear is active this frame...
        if Bear.status == STARTED:
            # update params
            pass
            # check whether Bear has been pressed
            if Bear.isClicked:
                if not Bear.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Bear.timesOn.append(Bear.buttonClock.getTime())
                    Bear.timesOff.append(Bear.buttonClock.getTime())
                elif len(Bear.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Bear.timesOff[-1] = Bear.buttonClock.getTime()
                if not Bear.wasClicked:
                    # end routine when Bear is clicked
                    continueRoutine = False
                if not Bear.wasClicked:
                    # run callback code when Bear is clicked
                    pass
        # take note of whether Bear was clicked, so that next frame we know if clicks are new
        Bear.wasClicked = Bear.isClicked and Bear.status == STARTED
        # *Fish* updates
        
        # if Fish is starting this frame...
        if Fish.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Fish.frameNStart = frameN  # exact frame index
            Fish.tStart = t  # local t and not account for scr refresh
            Fish.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Fish, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Fish.started')
            # update status
            Fish.status = STARTED
            win.callOnFlip(Fish.buttonClock.reset)
            Fish.setAutoDraw(True)
        
        # if Fish is active this frame...
        if Fish.status == STARTED:
            # update params
            pass
            # check whether Fish has been pressed
            if Fish.isClicked:
                if not Fish.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Fish.timesOn.append(Fish.buttonClock.getTime())
                    Fish.timesOff.append(Fish.buttonClock.getTime())
                elif len(Fish.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Fish.timesOff[-1] = Fish.buttonClock.getTime()
                if not Fish.wasClicked:
                    # end routine when Fish is clicked
                    continueRoutine = False
                if not Fish.wasClicked:
                    # run callback code when Fish is clicked
                    pass
        # take note of whether Fish was clicked, so that next frame we know if clicks are new
        Fish.wasClicked = Fish.isClicked and Fish.status == STARTED
        # *Bird* updates
        
        # if Bird is starting this frame...
        if Bird.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Bird.frameNStart = frameN  # exact frame index
            Bird.tStart = t  # local t and not account for scr refresh
            Bird.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Bird, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Bird.started')
            # update status
            Bird.status = STARTED
            win.callOnFlip(Bird.buttonClock.reset)
            Bird.setAutoDraw(True)
        
        # if Bird is active this frame...
        if Bird.status == STARTED:
            # update params
            pass
            # check whether Bird has been pressed
            if Bird.isClicked:
                if not Bird.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Bird.timesOn.append(Bird.buttonClock.getTime())
                    Bird.timesOff.append(Bird.buttonClock.getTime())
                elif len(Bird.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Bird.timesOff[-1] = Bird.buttonClock.getTime()
                if not Bird.wasClicked:
                    # end routine when Bird is clicked
                    continueRoutine = False
                if not Bird.wasClicked:
                    # run callback code when Bird is clicked
                    pass
        # take note of whether Bird was clicked, so that next frame we know if clicks are new
        Bird.wasClicked = Bird.isClicked and Bird.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch3NG1.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch3NG1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch3NG1" ---
    for thisComponent in catch3NG1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch3NG1
    catch3NG1.tStop = globalClock.getTime(format='float')
    catch3NG1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch3NG1.stopped', catch3NG1.tStop)
    thisExp.addData('Bear.numClicks', Bear.numClicks)
    if Bear.numClicks:
       thisExp.addData('Bear.timesOn', Bear.timesOn)
       thisExp.addData('Bear.timesOff', Bear.timesOff)
    else:
       thisExp.addData('Bear.timesOn', "")
       thisExp.addData('Bear.timesOff', "")
    thisExp.addData('Fish.numClicks', Fish.numClicks)
    if Fish.numClicks:
       thisExp.addData('Fish.timesOn', Fish.timesOn)
       thisExp.addData('Fish.timesOff', Fish.timesOff)
    else:
       thisExp.addData('Fish.timesOn', "")
       thisExp.addData('Fish.timesOff', "")
    thisExp.addData('Bird.numClicks', Bird.numClicks)
    if Bird.numClicks:
       thisExp.addData('Bird.timesOn', Bird.timesOn)
       thisExp.addData('Bird.timesOff', Bird.timesOff)
    else:
       thisExp.addData('Bird.timesOn', "")
       thisExp.addData('Bird.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch3NG1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirENG45 = data.TrialHandler2(
        name='SentirENG45',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimENG/Stimuli3ENG45.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirENG45)  # add the loop to the experiment
    thisSentirENG45 = SentirENG45.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirENG45.rgb)
    if thisSentirENG45 != None:
        for paramName in thisSentirENG45:
            globals()[paramName] = thisSentirENG45[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirENG45 in SentirENG45:
        currentLoop = SentirENG45
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirENG45.rgb)
        if thisSentirENG45 != None:
            for paramName in thisSentirENG45:
                globals()[paramName] = thisSentirENG45[paramName]
        
        # --- Prepare to start Routine "SentirENG_psychopy" ---
        # create an object to store info about Routine SentirENG_psychopy
        SentirENG_psychopy = data.Routine(
            name='SentirENG_psychopy',
            components=[question, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionslider, next3NGstim, donotknow3NG],
        )
        SentirENG_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionslider.reset()
        # reset next3NGstim to account for continued clicks & clear times on/off
        next3NGstim.reset()
        # reset donotknow3NG to account for continued clicks & clear times on/off
        donotknow3NG.reset()
        # store start times for SentirENG_psychopy
        SentirENG_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirENG_psychopy.tStart = globalClock.getTime(format='float')
        SentirENG_psychopy.status = STARTED
        thisExp.addData('SentirENG_psychopy.started', SentirENG_psychopy.tStart)
        SentirENG_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirENG_psychopyComponents = SentirENG_psychopy.components
        for thisComponent in SentirENG_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirENG_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirENG45, data.TrialHandler2) and thisSentirENG45.thisN != SentirENG45.thisTrial.thisN:
            continueRoutine = False
        SentirENG_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *question* updates
            
            # if question is starting this frame...
            if question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                question.frameNStart = frameN  # exact frame index
                question.tStart = t  # local t and not account for scr refresh
                question.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(question, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'question.started')
                # update status
                question.status = STARTED
                question.setAutoDraw(True)
            
            # if question is active this frame...
            if question.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionslider* updates
            
            # if interoceptionslider is starting this frame...
            if interoceptionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionslider.frameNStart = frameN  # exact frame index
                interoceptionslider.tStart = t  # local t and not account for scr refresh
                interoceptionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionslider.started')
                # update status
                interoceptionslider.status = STARTED
                interoceptionslider.setAutoDraw(True)
            
            # if interoceptionslider is active this frame...
            if interoceptionslider.status == STARTED:
                # update params
                pass
            # *next3NGstim* updates
            
            # if next3NGstim is starting this frame...
            if next3NGstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next3NGstim.frameNStart = frameN  # exact frame index
                next3NGstim.tStart = t  # local t and not account for scr refresh
                next3NGstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next3NGstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next3NGstim.started')
                # update status
                next3NGstim.status = STARTED
                win.callOnFlip(next3NGstim.buttonClock.reset)
                next3NGstim.setAutoDraw(True)
            
            # if next3NGstim is active this frame...
            if next3NGstim.status == STARTED:
                # update params
                pass
                # check whether next3NGstim has been pressed
                if next3NGstim.isClicked:
                    if not next3NGstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next3NGstim.timesOn.append(next3NGstim.buttonClock.getTime())
                        next3NGstim.timesOff.append(next3NGstim.buttonClock.getTime())
                    elif len(next3NGstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next3NGstim.timesOff[-1] = next3NGstim.buttonClock.getTime()
                    if not next3NGstim.wasClicked:
                        # end routine when next3NGstim is clicked
                        continueRoutine = False
                    if not next3NGstim.wasClicked:
                        # run callback code when next3NGstim is clicked
                        pass
            # take note of whether next3NGstim was clicked, so that next frame we know if clicks are new
            next3NGstim.wasClicked = next3NGstim.isClicked and next3NGstim.status == STARTED
            # *donotknow3NG* updates
            
            # if donotknow3NG is starting this frame...
            if donotknow3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                donotknow3NG.frameNStart = frameN  # exact frame index
                donotknow3NG.tStart = t  # local t and not account for scr refresh
                donotknow3NG.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(donotknow3NG, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'donotknow3NG.started')
                # update status
                donotknow3NG.status = STARTED
                win.callOnFlip(donotknow3NG.buttonClock.reset)
                donotknow3NG.setAutoDraw(True)
            
            # if donotknow3NG is active this frame...
            if donotknow3NG.status == STARTED:
                # update params
                pass
                # check whether donotknow3NG has been pressed
                if donotknow3NG.isClicked:
                    if not donotknow3NG.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        donotknow3NG.timesOn.append(donotknow3NG.buttonClock.getTime())
                        donotknow3NG.timesOff.append(donotknow3NG.buttonClock.getTime())
                    elif len(donotknow3NG.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        donotknow3NG.timesOff[-1] = donotknow3NG.buttonClock.getTime()
                    if not donotknow3NG.wasClicked:
                        # end routine when donotknow3NG is clicked
                        continueRoutine = False
                    if not donotknow3NG.wasClicked:
                        # run callback code when donotknow3NG is clicked
                        pass
            # take note of whether donotknow3NG was clicked, so that next frame we know if clicks are new
            donotknow3NG.wasClicked = donotknow3NG.isClicked and donotknow3NG.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirENG_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirENG_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirENG_psychopy" ---
        for thisComponent in SentirENG_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirENG_psychopy
        SentirENG_psychopy.tStop = globalClock.getTime(format='float')
        SentirENG_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirENG_psychopy.stopped', SentirENG_psychopy.tStop)
        SentirENG45.addData('auditionslider.response', auditionslider.getRating())
        SentirENG45.addData('auditionslider.rt', auditionslider.getRT())
        SentirENG45.addData('tasteslider.response', tasteslider.getRating())
        SentirENG45.addData('tasteslider.rt', tasteslider.getRT())
        SentirENG45.addData('hapticslider.response', hapticslider.getRating())
        SentirENG45.addData('hapticslider.rt', hapticslider.getRT())
        SentirENG45.addData('olfactionslider.response', olfactionslider.getRating())
        SentirENG45.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirENG45.addData('visionslider.response', visionslider.getRating())
        SentirENG45.addData('visionslider.rt', visionslider.getRT())
        SentirENG45.addData('interoceptionslider.response', interoceptionslider.getRating())
        SentirENG45.addData('interoceptionslider.rt', interoceptionslider.getRT())
        SentirENG45.addData('next3NGstim.numClicks', next3NGstim.numClicks)
        if next3NGstim.numClicks:
           SentirENG45.addData('next3NGstim.timesOn', next3NGstim.timesOn)
           SentirENG45.addData('next3NGstim.timesOff', next3NGstim.timesOff)
        else:
           SentirENG45.addData('next3NGstim.timesOn', "")
           SentirENG45.addData('next3NGstim.timesOff', "")
        SentirENG45.addData('donotknow3NG.numClicks', donotknow3NG.numClicks)
        if donotknow3NG.numClicks:
           SentirENG45.addData('donotknow3NG.timesOn', donotknow3NG.timesOn)
           SentirENG45.addData('donotknow3NG.timesOff', donotknow3NG.timesOff)
        else:
           SentirENG45.addData('donotknow3NG.timesOn', "")
           SentirENG45.addData('donotknow3NG.timesOff', "")
        # the Routine "SentirENG_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirENG45'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "catch3NG2" ---
    # create an object to store info about Routine catch3NG2
    catch3NG2 = data.Routine(
        name='catch3NG2',
        components=[catch3NGmath, fifthteen, seventytwo, onehundred],
    )
    catch3NG2.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset fifthteen to account for continued clicks & clear times on/off
    fifthteen.reset()
    # reset seventytwo to account for continued clicks & clear times on/off
    seventytwo.reset()
    # reset onehundred to account for continued clicks & clear times on/off
    onehundred.reset()
    # store start times for catch3NG2
    catch3NG2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch3NG2.tStart = globalClock.getTime(format='float')
    catch3NG2.status = STARTED
    thisExp.addData('catch3NG2.started', catch3NG2.tStart)
    catch3NG2.maxDuration = None
    # keep track of which components have finished
    catch3NG2Components = catch3NG2.components
    for thisComponent in catch3NG2.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch3NG2" ---
    catch3NG2.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch3NGmath* updates
        
        # if catch3NGmath is starting this frame...
        if catch3NGmath.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch3NGmath.frameNStart = frameN  # exact frame index
            catch3NGmath.tStart = t  # local t and not account for scr refresh
            catch3NGmath.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch3NGmath, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch3NGmath.started')
            # update status
            catch3NGmath.status = STARTED
            catch3NGmath.setAutoDraw(True)
        
        # if catch3NGmath is active this frame...
        if catch3NGmath.status == STARTED:
            # update params
            pass
        # *fifthteen* updates
        
        # if fifthteen is starting this frame...
        if fifthteen.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            fifthteen.frameNStart = frameN  # exact frame index
            fifthteen.tStart = t  # local t and not account for scr refresh
            fifthteen.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fifthteen, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fifthteen.started')
            # update status
            fifthteen.status = STARTED
            win.callOnFlip(fifthteen.buttonClock.reset)
            fifthteen.setAutoDraw(True)
        
        # if fifthteen is active this frame...
        if fifthteen.status == STARTED:
            # update params
            pass
            # check whether fifthteen has been pressed
            if fifthteen.isClicked:
                if not fifthteen.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    fifthteen.timesOn.append(fifthteen.buttonClock.getTime())
                    fifthteen.timesOff.append(fifthteen.buttonClock.getTime())
                elif len(fifthteen.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    fifthteen.timesOff[-1] = fifthteen.buttonClock.getTime()
                if not fifthteen.wasClicked:
                    # end routine when fifthteen is clicked
                    continueRoutine = False
                if not fifthteen.wasClicked:
                    # run callback code when fifthteen is clicked
                    pass
        # take note of whether fifthteen was clicked, so that next frame we know if clicks are new
        fifthteen.wasClicked = fifthteen.isClicked and fifthteen.status == STARTED
        # *seventytwo* updates
        
        # if seventytwo is starting this frame...
        if seventytwo.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            seventytwo.frameNStart = frameN  # exact frame index
            seventytwo.tStart = t  # local t and not account for scr refresh
            seventytwo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(seventytwo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'seventytwo.started')
            # update status
            seventytwo.status = STARTED
            win.callOnFlip(seventytwo.buttonClock.reset)
            seventytwo.setAutoDraw(True)
        
        # if seventytwo is active this frame...
        if seventytwo.status == STARTED:
            # update params
            pass
            # check whether seventytwo has been pressed
            if seventytwo.isClicked:
                if not seventytwo.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    seventytwo.timesOn.append(seventytwo.buttonClock.getTime())
                    seventytwo.timesOff.append(seventytwo.buttonClock.getTime())
                elif len(seventytwo.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    seventytwo.timesOff[-1] = seventytwo.buttonClock.getTime()
                if not seventytwo.wasClicked:
                    # end routine when seventytwo is clicked
                    continueRoutine = False
                if not seventytwo.wasClicked:
                    # run callback code when seventytwo is clicked
                    pass
        # take note of whether seventytwo was clicked, so that next frame we know if clicks are new
        seventytwo.wasClicked = seventytwo.isClicked and seventytwo.status == STARTED
        # *onehundred* updates
        
        # if onehundred is starting this frame...
        if onehundred.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            onehundred.frameNStart = frameN  # exact frame index
            onehundred.tStart = t  # local t and not account for scr refresh
            onehundred.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(onehundred, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'onehundred.started')
            # update status
            onehundred.status = STARTED
            win.callOnFlip(onehundred.buttonClock.reset)
            onehundred.setAutoDraw(True)
        
        # if onehundred is active this frame...
        if onehundred.status == STARTED:
            # update params
            pass
            # check whether onehundred has been pressed
            if onehundred.isClicked:
                if not onehundred.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    onehundred.timesOn.append(onehundred.buttonClock.getTime())
                    onehundred.timesOff.append(onehundred.buttonClock.getTime())
                elif len(onehundred.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    onehundred.timesOff[-1] = onehundred.buttonClock.getTime()
                if not onehundred.wasClicked:
                    # end routine when onehundred is clicked
                    continueRoutine = False
                if not onehundred.wasClicked:
                    # run callback code when onehundred is clicked
                    pass
        # take note of whether onehundred was clicked, so that next frame we know if clicks are new
        onehundred.wasClicked = onehundred.isClicked and onehundred.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch3NG2.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch3NG2.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch3NG2" ---
    for thisComponent in catch3NG2.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch3NG2
    catch3NG2.tStop = globalClock.getTime(format='float')
    catch3NG2.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch3NG2.stopped', catch3NG2.tStop)
    thisExp.addData('fifthteen.numClicks', fifthteen.numClicks)
    if fifthteen.numClicks:
       thisExp.addData('fifthteen.timesOn', fifthteen.timesOn)
       thisExp.addData('fifthteen.timesOff', fifthteen.timesOff)
    else:
       thisExp.addData('fifthteen.timesOn', "")
       thisExp.addData('fifthteen.timesOff', "")
    thisExp.addData('seventytwo.numClicks', seventytwo.numClicks)
    if seventytwo.numClicks:
       thisExp.addData('seventytwo.timesOn', seventytwo.timesOn)
       thisExp.addData('seventytwo.timesOff', seventytwo.timesOff)
    else:
       thisExp.addData('seventytwo.timesOn', "")
       thisExp.addData('seventytwo.timesOff', "")
    thisExp.addData('onehundred.numClicks', onehundred.numClicks)
    if onehundred.numClicks:
       thisExp.addData('onehundred.timesOn', onehundred.timesOn)
       thisExp.addData('onehundred.timesOff', onehundred.timesOff)
    else:
       thisExp.addData('onehundred.timesOn', "")
       thisExp.addData('onehundred.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch3NG2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "break3NG" ---
    # create an object to store info about Routine break3NG
    break3NG = data.Routine(
        name='break3NG',
        components=[SentirENGbreak, next3NGbreak],
    )
    break3NG.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next3NGbreak to account for continued clicks & clear times on/off
    next3NGbreak.reset()
    # store start times for break3NG
    break3NG.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break3NG.tStart = globalClock.getTime(format='float')
    break3NG.status = STARTED
    thisExp.addData('break3NG.started', break3NG.tStart)
    break3NG.maxDuration = None
    # keep track of which components have finished
    break3NGComponents = break3NG.components
    for thisComponent in break3NG.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break3NG" ---
    break3NG.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *SentirENGbreak* updates
        
        # if SentirENGbreak is starting this frame...
        if SentirENGbreak.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            SentirENGbreak.frameNStart = frameN  # exact frame index
            SentirENGbreak.tStart = t  # local t and not account for scr refresh
            SentirENGbreak.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(SentirENGbreak, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'SentirENGbreak.started')
            # update status
            SentirENGbreak.status = STARTED
            SentirENGbreak.setAutoDraw(True)
        
        # if SentirENGbreak is active this frame...
        if SentirENGbreak.status == STARTED:
            # update params
            pass
        # *next3NGbreak* updates
        
        # if next3NGbreak is starting this frame...
        if next3NGbreak.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next3NGbreak.frameNStart = frameN  # exact frame index
            next3NGbreak.tStart = t  # local t and not account for scr refresh
            next3NGbreak.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next3NGbreak, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next3NGbreak.started')
            # update status
            next3NGbreak.status = STARTED
            win.callOnFlip(next3NGbreak.buttonClock.reset)
            next3NGbreak.setAutoDraw(True)
        
        # if next3NGbreak is active this frame...
        if next3NGbreak.status == STARTED:
            # update params
            pass
            # check whether next3NGbreak has been pressed
            if next3NGbreak.isClicked:
                if not next3NGbreak.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next3NGbreak.timesOn.append(next3NGbreak.buttonClock.getTime())
                    next3NGbreak.timesOff.append(next3NGbreak.buttonClock.getTime())
                elif len(next3NGbreak.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next3NGbreak.timesOff[-1] = next3NGbreak.buttonClock.getTime()
                if not next3NGbreak.wasClicked:
                    # end routine when next3NGbreak is clicked
                    continueRoutine = False
                if not next3NGbreak.wasClicked:
                    # run callback code when next3NGbreak is clicked
                    pass
        # take note of whether next3NGbreak was clicked, so that next frame we know if clicks are new
        next3NGbreak.wasClicked = next3NGbreak.isClicked and next3NGbreak.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break3NG.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in break3NG.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break3NG" ---
    for thisComponent in break3NG.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break3NG
    break3NG.tStop = globalClock.getTime(format='float')
    break3NG.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break3NG.stopped', break3NG.tStop)
    thisExp.addData('next3NGbreak.numClicks', next3NGbreak.numClicks)
    if next3NGbreak.numClicks:
       thisExp.addData('next3NGbreak.timesOn', next3NGbreak.timesOn)
       thisExp.addData('next3NGbreak.timesOff', next3NGbreak.timesOff)
    else:
       thisExp.addData('next3NGbreak.timesOn', "")
       thisExp.addData('next3NGbreak.timesOff', "")
    thisExp.nextEntry()
    # the Routine "break3NG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirENG72 = data.TrialHandler2(
        name='SentirENG72',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimENG/Stimuli3ENG72.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirENG72)  # add the loop to the experiment
    thisSentirENG72 = SentirENG72.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirENG72.rgb)
    if thisSentirENG72 != None:
        for paramName in thisSentirENG72:
            globals()[paramName] = thisSentirENG72[paramName]
    
    for thisSentirENG72 in SentirENG72:
        currentLoop = SentirENG72
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # abbreviate parameter names if possible (e.g. rgb = thisSentirENG72.rgb)
        if thisSentirENG72 != None:
            for paramName in thisSentirENG72:
                globals()[paramName] = thisSentirENG72[paramName]
        
        # --- Prepare to start Routine "SentirENG_psychopy" ---
        # create an object to store info about Routine SentirENG_psychopy
        SentirENG_psychopy = data.Routine(
            name='SentirENG_psychopy',
            components=[question, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionslider, next3NGstim, donotknow3NG],
        )
        SentirENG_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionslider.reset()
        # reset next3NGstim to account for continued clicks & clear times on/off
        next3NGstim.reset()
        # reset donotknow3NG to account for continued clicks & clear times on/off
        donotknow3NG.reset()
        # store start times for SentirENG_psychopy
        SentirENG_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirENG_psychopy.tStart = globalClock.getTime(format='float')
        SentirENG_psychopy.status = STARTED
        thisExp.addData('SentirENG_psychopy.started', SentirENG_psychopy.tStart)
        SentirENG_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirENG_psychopyComponents = SentirENG_psychopy.components
        for thisComponent in SentirENG_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirENG_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirENG72, data.TrialHandler2) and thisSentirENG72.thisN != SentirENG72.thisTrial.thisN:
            continueRoutine = False
        SentirENG_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *question* updates
            
            # if question is starting this frame...
            if question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                question.frameNStart = frameN  # exact frame index
                question.tStart = t  # local t and not account for scr refresh
                question.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(question, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'question.started')
                # update status
                question.status = STARTED
                question.setAutoDraw(True)
            
            # if question is active this frame...
            if question.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionslider* updates
            
            # if interoceptionslider is starting this frame...
            if interoceptionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionslider.frameNStart = frameN  # exact frame index
                interoceptionslider.tStart = t  # local t and not account for scr refresh
                interoceptionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionslider.started')
                # update status
                interoceptionslider.status = STARTED
                interoceptionslider.setAutoDraw(True)
            
            # if interoceptionslider is active this frame...
            if interoceptionslider.status == STARTED:
                # update params
                pass
            # *next3NGstim* updates
            
            # if next3NGstim is starting this frame...
            if next3NGstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next3NGstim.frameNStart = frameN  # exact frame index
                next3NGstim.tStart = t  # local t and not account for scr refresh
                next3NGstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next3NGstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next3NGstim.started')
                # update status
                next3NGstim.status = STARTED
                win.callOnFlip(next3NGstim.buttonClock.reset)
                next3NGstim.setAutoDraw(True)
            
            # if next3NGstim is active this frame...
            if next3NGstim.status == STARTED:
                # update params
                pass
                # check whether next3NGstim has been pressed
                if next3NGstim.isClicked:
                    if not next3NGstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next3NGstim.timesOn.append(next3NGstim.buttonClock.getTime())
                        next3NGstim.timesOff.append(next3NGstim.buttonClock.getTime())
                    elif len(next3NGstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next3NGstim.timesOff[-1] = next3NGstim.buttonClock.getTime()
                    if not next3NGstim.wasClicked:
                        # end routine when next3NGstim is clicked
                        continueRoutine = False
                    if not next3NGstim.wasClicked:
                        # run callback code when next3NGstim is clicked
                        pass
            # take note of whether next3NGstim was clicked, so that next frame we know if clicks are new
            next3NGstim.wasClicked = next3NGstim.isClicked and next3NGstim.status == STARTED
            # *donotknow3NG* updates
            
            # if donotknow3NG is starting this frame...
            if donotknow3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                donotknow3NG.frameNStart = frameN  # exact frame index
                donotknow3NG.tStart = t  # local t and not account for scr refresh
                donotknow3NG.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(donotknow3NG, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'donotknow3NG.started')
                # update status
                donotknow3NG.status = STARTED
                win.callOnFlip(donotknow3NG.buttonClock.reset)
                donotknow3NG.setAutoDraw(True)
            
            # if donotknow3NG is active this frame...
            if donotknow3NG.status == STARTED:
                # update params
                pass
                # check whether donotknow3NG has been pressed
                if donotknow3NG.isClicked:
                    if not donotknow3NG.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        donotknow3NG.timesOn.append(donotknow3NG.buttonClock.getTime())
                        donotknow3NG.timesOff.append(donotknow3NG.buttonClock.getTime())
                    elif len(donotknow3NG.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        donotknow3NG.timesOff[-1] = donotknow3NG.buttonClock.getTime()
                    if not donotknow3NG.wasClicked:
                        # end routine when donotknow3NG is clicked
                        continueRoutine = False
                    if not donotknow3NG.wasClicked:
                        # run callback code when donotknow3NG is clicked
                        pass
            # take note of whether donotknow3NG was clicked, so that next frame we know if clicks are new
            donotknow3NG.wasClicked = donotknow3NG.isClicked and donotknow3NG.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirENG_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirENG_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirENG_psychopy" ---
        for thisComponent in SentirENG_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirENG_psychopy
        SentirENG_psychopy.tStop = globalClock.getTime(format='float')
        SentirENG_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirENG_psychopy.stopped', SentirENG_psychopy.tStop)
        SentirENG72.addData('auditionslider.response', auditionslider.getRating())
        SentirENG72.addData('auditionslider.rt', auditionslider.getRT())
        SentirENG72.addData('tasteslider.response', tasteslider.getRating())
        SentirENG72.addData('tasteslider.rt', tasteslider.getRT())
        SentirENG72.addData('hapticslider.response', hapticslider.getRating())
        SentirENG72.addData('hapticslider.rt', hapticslider.getRT())
        SentirENG72.addData('olfactionslider.response', olfactionslider.getRating())
        SentirENG72.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirENG72.addData('visionslider.response', visionslider.getRating())
        SentirENG72.addData('visionslider.rt', visionslider.getRT())
        SentirENG72.addData('interoceptionslider.response', interoceptionslider.getRating())
        SentirENG72.addData('interoceptionslider.rt', interoceptionslider.getRT())
        SentirENG72.addData('next3NGstim.numClicks', next3NGstim.numClicks)
        if next3NGstim.numClicks:
           SentirENG72.addData('next3NGstim.timesOn', next3NGstim.timesOn)
           SentirENG72.addData('next3NGstim.timesOff', next3NGstim.timesOff)
        else:
           SentirENG72.addData('next3NGstim.timesOn', "")
           SentirENG72.addData('next3NGstim.timesOff', "")
        SentirENG72.addData('donotknow3NG.numClicks', donotknow3NG.numClicks)
        if donotknow3NG.numClicks:
           SentirENG72.addData('donotknow3NG.timesOn', donotknow3NG.timesOn)
           SentirENG72.addData('donotknow3NG.timesOff', donotknow3NG.timesOff)
        else:
           SentirENG72.addData('donotknow3NG.timesOn', "")
           SentirENG72.addData('donotknow3NG.timesOff', "")
        # the Routine "SentirENG_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed 1.0 repeats of 'SentirENG72'
    
    
    # --- Prepare to start Routine "catch3NG3" ---
    # create an object to store info about Routine catch3NG3
    catch3NG3 = data.Routine(
        name='catch3NG3',
        components=[catch3NGfruit, sandwitch, coliflower, apple],
    )
    catch3NG3.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset sandwitch to account for continued clicks & clear times on/off
    sandwitch.reset()
    # reset coliflower to account for continued clicks & clear times on/off
    coliflower.reset()
    # reset apple to account for continued clicks & clear times on/off
    apple.reset()
    # store start times for catch3NG3
    catch3NG3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch3NG3.tStart = globalClock.getTime(format='float')
    catch3NG3.status = STARTED
    thisExp.addData('catch3NG3.started', catch3NG3.tStart)
    catch3NG3.maxDuration = None
    # keep track of which components have finished
    catch3NG3Components = catch3NG3.components
    for thisComponent in catch3NG3.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch3NG3" ---
    catch3NG3.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch3NGfruit* updates
        
        # if catch3NGfruit is starting this frame...
        if catch3NGfruit.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch3NGfruit.frameNStart = frameN  # exact frame index
            catch3NGfruit.tStart = t  # local t and not account for scr refresh
            catch3NGfruit.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch3NGfruit, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch3NGfruit.started')
            # update status
            catch3NGfruit.status = STARTED
            catch3NGfruit.setAutoDraw(True)
        
        # if catch3NGfruit is active this frame...
        if catch3NGfruit.status == STARTED:
            # update params
            pass
        # *sandwitch* updates
        
        # if sandwitch is starting this frame...
        if sandwitch.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            sandwitch.frameNStart = frameN  # exact frame index
            sandwitch.tStart = t  # local t and not account for scr refresh
            sandwitch.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sandwitch, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'sandwitch.started')
            # update status
            sandwitch.status = STARTED
            win.callOnFlip(sandwitch.buttonClock.reset)
            sandwitch.setAutoDraw(True)
        
        # if sandwitch is active this frame...
        if sandwitch.status == STARTED:
            # update params
            pass
            # check whether sandwitch has been pressed
            if sandwitch.isClicked:
                if not sandwitch.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    sandwitch.timesOn.append(sandwitch.buttonClock.getTime())
                    sandwitch.timesOff.append(sandwitch.buttonClock.getTime())
                elif len(sandwitch.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    sandwitch.timesOff[-1] = sandwitch.buttonClock.getTime()
                if not sandwitch.wasClicked:
                    # end routine when sandwitch is clicked
                    continueRoutine = False
                if not sandwitch.wasClicked:
                    # run callback code when sandwitch is clicked
                    pass
        # take note of whether sandwitch was clicked, so that next frame we know if clicks are new
        sandwitch.wasClicked = sandwitch.isClicked and sandwitch.status == STARTED
        # *coliflower* updates
        
        # if coliflower is starting this frame...
        if coliflower.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            coliflower.frameNStart = frameN  # exact frame index
            coliflower.tStart = t  # local t and not account for scr refresh
            coliflower.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(coliflower, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'coliflower.started')
            # update status
            coliflower.status = STARTED
            win.callOnFlip(coliflower.buttonClock.reset)
            coliflower.setAutoDraw(True)
        
        # if coliflower is active this frame...
        if coliflower.status == STARTED:
            # update params
            pass
            # check whether coliflower has been pressed
            if coliflower.isClicked:
                if not coliflower.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    coliflower.timesOn.append(coliflower.buttonClock.getTime())
                    coliflower.timesOff.append(coliflower.buttonClock.getTime())
                elif len(coliflower.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    coliflower.timesOff[-1] = coliflower.buttonClock.getTime()
                if not coliflower.wasClicked:
                    # end routine when coliflower is clicked
                    continueRoutine = False
                if not coliflower.wasClicked:
                    # run callback code when coliflower is clicked
                    pass
        # take note of whether coliflower was clicked, so that next frame we know if clicks are new
        coliflower.wasClicked = coliflower.isClicked and coliflower.status == STARTED
        # *apple* updates
        
        # if apple is starting this frame...
        if apple.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            apple.frameNStart = frameN  # exact frame index
            apple.tStart = t  # local t and not account for scr refresh
            apple.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(apple, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'apple.started')
            # update status
            apple.status = STARTED
            win.callOnFlip(apple.buttonClock.reset)
            apple.setAutoDraw(True)
        
        # if apple is active this frame...
        if apple.status == STARTED:
            # update params
            pass
            # check whether apple has been pressed
            if apple.isClicked:
                if not apple.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    apple.timesOn.append(apple.buttonClock.getTime())
                    apple.timesOff.append(apple.buttonClock.getTime())
                elif len(apple.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    apple.timesOff[-1] = apple.buttonClock.getTime()
                if not apple.wasClicked:
                    # end routine when apple is clicked
                    continueRoutine = False
                if not apple.wasClicked:
                    # run callback code when apple is clicked
                    pass
        # take note of whether apple was clicked, so that next frame we know if clicks are new
        apple.wasClicked = apple.isClicked and apple.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch3NG3.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch3NG3.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch3NG3" ---
    for thisComponent in catch3NG3.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch3NG3
    catch3NG3.tStop = globalClock.getTime(format='float')
    catch3NG3.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch3NG3.stopped', catch3NG3.tStop)
    thisExp.addData('sandwitch.numClicks', sandwitch.numClicks)
    if sandwitch.numClicks:
       thisExp.addData('sandwitch.timesOn', sandwitch.timesOn)
       thisExp.addData('sandwitch.timesOff', sandwitch.timesOff)
    else:
       thisExp.addData('sandwitch.timesOn', "")
       thisExp.addData('sandwitch.timesOff', "")
    thisExp.addData('coliflower.numClicks', coliflower.numClicks)
    if coliflower.numClicks:
       thisExp.addData('coliflower.timesOn', coliflower.timesOn)
       thisExp.addData('coliflower.timesOff', coliflower.timesOff)
    else:
       thisExp.addData('coliflower.timesOn', "")
       thisExp.addData('coliflower.timesOff', "")
    thisExp.addData('apple.numClicks', apple.numClicks)
    if apple.numClicks:
       thisExp.addData('apple.timesOn', apple.timesOn)
       thisExp.addData('apple.timesOff', apple.timesOff)
    else:
       thisExp.addData('apple.timesOn', "")
       thisExp.addData('apple.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch3NG3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SenitENG80 = data.TrialHandler2(
        name='SenitENG80',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimENG/Stimuli3ENG80.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SenitENG80)  # add the loop to the experiment
    thisSenitENG80 = SenitENG80.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSenitENG80.rgb)
    if thisSenitENG80 != None:
        for paramName in thisSenitENG80:
            globals()[paramName] = thisSenitENG80[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSenitENG80 in SenitENG80:
        currentLoop = SenitENG80
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSenitENG80.rgb)
        if thisSenitENG80 != None:
            for paramName in thisSenitENG80:
                globals()[paramName] = thisSenitENG80[paramName]
        
        # --- Prepare to start Routine "SentirENG_psychopy" ---
        # create an object to store info about Routine SentirENG_psychopy
        SentirENG_psychopy = data.Routine(
            name='SentirENG_psychopy',
            components=[question, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionslider, next3NGstim, donotknow3NG],
        )
        SentirENG_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionslider.reset()
        # reset next3NGstim to account for continued clicks & clear times on/off
        next3NGstim.reset()
        # reset donotknow3NG to account for continued clicks & clear times on/off
        donotknow3NG.reset()
        # store start times for SentirENG_psychopy
        SentirENG_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirENG_psychopy.tStart = globalClock.getTime(format='float')
        SentirENG_psychopy.status = STARTED
        thisExp.addData('SentirENG_psychopy.started', SentirENG_psychopy.tStart)
        SentirENG_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirENG_psychopyComponents = SentirENG_psychopy.components
        for thisComponent in SentirENG_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirENG_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SenitENG80, data.TrialHandler2) and thisSenitENG80.thisN != SenitENG80.thisTrial.thisN:
            continueRoutine = False
        SentirENG_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *question* updates
            
            # if question is starting this frame...
            if question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                question.frameNStart = frameN  # exact frame index
                question.tStart = t  # local t and not account for scr refresh
                question.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(question, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'question.started')
                # update status
                question.status = STARTED
                question.setAutoDraw(True)
            
            # if question is active this frame...
            if question.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionslider* updates
            
            # if interoceptionslider is starting this frame...
            if interoceptionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionslider.frameNStart = frameN  # exact frame index
                interoceptionslider.tStart = t  # local t and not account for scr refresh
                interoceptionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionslider.started')
                # update status
                interoceptionslider.status = STARTED
                interoceptionslider.setAutoDraw(True)
            
            # if interoceptionslider is active this frame...
            if interoceptionslider.status == STARTED:
                # update params
                pass
            # *next3NGstim* updates
            
            # if next3NGstim is starting this frame...
            if next3NGstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next3NGstim.frameNStart = frameN  # exact frame index
                next3NGstim.tStart = t  # local t and not account for scr refresh
                next3NGstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next3NGstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next3NGstim.started')
                # update status
                next3NGstim.status = STARTED
                win.callOnFlip(next3NGstim.buttonClock.reset)
                next3NGstim.setAutoDraw(True)
            
            # if next3NGstim is active this frame...
            if next3NGstim.status == STARTED:
                # update params
                pass
                # check whether next3NGstim has been pressed
                if next3NGstim.isClicked:
                    if not next3NGstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next3NGstim.timesOn.append(next3NGstim.buttonClock.getTime())
                        next3NGstim.timesOff.append(next3NGstim.buttonClock.getTime())
                    elif len(next3NGstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next3NGstim.timesOff[-1] = next3NGstim.buttonClock.getTime()
                    if not next3NGstim.wasClicked:
                        # end routine when next3NGstim is clicked
                        continueRoutine = False
                    if not next3NGstim.wasClicked:
                        # run callback code when next3NGstim is clicked
                        pass
            # take note of whether next3NGstim was clicked, so that next frame we know if clicks are new
            next3NGstim.wasClicked = next3NGstim.isClicked and next3NGstim.status == STARTED
            # *donotknow3NG* updates
            
            # if donotknow3NG is starting this frame...
            if donotknow3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                donotknow3NG.frameNStart = frameN  # exact frame index
                donotknow3NG.tStart = t  # local t and not account for scr refresh
                donotknow3NG.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(donotknow3NG, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'donotknow3NG.started')
                # update status
                donotknow3NG.status = STARTED
                win.callOnFlip(donotknow3NG.buttonClock.reset)
                donotknow3NG.setAutoDraw(True)
            
            # if donotknow3NG is active this frame...
            if donotknow3NG.status == STARTED:
                # update params
                pass
                # check whether donotknow3NG has been pressed
                if donotknow3NG.isClicked:
                    if not donotknow3NG.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        donotknow3NG.timesOn.append(donotknow3NG.buttonClock.getTime())
                        donotknow3NG.timesOff.append(donotknow3NG.buttonClock.getTime())
                    elif len(donotknow3NG.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        donotknow3NG.timesOff[-1] = donotknow3NG.buttonClock.getTime()
                    if not donotknow3NG.wasClicked:
                        # end routine when donotknow3NG is clicked
                        continueRoutine = False
                    if not donotknow3NG.wasClicked:
                        # run callback code when donotknow3NG is clicked
                        pass
            # take note of whether donotknow3NG was clicked, so that next frame we know if clicks are new
            donotknow3NG.wasClicked = donotknow3NG.isClicked and donotknow3NG.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirENG_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirENG_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirENG_psychopy" ---
        for thisComponent in SentirENG_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirENG_psychopy
        SentirENG_psychopy.tStop = globalClock.getTime(format='float')
        SentirENG_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirENG_psychopy.stopped', SentirENG_psychopy.tStop)
        SenitENG80.addData('auditionslider.response', auditionslider.getRating())
        SenitENG80.addData('auditionslider.rt', auditionslider.getRT())
        SenitENG80.addData('tasteslider.response', tasteslider.getRating())
        SenitENG80.addData('tasteslider.rt', tasteslider.getRT())
        SenitENG80.addData('hapticslider.response', hapticslider.getRating())
        SenitENG80.addData('hapticslider.rt', hapticslider.getRT())
        SenitENG80.addData('olfactionslider.response', olfactionslider.getRating())
        SenitENG80.addData('olfactionslider.rt', olfactionslider.getRT())
        SenitENG80.addData('visionslider.response', visionslider.getRating())
        SenitENG80.addData('visionslider.rt', visionslider.getRT())
        SenitENG80.addData('interoceptionslider.response', interoceptionslider.getRating())
        SenitENG80.addData('interoceptionslider.rt', interoceptionslider.getRT())
        SenitENG80.addData('next3NGstim.numClicks', next3NGstim.numClicks)
        if next3NGstim.numClicks:
           SenitENG80.addData('next3NGstim.timesOn', next3NGstim.timesOn)
           SenitENG80.addData('next3NGstim.timesOff', next3NGstim.timesOff)
        else:
           SenitENG80.addData('next3NGstim.timesOn', "")
           SenitENG80.addData('next3NGstim.timesOff', "")
        SenitENG80.addData('donotknow3NG.numClicks', donotknow3NG.numClicks)
        if donotknow3NG.numClicks:
           SenitENG80.addData('donotknow3NG.timesOn', donotknow3NG.timesOn)
           SenitENG80.addData('donotknow3NG.timesOff', donotknow3NG.timesOff)
        else:
           SenitENG80.addData('donotknow3NG.timesOn', "")
           SenitENG80.addData('donotknow3NG.timesOff', "")
        # the Routine "SentirENG_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SenitENG80'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "end" ---
    # create an object to store info about Routine end
    end = data.Routine(
        name='end',
        components=[end_y, end3NG],
    )
    end.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset end3NG to account for continued clicks & clear times on/off
    end3NG.reset()
    # store start times for end
    end.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    end.tStart = globalClock.getTime(format='float')
    end.status = STARTED
    thisExp.addData('end.started', end.tStart)
    end.maxDuration = None
    # keep track of which components have finished
    endComponents = end.components
    for thisComponent in end.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "end" ---
    end.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *end_y* updates
        
        # if end_y is starting this frame...
        if end_y.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            end_y.frameNStart = frameN  # exact frame index
            end_y.tStart = t  # local t and not account for scr refresh
            end_y.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(end_y, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'end_y.started')
            # update status
            end_y.status = STARTED
            end_y.setAutoDraw(True)
        
        # if end_y is active this frame...
        if end_y.status == STARTED:
            # update params
            pass
        # *end3NG* updates
        
        # if end3NG is starting this frame...
        if end3NG.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            end3NG.frameNStart = frameN  # exact frame index
            end3NG.tStart = t  # local t and not account for scr refresh
            end3NG.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(end3NG, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'end3NG.started')
            # update status
            end3NG.status = STARTED
            win.callOnFlip(end3NG.buttonClock.reset)
            end3NG.setAutoDraw(True)
        
        # if end3NG is active this frame...
        if end3NG.status == STARTED:
            # update params
            pass
            # check whether end3NG has been pressed
            if end3NG.isClicked:
                if not end3NG.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    end3NG.timesOn.append(end3NG.buttonClock.getTime())
                    end3NG.timesOff.append(end3NG.buttonClock.getTime())
                elif len(end3NG.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    end3NG.timesOff[-1] = end3NG.buttonClock.getTime()
                if not end3NG.wasClicked:
                    # end routine when end3NG is clicked
                    continueRoutine = False
                if not end3NG.wasClicked:
                    # run callback code when end3NG is clicked
                    pass
        # take note of whether end3NG was clicked, so that next frame we know if clicks are new
        end3NG.wasClicked = end3NG.isClicked and end3NG.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            end.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in end.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "end" ---
    for thisComponent in end.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for end
    end.tStop = globalClock.getTime(format='float')
    end.tStopRefresh = tThisFlipGlobal
    thisExp.addData('end.stopped', end.tStop)
    thisExp.addData('end3NG.numClicks', end3NG.numClicks)
    if end3NG.numClicks:
       thisExp.addData('end3NG.timesOn', end3NG.timesOn)
       thisExp.addData('end3NG.timesOff', end3NG.timesOff)
    else:
       thisExp.addData('end3NG.timesOn', "")
       thisExp.addData('end3NG.timesOff', "")
    thisExp.nextEntry()
    # the Routine "end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
