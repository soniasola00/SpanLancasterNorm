/****************************** 
 * Sentires_Psychopy_Fin *
 ******************************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2024.2.1.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'SentirES_psychopy_fin';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0,0,0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(warning_SPANRoutineBegin());
flowScheduler.add(warning_SPANRoutineEachFrame());
flowScheduler.add(warning_SPANRoutineEnd());
flowScheduler.add(instructions2PANRoutineBegin());
flowScheduler.add(instructions2PANRoutineEachFrame());
flowScheduler.add(instructions2PANRoutineEnd());
const SentirES2PAN19LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirES2PAN19LoopBegin(SentirES2PAN19LoopScheduler));
flowScheduler.add(SentirES2PAN19LoopScheduler);
flowScheduler.add(SentirES2PAN19LoopEnd);


flowScheduler.add(catch2PAN1RoutineBegin());
flowScheduler.add(catch2PAN1RoutineEachFrame());
flowScheduler.add(catch2PAN1RoutineEnd());
const SentirES2SPAN45LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirES2SPAN45LoopBegin(SentirES2SPAN45LoopScheduler));
flowScheduler.add(SentirES2SPAN45LoopScheduler);
flowScheduler.add(SentirES2SPAN45LoopEnd);


flowScheduler.add(catch2SPAN2RoutineBegin());
flowScheduler.add(catch2SPAN2RoutineEachFrame());
flowScheduler.add(catch2SPAN2RoutineEnd());
flowScheduler.add(break2PANRoutineBegin());
flowScheduler.add(break2PANRoutineEachFrame());
flowScheduler.add(break2PANRoutineEnd());
const SentirES2SPAN78LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirES2SPAN78LoopBegin(SentirES2SPAN78LoopScheduler));
flowScheduler.add(SentirES2SPAN78LoopScheduler);
flowScheduler.add(SentirES2SPAN78LoopEnd);


flowScheduler.add(catch2PAN3RoutineBegin());
flowScheduler.add(catch2PAN3RoutineEachFrame());
flowScheduler.add(catch2PAN3RoutineEnd());
const SentirES2SPAN80LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(SentirES2SPAN80LoopBegin(SentirES2SPAN80LoopScheduler));
flowScheduler.add(SentirES2SPAN80LoopScheduler);
flowScheduler.add(SentirES2SPAN80LoopEnd);


flowScheduler.add(finRoutineBegin());
flowScheduler.add(finRoutineEachFrame());
flowScheduler.add(finRoutineEnd());
flowScheduler.add(quitPsychoJS, 'Thank you for your patience.', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, 'Thank you for your patience.', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
    {'name': 'stimSPAN/Stimuli2PAN19.csv', 'path': 'stimSPAN/Stimuli2PAN19.csv'},
    {'name': 'stimSPAN/Stimuli2PAN45.csv', 'path': 'stimSPAN/Stimuli2PAN45.csv'},
    {'name': 'stimSPAN/Stimuli2PAN78.csv', 'path': 'stimSPAN/Stimuli2PAN78.csv'},
    {'name': 'stimSPAN/Stimuli2PAN80.csv', 'path': 'stimSPAN/Stimuli2PAN80.csv'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.INFO);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2024.2.1';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var warning_SPANClock;
var warning2PAN;
var next2PAN;
var instructions2PANClock;
var instructions2PANtext;
var next2PANinstr;
var SentirES_psychopyClock;
var pregunta;
var stimuli;
var audition;
var taste;
var haptic;
var olfaction;
var vision;
var interoception;
var auditionslider;
var tasteslider;
var hapticslider;
var olfactionslider;
var visionslider;
var interoceptionsslider;
var next2PANstim;
var nose2PAN;
var catch2PAN1Clock;
var catch2PANanimal;
var Oso;
var Pez;
var Ave;
var catch2SPAN2Clock;
var catch2PANmates;
var quinze;
var setentaydos;
var cien;
var break2PANClock;
var SentirESbreak;
var next2PANbreak;
var catch2PAN3Clock;
var catch2PANfruta;
var bocadillo;
var coliflor;
var manzana;
var finClock;
var fin_y;
var fin2PAN;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "warning_SPAN"
  warning_SPANClock = new util.Clock();
  warning2PAN = new visual.TextStim({
    win: psychoJS.window,
    name: 'warning2PAN',
    text: 'ADERTENCIA\nEste estudio usa palabras cotidianas. De vez en cuando esto significa que aparecen palabras que pueden ser explicitas u ofensivas. Si se siente incomodo en cualquier momento eres libre de terminar la encuesta cerrando la ventana.\n\nPara continuar pulsa "Siguiente"\'',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next2PAN = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next2PAN',
    text: 'Siguente',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next2PAN.clock = new util.Clock();
  
  // Initialize components for Routine "instructions2PAN"
  instructions2PANClock = new util.Clock();
  instructions2PANtext = new visual.TextStim({
    win: psychoJS.window,
    name: 'instructions2PANtext',
    text: 'INSTRUCCIONES\n\nLes vamos a preguntar cómo percibes palabras frecuentes usando seis sentidos corporales. No hay respuestas correctas ni incorrectas. La medida es de 0 (nunca lo percibes usando esa sensación corporal) hasta 5 (interactúas mucho usando esa sensación corporal). Haz click en el número y cuando ya haya rellenado las seis sensaciones pulsa el botón "Siguiente" para empezar la siguiente palabra.Si no reconoce una palabra pulsa “No se esta palabra" y haz click al "Siguente" para continuar.',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next2PANinstr = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next2PANinstr',
    text: 'Siguente',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next2PANinstr.clock = new util.Clock();
  
  // Initialize components for Routine "SentirES_psychopy"
  SentirES_psychopyClock = new util.Clock();
  pregunta = new visual.TextStim({
    win: psychoJS.window,
    name: 'pregunta',
    text: 'Comó percibes',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.4), 0.4], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  stimuli = new visual.TextStim({
    win: psychoJS.window,
    name: 'stimuli',
    text: '',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.4), 0.3], draggable: false, height: 0.045,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -1.0 
  });
  
  audition = new visual.TextStim({
    win: psychoJS.window,
    name: 'audition',
    text: 'usando audicion',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0.2], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -2.0 
  });
  
  taste = new visual.TextStim({
    win: psychoJS.window,
    name: 'taste',
    text: 'usando sabor',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0.1], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -3.0 
  });
  
  haptic = new visual.TextStim({
    win: psychoJS.window,
    name: 'haptic',
    text: 'usando tacto',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), 0], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -4.0 
  });
  
  olfaction = new visual.TextStim({
    win: psychoJS.window,
    name: 'olfaction',
    text: 'usando olor',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -5.0 
  });
  
  vision = new visual.TextStim({
    win: psychoJS.window,
    name: 'vision',
    text: 'usando vision',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -6.0 
  });
  
  interoception = new visual.TextStim({
    win: psychoJS.window,
    name: 'interoception',
    text: 'usando sensaciones \nintracorporales',
    font: 'Arial',
    units: 'height', 
    pos: [(- 0.52), (- 0.3)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('White'),  opacity: 1.0,
    depth: -7.0 
  });
  
  auditionslider = new visual.Slider({
    win: psychoJS.window, name: 'auditionslider',
    startValue: 0,
    size: [0.7, 0.05], pos: [0, 0.2], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -8, 
    flip: false,
  });
  
  tasteslider = new visual.Slider({
    win: psychoJS.window, name: 'tasteslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, 0.1], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -9, 
    flip: false,
  });
  
  hapticslider = new visual.Slider({
    win: psychoJS.window, name: 'hapticslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, 0], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -10, 
    flip: false,
  });
  
  olfactionslider = new visual.Slider({
    win: psychoJS.window, name: 'olfactionslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.1)], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: 1.0, fontFamily: 'Arial', bold: true, italic: false, depth: -11, 
    flip: false,
  });
  
  visionslider = new visual.Slider({
    win: psychoJS.window, name: 'visionslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.2)], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -12, 
    flip: false,
  });
  
  interoceptionsslider = new visual.Slider({
    win: psychoJS.window, name: 'interoceptionsslider',
    startValue: undefined,
    size: [0.7, 0.05], pos: [0, (- 0.3)], ori: 0.0, units: 'height',
    labels: ["nada", "totalmente"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color('White'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -13, 
    flip: false,
  });
  
  next2PANstim = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next2PANstim',
    text: 'Siguente',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -14
  });
  next2PANstim.clock = new util.Clock();
  
  nose2PAN = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'nose2PAN',
    text: 'no sé esta palabra',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.55, 0.3],
    letterHeight: 0.03,
    size: [0.4, 0.2],
    ori: 0.0
    ,
    depth: -15
  });
  nose2PAN.clock = new util.Clock();
  
  // Initialize components for Routine "catch2PAN1"
  catch2PAN1Clock = new util.Clock();
  catch2PANanimal = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch2PANanimal',
    text: 'Eliga el animal que vuela.',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  Oso = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Oso',
    text: 'Oso',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  Oso.clock = new util.Clock();
  
  Pez = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Pez',
    text: 'Pez',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  Pez.clock = new util.Clock();
  
  Ave = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Ave',
    text: 'Ave',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  Ave.clock = new util.Clock();
  
  // Initialize components for Routine "catch2SPAN2"
  catch2SPAN2Clock = new util.Clock();
  catch2PANmates = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch2PANmates',
    text: 'Que es 5 x 3?',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  quinze = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'quinze',
    text: '15',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  quinze.clock = new util.Clock();
  
  setentaydos = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'setentaydos',
    text: '72',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  setentaydos.clock = new util.Clock();
  
  cien = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'cien',
    text: '100',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  cien.clock = new util.Clock();
  
  // Initialize components for Routine "break2PAN"
  break2PANClock = new util.Clock();
  SentirESbreak = new visual.TextStim({
    win: psychoJS.window,
    name: 'SentirESbreak',
    text: 'Si lo deseas toma un pequeño descanso aqui. Pulse "Siguente" para continuar con el experimento',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  next2PANbreak = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'next2PANbreak',
    text: 'Siguente',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, (- 0.4)],
    letterHeight: 0.03,
    size: [0.2, 0.2],
    ori: 0.0
    ,
    depth: -1
  });
  next2PANbreak.clock = new util.Clock();
  
  // Initialize components for Routine "catch2PAN3"
  catch2PAN3Clock = new util.Clock();
  catch2PANfruta = new visual.TextStim({
    win: psychoJS.window,
    name: 'catch2PANfruta',
    text: 'Cual es una fruta?',
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.06,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  bocadillo = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'bocadillo',
    text: 'bacadillo',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [(- 0.5), 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -1
  });
  bocadillo.clock = new util.Clock();
  
  coliflor = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'coliflor',
    text: 'coliflor',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -2
  });
  coliflor.clock = new util.Clock();
  
  manzana = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'manzana',
    text: 'manzana',
    fillColor: 'darkgrey',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0],
    letterHeight: 0.04,
    size: [0.3, 0.3],
    ori: 0.0
    ,
    depth: -3
  });
  manzana.clock = new util.Clock();
  
  // Initialize components for Routine "fin"
  finClock = new util.Clock();
  fin_y = new visual.TextStim({
    win: psychoJS.window,
    name: 'fin_y',
    text: "Gracais por su particpacion!\nPulse 'fin' para finalizar este estudio",
    font: 'Arial',
    units: 'height', 
    pos: [0, 0.3], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: 0.0 
  });
  
  fin2PAN = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'fin2PAN',
    text: 'fin',
    fillColor: [(- 1.0), 0.0902, 0.0902],
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0, 0],
    letterHeight: 0.05,
    size: [0.5, 0.5],
    ori: 0.0
    ,
    depth: -1
  });
  fin2PAN.clock = new util.Clock();
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var warning_SPANMaxDurationReached;
var warning_SPANMaxDuration;
var warning_SPANComponents;
function warning_SPANRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'warning_SPAN' ---
    t = 0;
    warning_SPANClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    warning_SPANMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next2PAN to account for continued clicks & clear times on/off
    next2PAN.reset()
    psychoJS.experiment.addData('warning_SPAN.started', globalClock.getTime());
    warning_SPANMaxDuration = null
    // keep track of which components have finished
    warning_SPANComponents = [];
    warning_SPANComponents.push(warning2PAN);
    warning_SPANComponents.push(next2PAN);
    
    for (const thisComponent of warning_SPANComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function warning_SPANRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'warning_SPAN' ---
    // get current time
    t = warning_SPANClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *warning2PAN* updates
    if (t >= 0.0 && warning2PAN.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      warning2PAN.tStart = t;  // (not accounting for frame time here)
      warning2PAN.frameNStart = frameN;  // exact frame index
      
      warning2PAN.setAutoDraw(true);
    }
    
    
    // *next2PAN* updates
    if (t >= 0 && next2PAN.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next2PAN.tStart = t;  // (not accounting for frame time here)
      next2PAN.frameNStart = frameN;  // exact frame index
      
      next2PAN.setAutoDraw(true);
    }
    
    if (next2PAN.status === PsychoJS.Status.STARTED) {
      // check whether next2PAN has been pressed
      if (next2PAN.isClicked) {
        if (!next2PAN.wasClicked) {
          // store time of first click
          next2PAN.timesOn.push(next2PAN.clock.getTime());
          // store time clicked until
          next2PAN.timesOff.push(next2PAN.clock.getTime());
        } else {
          // update time clicked until;
          next2PAN.timesOff[next2PAN.timesOff.length - 1] = next2PAN.clock.getTime();
        }
        if (!next2PAN.wasClicked) {
          // end routine when next2PAN is clicked
          continueRoutine = false;
          
        }
        // if next2PAN is still clicked next frame, it is not a new click
        next2PAN.wasClicked = true;
      } else {
        // if next2PAN is clicked next frame, it is a new click
        next2PAN.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next2PAN hasn't started / has finished
      next2PAN.clock.reset();
      // if next2PAN is clicked next frame, it is a new click
      next2PAN.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of warning_SPANComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function warning_SPANRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'warning_SPAN' ---
    for (const thisComponent of warning_SPANComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('warning_SPAN.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next2PAN.numClicks', next2PAN.numClicks);
    psychoJS.experiment.addData('next2PAN.timesOn', next2PAN.timesOn);
    psychoJS.experiment.addData('next2PAN.timesOff', next2PAN.timesOff);
    // the Routine "warning_SPAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var instructions2PANMaxDurationReached;
var instructions2PANMaxDuration;
var instructions2PANComponents;
function instructions2PANRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions2PAN' ---
    t = 0;
    instructions2PANClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    instructions2PANMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next2PANinstr to account for continued clicks & clear times on/off
    next2PANinstr.reset()
    psychoJS.experiment.addData('instructions2PAN.started', globalClock.getTime());
    instructions2PANMaxDuration = null
    // keep track of which components have finished
    instructions2PANComponents = [];
    instructions2PANComponents.push(instructions2PANtext);
    instructions2PANComponents.push(next2PANinstr);
    
    for (const thisComponent of instructions2PANComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instructions2PANRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions2PAN' ---
    // get current time
    t = instructions2PANClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instructions2PANtext* updates
    if (t >= 0.0 && instructions2PANtext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instructions2PANtext.tStart = t;  // (not accounting for frame time here)
      instructions2PANtext.frameNStart = frameN;  // exact frame index
      
      instructions2PANtext.setAutoDraw(true);
    }
    
    
    // *next2PANinstr* updates
    if (t >= 0 && next2PANinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next2PANinstr.tStart = t;  // (not accounting for frame time here)
      next2PANinstr.frameNStart = frameN;  // exact frame index
      
      next2PANinstr.setAutoDraw(true);
    }
    
    if (next2PANinstr.status === PsychoJS.Status.STARTED) {
      // check whether next2PANinstr has been pressed
      if (next2PANinstr.isClicked) {
        if (!next2PANinstr.wasClicked) {
          // store time of first click
          next2PANinstr.timesOn.push(next2PANinstr.clock.getTime());
          // store time clicked until
          next2PANinstr.timesOff.push(next2PANinstr.clock.getTime());
        } else {
          // update time clicked until;
          next2PANinstr.timesOff[next2PANinstr.timesOff.length - 1] = next2PANinstr.clock.getTime();
        }
        if (!next2PANinstr.wasClicked) {
          // end routine when next2PANinstr is clicked
          continueRoutine = false;
          
        }
        // if next2PANinstr is still clicked next frame, it is not a new click
        next2PANinstr.wasClicked = true;
      } else {
        // if next2PANinstr is clicked next frame, it is a new click
        next2PANinstr.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next2PANinstr hasn't started / has finished
      next2PANinstr.clock.reset();
      // if next2PANinstr is clicked next frame, it is a new click
      next2PANinstr.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructions2PANComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructions2PANRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions2PAN' ---
    for (const thisComponent of instructions2PANComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('instructions2PAN.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next2PANinstr.numClicks', next2PANinstr.numClicks);
    psychoJS.experiment.addData('next2PANinstr.timesOn', next2PANinstr.timesOn);
    psychoJS.experiment.addData('next2PANinstr.timesOff', next2PANinstr.timesOff);
    // the Routine "instructions2PAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SentirES2PAN19;
function SentirES2PAN19LoopBegin(SentirES2PAN19LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirES2PAN19 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimSPAN/Stimuli2PAN19.csv',
      seed: undefined, name: 'SentirES2PAN19'
    });
    psychoJS.experiment.addLoop(SentirES2PAN19); // add the loop to the experiment
    currentLoop = SentirES2PAN19;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirES2PAN19 of SentirES2PAN19) {
      snapshot = SentirES2PAN19.getSnapshot();
      SentirES2PAN19LoopScheduler.add(importConditions(snapshot));
      SentirES2PAN19LoopScheduler.add(SentirES_psychopyRoutineBegin(snapshot));
      SentirES2PAN19LoopScheduler.add(SentirES_psychopyRoutineEachFrame());
      SentirES2PAN19LoopScheduler.add(SentirES_psychopyRoutineEnd(snapshot));
      SentirES2PAN19LoopScheduler.add(SentirES2PAN19LoopEndIteration(SentirES2PAN19LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirES2PAN19LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirES2PAN19);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirES2PAN19LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirES2SPAN45;
function SentirES2SPAN45LoopBegin(SentirES2SPAN45LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirES2SPAN45 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimSPAN/Stimuli2PAN45.csv',
      seed: undefined, name: 'SentirES2SPAN45'
    });
    psychoJS.experiment.addLoop(SentirES2SPAN45); // add the loop to the experiment
    currentLoop = SentirES2SPAN45;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirES2SPAN45 of SentirES2SPAN45) {
      snapshot = SentirES2SPAN45.getSnapshot();
      SentirES2SPAN45LoopScheduler.add(importConditions(snapshot));
      SentirES2SPAN45LoopScheduler.add(SentirES_psychopyRoutineBegin(snapshot));
      SentirES2SPAN45LoopScheduler.add(SentirES_psychopyRoutineEachFrame());
      SentirES2SPAN45LoopScheduler.add(SentirES_psychopyRoutineEnd(snapshot));
      SentirES2SPAN45LoopScheduler.add(SentirES2SPAN45LoopEndIteration(SentirES2SPAN45LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirES2SPAN45LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirES2SPAN45);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirES2SPAN45LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirES2SPAN78;
function SentirES2SPAN78LoopBegin(SentirES2SPAN78LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirES2SPAN78 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimSPAN/Stimuli2PAN78.csv',
      seed: undefined, name: 'SentirES2SPAN78'
    });
    psychoJS.experiment.addLoop(SentirES2SPAN78); // add the loop to the experiment
    currentLoop = SentirES2SPAN78;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirES2SPAN78 of SentirES2SPAN78) {
      snapshot = SentirES2SPAN78.getSnapshot();
      SentirES2SPAN78LoopScheduler.add(importConditions(snapshot));
      SentirES2SPAN78LoopScheduler.add(SentirES_psychopyRoutineBegin(snapshot));
      SentirES2SPAN78LoopScheduler.add(SentirES_psychopyRoutineEachFrame());
      SentirES2SPAN78LoopScheduler.add(SentirES_psychopyRoutineEnd(snapshot));
      SentirES2SPAN78LoopScheduler.add(SentirES2SPAN78LoopEndIteration(SentirES2SPAN78LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirES2SPAN78LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirES2SPAN78);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirES2SPAN78LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirES2SPAN80;
function SentirES2SPAN80LoopBegin(SentirES2SPAN80LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    SentirES2SPAN80 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'stimSPAN/Stimuli2PAN80.csv',
      seed: undefined, name: 'SentirES2SPAN80'
    });
    psychoJS.experiment.addLoop(SentirES2SPAN80); // add the loop to the experiment
    currentLoop = SentirES2SPAN80;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisSentirES2SPAN80 of SentirES2SPAN80) {
      snapshot = SentirES2SPAN80.getSnapshot();
      SentirES2SPAN80LoopScheduler.add(importConditions(snapshot));
      SentirES2SPAN80LoopScheduler.add(SentirES_psychopyRoutineBegin(snapshot));
      SentirES2SPAN80LoopScheduler.add(SentirES_psychopyRoutineEachFrame());
      SentirES2SPAN80LoopScheduler.add(SentirES_psychopyRoutineEnd(snapshot));
      SentirES2SPAN80LoopScheduler.add(SentirES2SPAN80LoopEndIteration(SentirES2SPAN80LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function SentirES2SPAN80LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(SentirES2SPAN80);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function SentirES2SPAN80LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var SentirES_psychopyMaxDurationReached;
var SentirES_psychopyMaxDuration;
var SentirES_psychopyComponents;
function SentirES_psychopyRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SentirES_psychopy' ---
    t = 0;
    SentirES_psychopyClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    SentirES_psychopyMaxDurationReached = false;
    // update component parameters for each repeat
    stimuli.setText(Word);
    auditionslider.reset()
    tasteslider.reset()
    hapticslider.reset()
    olfactionslider.reset()
    visionslider.reset()
    interoceptionsslider.reset()
    // reset next2PANstim to account for continued clicks & clear times on/off
    next2PANstim.reset()
    // reset nose2PAN to account for continued clicks & clear times on/off
    nose2PAN.reset()
    psychoJS.experiment.addData('SentirES_psychopy.started', globalClock.getTime());
    SentirES_psychopyMaxDuration = null
    // keep track of which components have finished
    SentirES_psychopyComponents = [];
    SentirES_psychopyComponents.push(pregunta);
    SentirES_psychopyComponents.push(stimuli);
    SentirES_psychopyComponents.push(audition);
    SentirES_psychopyComponents.push(taste);
    SentirES_psychopyComponents.push(haptic);
    SentirES_psychopyComponents.push(olfaction);
    SentirES_psychopyComponents.push(vision);
    SentirES_psychopyComponents.push(interoception);
    SentirES_psychopyComponents.push(auditionslider);
    SentirES_psychopyComponents.push(tasteslider);
    SentirES_psychopyComponents.push(hapticslider);
    SentirES_psychopyComponents.push(olfactionslider);
    SentirES_psychopyComponents.push(visionslider);
    SentirES_psychopyComponents.push(interoceptionsslider);
    SentirES_psychopyComponents.push(next2PANstim);
    SentirES_psychopyComponents.push(nose2PAN);
    
    for (const thisComponent of SentirES_psychopyComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function SentirES_psychopyRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'SentirES_psychopy' ---
    // get current time
    t = SentirES_psychopyClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *pregunta* updates
    if (t >= 0.0 && pregunta.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      pregunta.tStart = t;  // (not accounting for frame time here)
      pregunta.frameNStart = frameN;  // exact frame index
      
      pregunta.setAutoDraw(true);
    }
    
    
    // *stimuli* updates
    if (t >= 0.0 && stimuli.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      stimuli.tStart = t;  // (not accounting for frame time here)
      stimuli.frameNStart = frameN;  // exact frame index
      
      stimuli.setAutoDraw(true);
    }
    
    
    // *audition* updates
    if (t >= 0.0 && audition.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      audition.tStart = t;  // (not accounting for frame time here)
      audition.frameNStart = frameN;  // exact frame index
      
      audition.setAutoDraw(true);
    }
    
    
    // *taste* updates
    if (t >= 0.0 && taste.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      taste.tStart = t;  // (not accounting for frame time here)
      taste.frameNStart = frameN;  // exact frame index
      
      taste.setAutoDraw(true);
    }
    
    
    // *haptic* updates
    if (t >= 0.0 && haptic.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      haptic.tStart = t;  // (not accounting for frame time here)
      haptic.frameNStart = frameN;  // exact frame index
      
      haptic.setAutoDraw(true);
    }
    
    
    // *olfaction* updates
    if (t >= 0.0 && olfaction.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      olfaction.tStart = t;  // (not accounting for frame time here)
      olfaction.frameNStart = frameN;  // exact frame index
      
      olfaction.setAutoDraw(true);
    }
    
    
    // *vision* updates
    if (t >= 0.0 && vision.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vision.tStart = t;  // (not accounting for frame time here)
      vision.frameNStart = frameN;  // exact frame index
      
      vision.setAutoDraw(true);
    }
    
    
    // *interoception* updates
    if (t >= 0.0 && interoception.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      interoception.tStart = t;  // (not accounting for frame time here)
      interoception.frameNStart = frameN;  // exact frame index
      
      interoception.setAutoDraw(true);
    }
    
    
    // *auditionslider* updates
    if (t >= 0.0 && auditionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      auditionslider.tStart = t;  // (not accounting for frame time here)
      auditionslider.frameNStart = frameN;  // exact frame index
      
      auditionslider.setAutoDraw(true);
    }
    
    
    // *tasteslider* updates
    if (t >= 0.0 && tasteslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      tasteslider.tStart = t;  // (not accounting for frame time here)
      tasteslider.frameNStart = frameN;  // exact frame index
      
      tasteslider.setAutoDraw(true);
    }
    
    
    // *hapticslider* updates
    if (t >= 0.0 && hapticslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      hapticslider.tStart = t;  // (not accounting for frame time here)
      hapticslider.frameNStart = frameN;  // exact frame index
      
      hapticslider.setAutoDraw(true);
    }
    
    
    // *olfactionslider* updates
    if (t >= 0.0 && olfactionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      olfactionslider.tStart = t;  // (not accounting for frame time here)
      olfactionslider.frameNStart = frameN;  // exact frame index
      
      olfactionslider.setAutoDraw(true);
    }
    
    
    // *visionslider* updates
    if (t >= 0.0 && visionslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      visionslider.tStart = t;  // (not accounting for frame time here)
      visionslider.frameNStart = frameN;  // exact frame index
      
      visionslider.setAutoDraw(true);
    }
    
    
    // *interoceptionsslider* updates
    if (t >= 0.0 && interoceptionsslider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      interoceptionsslider.tStart = t;  // (not accounting for frame time here)
      interoceptionsslider.frameNStart = frameN;  // exact frame index
      
      interoceptionsslider.setAutoDraw(true);
    }
    
    
    // *next2PANstim* updates
    if (t >= 0 && next2PANstim.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next2PANstim.tStart = t;  // (not accounting for frame time here)
      next2PANstim.frameNStart = frameN;  // exact frame index
      
      next2PANstim.setAutoDraw(true);
    }
    
    if (next2PANstim.status === PsychoJS.Status.STARTED) {
      // check whether next2PANstim has been pressed
      if (next2PANstim.isClicked) {
        if (!next2PANstim.wasClicked) {
          // store time of first click
          next2PANstim.timesOn.push(next2PANstim.clock.getTime());
          // store time clicked until
          next2PANstim.timesOff.push(next2PANstim.clock.getTime());
        } else {
          // update time clicked until;
          next2PANstim.timesOff[next2PANstim.timesOff.length - 1] = next2PANstim.clock.getTime();
        }
        if (!next2PANstim.wasClicked) {
          // end routine when next2PANstim is clicked
          continueRoutine = false;
          
        }
        // if next2PANstim is still clicked next frame, it is not a new click
        next2PANstim.wasClicked = true;
      } else {
        // if next2PANstim is clicked next frame, it is a new click
        next2PANstim.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next2PANstim hasn't started / has finished
      next2PANstim.clock.reset();
      // if next2PANstim is clicked next frame, it is a new click
      next2PANstim.wasClicked = false;
    }
    
    // *nose2PAN* updates
    if (t >= 0 && nose2PAN.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      nose2PAN.tStart = t;  // (not accounting for frame time here)
      nose2PAN.frameNStart = frameN;  // exact frame index
      
      nose2PAN.setAutoDraw(true);
    }
    
    if (nose2PAN.status === PsychoJS.Status.STARTED) {
      // check whether nose2PAN has been pressed
      if (nose2PAN.isClicked) {
        if (!nose2PAN.wasClicked) {
          // store time of first click
          nose2PAN.timesOn.push(nose2PAN.clock.getTime());
          // store time clicked until
          nose2PAN.timesOff.push(nose2PAN.clock.getTime());
        } else {
          // update time clicked until;
          nose2PAN.timesOff[nose2PAN.timesOff.length - 1] = nose2PAN.clock.getTime();
        }
        if (!nose2PAN.wasClicked) {
          // end routine when nose2PAN is clicked
          continueRoutine = false;
          
        }
        // if nose2PAN is still clicked next frame, it is not a new click
        nose2PAN.wasClicked = true;
      } else {
        // if nose2PAN is clicked next frame, it is a new click
        nose2PAN.wasClicked = false;
      }
    } else {
      // keep clock at 0 if nose2PAN hasn't started / has finished
      nose2PAN.clock.reset();
      // if nose2PAN is clicked next frame, it is a new click
      nose2PAN.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of SentirES_psychopyComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function SentirES_psychopyRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SentirES_psychopy' ---
    for (const thisComponent of SentirES_psychopyComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('SentirES_psychopy.stopped', globalClock.getTime());
    psychoJS.experiment.addData('auditionslider.response', auditionslider.getRating());
    psychoJS.experiment.addData('auditionslider.rt', auditionslider.getRT());
    psychoJS.experiment.addData('tasteslider.response', tasteslider.getRating());
    psychoJS.experiment.addData('tasteslider.rt', tasteslider.getRT());
    psychoJS.experiment.addData('hapticslider.response', hapticslider.getRating());
    psychoJS.experiment.addData('hapticslider.rt', hapticslider.getRT());
    psychoJS.experiment.addData('olfactionslider.response', olfactionslider.getRating());
    psychoJS.experiment.addData('olfactionslider.rt', olfactionslider.getRT());
    psychoJS.experiment.addData('visionslider.response', visionslider.getRating());
    psychoJS.experiment.addData('visionslider.rt', visionslider.getRT());
    psychoJS.experiment.addData('interoceptionsslider.response', interoceptionsslider.getRating());
    psychoJS.experiment.addData('interoceptionsslider.rt', interoceptionsslider.getRT());
    psychoJS.experiment.addData('next2PANstim.numClicks', next2PANstim.numClicks);
    psychoJS.experiment.addData('next2PANstim.timesOn', next2PANstim.timesOn);
    psychoJS.experiment.addData('next2PANstim.timesOff', next2PANstim.timesOff);
    psychoJS.experiment.addData('nose2PAN.numClicks', nose2PAN.numClicks);
    psychoJS.experiment.addData('nose2PAN.timesOn', nose2PAN.timesOn);
    psychoJS.experiment.addData('nose2PAN.timesOff', nose2PAN.timesOff);
    // the Routine "SentirES_psychopy" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch2PAN1MaxDurationReached;
var catch2PAN1MaxDuration;
var catch2PAN1Components;
function catch2PAN1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch2PAN1' ---
    t = 0;
    catch2PAN1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch2PAN1MaxDurationReached = false;
    // update component parameters for each repeat
    // reset Oso to account for continued clicks & clear times on/off
    Oso.reset()
    // reset Pez to account for continued clicks & clear times on/off
    Pez.reset()
    // reset Ave to account for continued clicks & clear times on/off
    Ave.reset()
    psychoJS.experiment.addData('catch2PAN1.started', globalClock.getTime());
    catch2PAN1MaxDuration = null
    // keep track of which components have finished
    catch2PAN1Components = [];
    catch2PAN1Components.push(catch2PANanimal);
    catch2PAN1Components.push(Oso);
    catch2PAN1Components.push(Pez);
    catch2PAN1Components.push(Ave);
    
    for (const thisComponent of catch2PAN1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch2PAN1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch2PAN1' ---
    // get current time
    t = catch2PAN1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch2PANanimal* updates
    if (t >= 0.0 && catch2PANanimal.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch2PANanimal.tStart = t;  // (not accounting for frame time here)
      catch2PANanimal.frameNStart = frameN;  // exact frame index
      
      catch2PANanimal.setAutoDraw(true);
    }
    
    
    // *Oso* updates
    if (t >= 0 && Oso.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Oso.tStart = t;  // (not accounting for frame time here)
      Oso.frameNStart = frameN;  // exact frame index
      
      Oso.setAutoDraw(true);
    }
    
    if (Oso.status === PsychoJS.Status.STARTED) {
      // check whether Oso has been pressed
      if (Oso.isClicked) {
        if (!Oso.wasClicked) {
          // store time of first click
          Oso.timesOn.push(Oso.clock.getTime());
          // store time clicked until
          Oso.timesOff.push(Oso.clock.getTime());
        } else {
          // update time clicked until;
          Oso.timesOff[Oso.timesOff.length - 1] = Oso.clock.getTime();
        }
        if (!Oso.wasClicked) {
          // end routine when Oso is clicked
          continueRoutine = false;
          
        }
        // if Oso is still clicked next frame, it is not a new click
        Oso.wasClicked = true;
      } else {
        // if Oso is clicked next frame, it is a new click
        Oso.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Oso hasn't started / has finished
      Oso.clock.reset();
      // if Oso is clicked next frame, it is a new click
      Oso.wasClicked = false;
    }
    
    // *Pez* updates
    if (t >= 0 && Pez.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Pez.tStart = t;  // (not accounting for frame time here)
      Pez.frameNStart = frameN;  // exact frame index
      
      Pez.setAutoDraw(true);
    }
    
    if (Pez.status === PsychoJS.Status.STARTED) {
      // check whether Pez has been pressed
      if (Pez.isClicked) {
        if (!Pez.wasClicked) {
          // store time of first click
          Pez.timesOn.push(Pez.clock.getTime());
          // store time clicked until
          Pez.timesOff.push(Pez.clock.getTime());
        } else {
          // update time clicked until;
          Pez.timesOff[Pez.timesOff.length - 1] = Pez.clock.getTime();
        }
        if (!Pez.wasClicked) {
          // end routine when Pez is clicked
          continueRoutine = false;
          
        }
        // if Pez is still clicked next frame, it is not a new click
        Pez.wasClicked = true;
      } else {
        // if Pez is clicked next frame, it is a new click
        Pez.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Pez hasn't started / has finished
      Pez.clock.reset();
      // if Pez is clicked next frame, it is a new click
      Pez.wasClicked = false;
    }
    
    // *Ave* updates
    if (t >= 0 && Ave.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Ave.tStart = t;  // (not accounting for frame time here)
      Ave.frameNStart = frameN;  // exact frame index
      
      Ave.setAutoDraw(true);
    }
    
    if (Ave.status === PsychoJS.Status.STARTED) {
      // check whether Ave has been pressed
      if (Ave.isClicked) {
        if (!Ave.wasClicked) {
          // store time of first click
          Ave.timesOn.push(Ave.clock.getTime());
          // store time clicked until
          Ave.timesOff.push(Ave.clock.getTime());
        } else {
          // update time clicked until;
          Ave.timesOff[Ave.timesOff.length - 1] = Ave.clock.getTime();
        }
        if (!Ave.wasClicked) {
          // end routine when Ave is clicked
          continueRoutine = false;
          
        }
        // if Ave is still clicked next frame, it is not a new click
        Ave.wasClicked = true;
      } else {
        // if Ave is clicked next frame, it is a new click
        Ave.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Ave hasn't started / has finished
      Ave.clock.reset();
      // if Ave is clicked next frame, it is a new click
      Ave.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch2PAN1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch2PAN1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch2PAN1' ---
    for (const thisComponent of catch2PAN1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch2PAN1.stopped', globalClock.getTime());
    psychoJS.experiment.addData('Oso.numClicks', Oso.numClicks);
    psychoJS.experiment.addData('Oso.timesOn', Oso.timesOn);
    psychoJS.experiment.addData('Oso.timesOff', Oso.timesOff);
    psychoJS.experiment.addData('Pez.numClicks', Pez.numClicks);
    psychoJS.experiment.addData('Pez.timesOn', Pez.timesOn);
    psychoJS.experiment.addData('Pez.timesOff', Pez.timesOff);
    psychoJS.experiment.addData('Ave.numClicks', Ave.numClicks);
    psychoJS.experiment.addData('Ave.timesOn', Ave.timesOn);
    psychoJS.experiment.addData('Ave.timesOff', Ave.timesOff);
    // the Routine "catch2PAN1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch2SPAN2MaxDurationReached;
var catch2SPAN2MaxDuration;
var catch2SPAN2Components;
function catch2SPAN2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch2SPAN2' ---
    t = 0;
    catch2SPAN2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch2SPAN2MaxDurationReached = false;
    // update component parameters for each repeat
    // reset quinze to account for continued clicks & clear times on/off
    quinze.reset()
    // reset setentaydos to account for continued clicks & clear times on/off
    setentaydos.reset()
    // reset cien to account for continued clicks & clear times on/off
    cien.reset()
    psychoJS.experiment.addData('catch2SPAN2.started', globalClock.getTime());
    catch2SPAN2MaxDuration = null
    // keep track of which components have finished
    catch2SPAN2Components = [];
    catch2SPAN2Components.push(catch2PANmates);
    catch2SPAN2Components.push(quinze);
    catch2SPAN2Components.push(setentaydos);
    catch2SPAN2Components.push(cien);
    
    for (const thisComponent of catch2SPAN2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch2SPAN2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch2SPAN2' ---
    // get current time
    t = catch2SPAN2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch2PANmates* updates
    if (t >= 0.0 && catch2PANmates.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch2PANmates.tStart = t;  // (not accounting for frame time here)
      catch2PANmates.frameNStart = frameN;  // exact frame index
      
      catch2PANmates.setAutoDraw(true);
    }
    
    
    // *quinze* updates
    if (t >= 0 && quinze.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quinze.tStart = t;  // (not accounting for frame time here)
      quinze.frameNStart = frameN;  // exact frame index
      
      quinze.setAutoDraw(true);
    }
    
    if (quinze.status === PsychoJS.Status.STARTED) {
      // check whether quinze has been pressed
      if (quinze.isClicked) {
        if (!quinze.wasClicked) {
          // store time of first click
          quinze.timesOn.push(quinze.clock.getTime());
          // store time clicked until
          quinze.timesOff.push(quinze.clock.getTime());
        } else {
          // update time clicked until;
          quinze.timesOff[quinze.timesOff.length - 1] = quinze.clock.getTime();
        }
        if (!quinze.wasClicked) {
          // end routine when quinze is clicked
          continueRoutine = false;
          
        }
        // if quinze is still clicked next frame, it is not a new click
        quinze.wasClicked = true;
      } else {
        // if quinze is clicked next frame, it is a new click
        quinze.wasClicked = false;
      }
    } else {
      // keep clock at 0 if quinze hasn't started / has finished
      quinze.clock.reset();
      // if quinze is clicked next frame, it is a new click
      quinze.wasClicked = false;
    }
    
    // *setentaydos* updates
    if (t >= 0 && setentaydos.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      setentaydos.tStart = t;  // (not accounting for frame time here)
      setentaydos.frameNStart = frameN;  // exact frame index
      
      setentaydos.setAutoDraw(true);
    }
    
    if (setentaydos.status === PsychoJS.Status.STARTED) {
      // check whether setentaydos has been pressed
      if (setentaydos.isClicked) {
        if (!setentaydos.wasClicked) {
          // store time of first click
          setentaydos.timesOn.push(setentaydos.clock.getTime());
          // store time clicked until
          setentaydos.timesOff.push(setentaydos.clock.getTime());
        } else {
          // update time clicked until;
          setentaydos.timesOff[setentaydos.timesOff.length - 1] = setentaydos.clock.getTime();
        }
        if (!setentaydos.wasClicked) {
          // end routine when setentaydos is clicked
          continueRoutine = false;
          
        }
        // if setentaydos is still clicked next frame, it is not a new click
        setentaydos.wasClicked = true;
      } else {
        // if setentaydos is clicked next frame, it is a new click
        setentaydos.wasClicked = false;
      }
    } else {
      // keep clock at 0 if setentaydos hasn't started / has finished
      setentaydos.clock.reset();
      // if setentaydos is clicked next frame, it is a new click
      setentaydos.wasClicked = false;
    }
    
    // *cien* updates
    if (t >= 0 && cien.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cien.tStart = t;  // (not accounting for frame time here)
      cien.frameNStart = frameN;  // exact frame index
      
      cien.setAutoDraw(true);
    }
    
    if (cien.status === PsychoJS.Status.STARTED) {
      // check whether cien has been pressed
      if (cien.isClicked) {
        if (!cien.wasClicked) {
          // store time of first click
          cien.timesOn.push(cien.clock.getTime());
          // store time clicked until
          cien.timesOff.push(cien.clock.getTime());
        } else {
          // update time clicked until;
          cien.timesOff[cien.timesOff.length - 1] = cien.clock.getTime();
        }
        if (!cien.wasClicked) {
          // end routine when cien is clicked
          continueRoutine = false;
          
        }
        // if cien is still clicked next frame, it is not a new click
        cien.wasClicked = true;
      } else {
        // if cien is clicked next frame, it is a new click
        cien.wasClicked = false;
      }
    } else {
      // keep clock at 0 if cien hasn't started / has finished
      cien.clock.reset();
      // if cien is clicked next frame, it is a new click
      cien.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch2SPAN2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch2SPAN2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch2SPAN2' ---
    for (const thisComponent of catch2SPAN2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch2SPAN2.stopped', globalClock.getTime());
    psychoJS.experiment.addData('quinze.numClicks', quinze.numClicks);
    psychoJS.experiment.addData('quinze.timesOn', quinze.timesOn);
    psychoJS.experiment.addData('quinze.timesOff', quinze.timesOff);
    psychoJS.experiment.addData('setentaydos.numClicks', setentaydos.numClicks);
    psychoJS.experiment.addData('setentaydos.timesOn', setentaydos.timesOn);
    psychoJS.experiment.addData('setentaydos.timesOff', setentaydos.timesOff);
    psychoJS.experiment.addData('cien.numClicks', cien.numClicks);
    psychoJS.experiment.addData('cien.timesOn', cien.timesOn);
    psychoJS.experiment.addData('cien.timesOff', cien.timesOff);
    // the Routine "catch2SPAN2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var break2PANMaxDurationReached;
var break2PANMaxDuration;
var break2PANComponents;
function break2PANRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'break2PAN' ---
    t = 0;
    break2PANClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    break2PANMaxDurationReached = false;
    // update component parameters for each repeat
    // reset next2PANbreak to account for continued clicks & clear times on/off
    next2PANbreak.reset()
    psychoJS.experiment.addData('break2PAN.started', globalClock.getTime());
    break2PANMaxDuration = null
    // keep track of which components have finished
    break2PANComponents = [];
    break2PANComponents.push(SentirESbreak);
    break2PANComponents.push(next2PANbreak);
    
    for (const thisComponent of break2PANComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function break2PANRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'break2PAN' ---
    // get current time
    t = break2PANClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *SentirESbreak* updates
    if (t >= 0.0 && SentirESbreak.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      SentirESbreak.tStart = t;  // (not accounting for frame time here)
      SentirESbreak.frameNStart = frameN;  // exact frame index
      
      SentirESbreak.setAutoDraw(true);
    }
    
    
    // *next2PANbreak* updates
    if (t >= 0 && next2PANbreak.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      next2PANbreak.tStart = t;  // (not accounting for frame time here)
      next2PANbreak.frameNStart = frameN;  // exact frame index
      
      next2PANbreak.setAutoDraw(true);
    }
    
    if (next2PANbreak.status === PsychoJS.Status.STARTED) {
      // check whether next2PANbreak has been pressed
      if (next2PANbreak.isClicked) {
        if (!next2PANbreak.wasClicked) {
          // store time of first click
          next2PANbreak.timesOn.push(next2PANbreak.clock.getTime());
          // store time clicked until
          next2PANbreak.timesOff.push(next2PANbreak.clock.getTime());
        } else {
          // update time clicked until;
          next2PANbreak.timesOff[next2PANbreak.timesOff.length - 1] = next2PANbreak.clock.getTime();
        }
        if (!next2PANbreak.wasClicked) {
          // end routine when next2PANbreak is clicked
          continueRoutine = false;
          
        }
        // if next2PANbreak is still clicked next frame, it is not a new click
        next2PANbreak.wasClicked = true;
      } else {
        // if next2PANbreak is clicked next frame, it is a new click
        next2PANbreak.wasClicked = false;
      }
    } else {
      // keep clock at 0 if next2PANbreak hasn't started / has finished
      next2PANbreak.clock.reset();
      // if next2PANbreak is clicked next frame, it is a new click
      next2PANbreak.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of break2PANComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function break2PANRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'break2PAN' ---
    for (const thisComponent of break2PANComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('break2PAN.stopped', globalClock.getTime());
    psychoJS.experiment.addData('next2PANbreak.numClicks', next2PANbreak.numClicks);
    psychoJS.experiment.addData('next2PANbreak.timesOn', next2PANbreak.timesOn);
    psychoJS.experiment.addData('next2PANbreak.timesOff', next2PANbreak.timesOff);
    // the Routine "break2PAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var catch2PAN3MaxDurationReached;
var catch2PAN3MaxDuration;
var catch2PAN3Components;
function catch2PAN3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'catch2PAN3' ---
    t = 0;
    catch2PAN3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    catch2PAN3MaxDurationReached = false;
    // update component parameters for each repeat
    // reset bocadillo to account for continued clicks & clear times on/off
    bocadillo.reset()
    // reset coliflor to account for continued clicks & clear times on/off
    coliflor.reset()
    // reset manzana to account for continued clicks & clear times on/off
    manzana.reset()
    psychoJS.experiment.addData('catch2PAN3.started', globalClock.getTime());
    catch2PAN3MaxDuration = null
    // keep track of which components have finished
    catch2PAN3Components = [];
    catch2PAN3Components.push(catch2PANfruta);
    catch2PAN3Components.push(bocadillo);
    catch2PAN3Components.push(coliflor);
    catch2PAN3Components.push(manzana);
    
    for (const thisComponent of catch2PAN3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function catch2PAN3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'catch2PAN3' ---
    // get current time
    t = catch2PAN3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *catch2PANfruta* updates
    if (t >= 0.0 && catch2PANfruta.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      catch2PANfruta.tStart = t;  // (not accounting for frame time here)
      catch2PANfruta.frameNStart = frameN;  // exact frame index
      
      catch2PANfruta.setAutoDraw(true);
    }
    
    
    // *bocadillo* updates
    if (t >= 0 && bocadillo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      bocadillo.tStart = t;  // (not accounting for frame time here)
      bocadillo.frameNStart = frameN;  // exact frame index
      
      bocadillo.setAutoDraw(true);
    }
    
    if (bocadillo.status === PsychoJS.Status.STARTED) {
      // check whether bocadillo has been pressed
      if (bocadillo.isClicked) {
        if (!bocadillo.wasClicked) {
          // store time of first click
          bocadillo.timesOn.push(bocadillo.clock.getTime());
          // store time clicked until
          bocadillo.timesOff.push(bocadillo.clock.getTime());
        } else {
          // update time clicked until;
          bocadillo.timesOff[bocadillo.timesOff.length - 1] = bocadillo.clock.getTime();
        }
        if (!bocadillo.wasClicked) {
          // end routine when bocadillo is clicked
          continueRoutine = false;
          
        }
        // if bocadillo is still clicked next frame, it is not a new click
        bocadillo.wasClicked = true;
      } else {
        // if bocadillo is clicked next frame, it is a new click
        bocadillo.wasClicked = false;
      }
    } else {
      // keep clock at 0 if bocadillo hasn't started / has finished
      bocadillo.clock.reset();
      // if bocadillo is clicked next frame, it is a new click
      bocadillo.wasClicked = false;
    }
    
    // *coliflor* updates
    if (t >= 0 && coliflor.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      coliflor.tStart = t;  // (not accounting for frame time here)
      coliflor.frameNStart = frameN;  // exact frame index
      
      coliflor.setAutoDraw(true);
    }
    
    if (coliflor.status === PsychoJS.Status.STARTED) {
      // check whether coliflor has been pressed
      if (coliflor.isClicked) {
        if (!coliflor.wasClicked) {
          // store time of first click
          coliflor.timesOn.push(coliflor.clock.getTime());
          // store time clicked until
          coliflor.timesOff.push(coliflor.clock.getTime());
        } else {
          // update time clicked until;
          coliflor.timesOff[coliflor.timesOff.length - 1] = coliflor.clock.getTime();
        }
        if (!coliflor.wasClicked) {
          // end routine when coliflor is clicked
          continueRoutine = false;
          
        }
        // if coliflor is still clicked next frame, it is not a new click
        coliflor.wasClicked = true;
      } else {
        // if coliflor is clicked next frame, it is a new click
        coliflor.wasClicked = false;
      }
    } else {
      // keep clock at 0 if coliflor hasn't started / has finished
      coliflor.clock.reset();
      // if coliflor is clicked next frame, it is a new click
      coliflor.wasClicked = false;
    }
    
    // *manzana* updates
    if (t >= 0 && manzana.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      manzana.tStart = t;  // (not accounting for frame time here)
      manzana.frameNStart = frameN;  // exact frame index
      
      manzana.setAutoDraw(true);
    }
    
    if (manzana.status === PsychoJS.Status.STARTED) {
      // check whether manzana has been pressed
      if (manzana.isClicked) {
        if (!manzana.wasClicked) {
          // store time of first click
          manzana.timesOn.push(manzana.clock.getTime());
          // store time clicked until
          manzana.timesOff.push(manzana.clock.getTime());
        } else {
          // update time clicked until;
          manzana.timesOff[manzana.timesOff.length - 1] = manzana.clock.getTime();
        }
        if (!manzana.wasClicked) {
          // end routine when manzana is clicked
          continueRoutine = false;
          
        }
        // if manzana is still clicked next frame, it is not a new click
        manzana.wasClicked = true;
      } else {
        // if manzana is clicked next frame, it is a new click
        manzana.wasClicked = false;
      }
    } else {
      // keep clock at 0 if manzana hasn't started / has finished
      manzana.clock.reset();
      // if manzana is clicked next frame, it is a new click
      manzana.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of catch2PAN3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function catch2PAN3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'catch2PAN3' ---
    for (const thisComponent of catch2PAN3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('catch2PAN3.stopped', globalClock.getTime());
    psychoJS.experiment.addData('bocadillo.numClicks', bocadillo.numClicks);
    psychoJS.experiment.addData('bocadillo.timesOn', bocadillo.timesOn);
    psychoJS.experiment.addData('bocadillo.timesOff', bocadillo.timesOff);
    psychoJS.experiment.addData('coliflor.numClicks', coliflor.numClicks);
    psychoJS.experiment.addData('coliflor.timesOn', coliflor.timesOn);
    psychoJS.experiment.addData('coliflor.timesOff', coliflor.timesOff);
    psychoJS.experiment.addData('manzana.numClicks', manzana.numClicks);
    psychoJS.experiment.addData('manzana.timesOn', manzana.timesOn);
    psychoJS.experiment.addData('manzana.timesOff', manzana.timesOff);
    // the Routine "catch2PAN3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var finMaxDurationReached;
var finMaxDuration;
var finComponents;
function finRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'fin' ---
    t = 0;
    finClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    finMaxDurationReached = false;
    // update component parameters for each repeat
    // reset fin2PAN to account for continued clicks & clear times on/off
    fin2PAN.reset()
    psychoJS.experiment.addData('fin.started', globalClock.getTime());
    finMaxDuration = null
    // keep track of which components have finished
    finComponents = [];
    finComponents.push(fin_y);
    finComponents.push(fin2PAN);
    
    for (const thisComponent of finComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function finRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'fin' ---
    // get current time
    t = finClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fin_y* updates
    if (t >= 0.0 && fin_y.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fin_y.tStart = t;  // (not accounting for frame time here)
      fin_y.frameNStart = frameN;  // exact frame index
      
      fin_y.setAutoDraw(true);
    }
    
    
    // *fin2PAN* updates
    if (t >= 0 && fin2PAN.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fin2PAN.tStart = t;  // (not accounting for frame time here)
      fin2PAN.frameNStart = frameN;  // exact frame index
      
      fin2PAN.setAutoDraw(true);
    }
    
    if (fin2PAN.status === PsychoJS.Status.STARTED) {
      // check whether fin2PAN has been pressed
      if (fin2PAN.isClicked) {
        if (!fin2PAN.wasClicked) {
          // store time of first click
          fin2PAN.timesOn.push(fin2PAN.clock.getTime());
          // store time clicked until
          fin2PAN.timesOff.push(fin2PAN.clock.getTime());
        } else {
          // update time clicked until;
          fin2PAN.timesOff[fin2PAN.timesOff.length - 1] = fin2PAN.clock.getTime();
        }
        if (!fin2PAN.wasClicked) {
          // end routine when fin2PAN is clicked
          continueRoutine = false;
          
        }
        // if fin2PAN is still clicked next frame, it is not a new click
        fin2PAN.wasClicked = true;
      } else {
        // if fin2PAN is clicked next frame, it is a new click
        fin2PAN.wasClicked = false;
      }
    } else {
      // keep clock at 0 if fin2PAN hasn't started / has finished
      fin2PAN.clock.reset();
      // if fin2PAN is clicked next frame, it is a new click
      fin2PAN.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of finComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function finRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'fin' ---
    for (const thisComponent of finComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('fin.stopped', globalClock.getTime());
    psychoJS.experiment.addData('fin2PAN.numClicks', fin2PAN.numClicks);
    psychoJS.experiment.addData('fin2PAN.timesOn', fin2PAN.timesOn);
    psychoJS.experiment.addData('fin2PAN.timesOff', fin2PAN.timesOff);
    // the Routine "fin" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
