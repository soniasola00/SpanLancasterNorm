﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.2.1),
    on Mon Sep  9 10:56:56 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.2.1'
expName = 'SentirES_psychopy_fin'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1680, 1050]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/soniasimon/Documents/thesis/SentirES_fin/SentirES_psychopy_fin_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = True
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='event'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='Pyglet',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='Pyglet'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "warning_SPAN" ---
    warning2PAN = visual.TextStim(win=win, name='warning2PAN',
        text='ADERTENCIA\nEste estudio usa palabras cotidianas. De vez en cuando esto significa que aparecen palabras que pueden ser explicitas u ofensivas. Si se siente incomodo en cualquier momento eres libre de terminar la encuesta cerrando la ventana.\n\nPara continuar pulsa "Siguiente"\'',
        font='Arial',
        units='height', pos=(0, 0), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next2PAN = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PAN',
        depth=-1
    )
    next2PAN.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "instructions2PAN" ---
    instructions2PANtext = visual.TextStim(win=win, name='instructions2PANtext',
        text='INSTRUCCIONES\n\nLes vamos a preguntar cómo percibes palabras frecuentes usando seis sentidos corporales. No hay respuestas correctas ni incorrectas. La medida es de 0 (nunca lo percibes usando esa sensación corporal) hasta 5 (interactúas mucho usando esa sensación corporal). Haz click en el número y cuando ya haya rellenado las seis sensaciones pulsa el botón "Siguiente" para empezar la siguiente palabra.Si no reconoce una palabra pulsa “No se esta palabra" y haz click al "Siguente" para continuar.',
        font='Arial',
        units='height', pos=(0, 0), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next2PANinstr = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANinstr',
        depth=-1
    )
    next2PANinstr.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirES_psychopy" ---
    pregunta = visual.TextStim(win=win, name='pregunta',
        text='Comó percibes',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='usando audicion',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='usando sabor',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='usando tacto',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='usando olor',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='usando vision',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='usando sensaciones \nintracorporales',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionsslider = visual.Slider(win=win, name='interoceptionsslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next2PANstim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANstim',
        depth=-14
    )
    next2PANstim.buttonClock = core.Clock()
    nose2PAN = visual.ButtonStim(win, 
        text='no se esta palabra', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='nose2PAN',
        depth=-15
    )
    nose2PAN.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch2PAN1" ---
    catch2PANanimal = visual.TextStim(win=win, name='catch2PANanimal',
        text='Eliga el animal que vuela.',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    Oso = visual.ButtonStim(win, 
        text='Oso', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Oso',
        depth=-1
    )
    Oso.buttonClock = core.Clock()
    Pez = visual.ButtonStim(win, 
        text='Pez', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Pez',
        depth=-2
    )
    Pez.buttonClock = core.Clock()
    Ave = visual.ButtonStim(win, 
        text='Ave', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Ave',
        depth=-3
    )
    Ave.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirES_psychopy" ---
    pregunta = visual.TextStim(win=win, name='pregunta',
        text='Comó percibes',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='usando audicion',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='usando sabor',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='usando tacto',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='usando olor',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='usando vision',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='usando sensaciones \nintracorporales',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionsslider = visual.Slider(win=win, name='interoceptionsslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next2PANstim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANstim',
        depth=-14
    )
    next2PANstim.buttonClock = core.Clock()
    nose2PAN = visual.ButtonStim(win, 
        text='no se esta palabra', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='nose2PAN',
        depth=-15
    )
    nose2PAN.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch2SPAN2" ---
    catch2PANmates = visual.TextStim(win=win, name='catch2PANmates',
        text='Que es 5 x 3?',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    quinze = visual.ButtonStim(win, 
        text='15', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='quinze',
        depth=-1
    )
    quinze.buttonClock = core.Clock()
    setentaydos = visual.ButtonStim(win, 
        text='72', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='setentaydos',
        depth=-2
    )
    setentaydos.buttonClock = core.Clock()
    cien = visual.ButtonStim(win, 
        text='100', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='cien',
        depth=-3
    )
    cien.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "break2PAN" ---
    SentirESbreak = visual.TextStim(win=win, name='SentirESbreak',
        text='Si lo deseas toma un pequeño descanso aqui. Pulse "Siguente" para continuar con el experimento',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    next2PANbreak = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANbreak',
        depth=-1
    )
    next2PANbreak.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirES_psychopy" ---
    pregunta = visual.TextStim(win=win, name='pregunta',
        text='Comó percibes',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='usando audicion',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='usando sabor',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='usando tacto',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='usando olor',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='usando vision',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='usando sensaciones \nintracorporales',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionsslider = visual.Slider(win=win, name='interoceptionsslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next2PANstim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANstim',
        depth=-14
    )
    next2PANstim.buttonClock = core.Clock()
    nose2PAN = visual.ButtonStim(win, 
        text='no se esta palabra', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='nose2PAN',
        depth=-15
    )
    nose2PAN.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "catch2PAN3" ---
    catch2PANfruta = visual.TextStim(win=win, name='catch2PANfruta',
        text='Cual es una fruta?',
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    bocadillo = visual.ButtonStim(win, 
        text='bacadillo', font='Arvo',
        pos=(-0.5, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='bocadillo',
        depth=-1
    )
    bocadillo.buttonClock = core.Clock()
    coliflor = visual.ButtonStim(win, 
        text='coliflor', font='Arvo',
        pos=(0, 0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='coliflor',
        depth=-2
    )
    coliflor.buttonClock = core.Clock()
    manzana = visual.ButtonStim(win, 
        text='manzana', font='Arvo',
        pos=(0.5,0),units='height',
        letterHeight=0.04,
        size=(0.3, 0.3), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='manzana',
        depth=-3
    )
    manzana.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "SentirES_psychopy" ---
    pregunta = visual.TextStim(win=win, name='pregunta',
        text='Comó percibes',
        font='Arial',
        units='height', pos=(-0.4,0.4), draggable=False, height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    stimuli = visual.TextStim(win=win, name='stimuli',
        text='',
        font='Arial',
        units='height', pos=(-0.4,0.3), draggable=False, height=0.045, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-1.0);
    audition = visual.TextStim(win=win, name='audition',
        text='usando audicion',
        font='Arial',
        units='height', pos=(-0.52,0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-2.0);
    taste = visual.TextStim(win=win, name='taste',
        text='usando sabor',
        font='Arial',
        units='height', pos=(-0.52,0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-3.0);
    haptic = visual.TextStim(win=win, name='haptic',
        text='usando tacto',
        font='Arial',
        units='height', pos=(-0.52,0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-4.0);
    olfaction = visual.TextStim(win=win, name='olfaction',
        text='usando olor',
        font='Arial',
        units='height', pos=(-0.52,-0.1), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-5.0);
    vision = visual.TextStim(win=win, name='vision',
        text='usando vision',
        font='Arial',
        units='height', pos=(-0.52,-0.2), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-6.0);
    interoception = visual.TextStim(win=win, name='interoception',
        text='usando sensaciones \nintracorporales',
        font='Arial',
        units='height', pos=(-0.52,-0.3), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='White', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=-7.0);
    auditionslider = visual.Slider(win=win, name='auditionslider',
        startValue=0, size=(0.7, 0.05), pos=(0,0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-8, readOnly=False)
    tasteslider = visual.Slider(win=win, name='tasteslider',
        startValue=None, size=(0.7, 0.05), pos=(0, 0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-9, readOnly=False)
    hapticslider = visual.Slider(win=win, name='hapticslider',
        startValue=None, size=(0.7, 0.05), pos=(0,0), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-10, readOnly=False)
    olfactionslider = visual.Slider(win=win, name='olfactionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.1), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=1.0,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-11, readOnly=False)
    visionslider = visual.Slider(win=win, name='visionslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.2), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-12, readOnly=False)
    interoceptionsslider = visual.Slider(win=win, name='interoceptionsslider',
        startValue=None, size=(0.7, 0.05), pos=(0,-0.3), units='height',
        labels=["nada","totalmente"], ticks=(0,1, 2, 3, 4, 5), granularity=1.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor='White', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-13, readOnly=False)
    next2PANstim = visual.ButtonStim(win, 
        text='Siguente', font='Arial',
        pos=(0.55, -0.4),units='height',
        letterHeight=0.03,
        size=(0.2, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='next2PANstim',
        depth=-14
    )
    next2PANstim.buttonClock = core.Clock()
    nose2PAN = visual.ButtonStim(win, 
        text='no se esta palabra', font='Arial',
        pos=(0.55, 0.3),units='height',
        letterHeight=0.03,
        size=(0.4, 0.2), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='nose2PAN',
        depth=-15
    )
    nose2PAN.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "fin" ---
    fin_y = visual.TextStim(win=win, name='fin_y',
        text="Gracais por su particpacion!\nPulse 'fin' para finalizar este estudio",
        font='Arial',
        units='height', pos=(0, 0.3), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    fin2PAN = visual.ButtonStim(win, 
        text='fin', font='Arial',
        pos=(0, 0),units='height',
        letterHeight=0.05,
        size=(0.5, 0.5), 
        ori=0.0
        ,borderWidth=0.0,
        fillColor=[-1.0000, 0.0902, 0.0902], borderColor=None,
        color='white', colorSpace='rgb',
        opacity=1.0,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='fin2PAN',
        depth=-1
    )
    fin2PAN.buttonClock = core.Clock()
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "warning_SPAN" ---
    # create an object to store info about Routine warning_SPAN
    warning_SPAN = data.Routine(
        name='warning_SPAN',
        components=[warning2PAN, next2PAN],
    )
    warning_SPAN.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next2PAN to account for continued clicks & clear times on/off
    next2PAN.reset()
    # store start times for warning_SPAN
    warning_SPAN.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    warning_SPAN.tStart = globalClock.getTime(format='float')
    warning_SPAN.status = STARTED
    thisExp.addData('warning_SPAN.started', warning_SPAN.tStart)
    warning_SPAN.maxDuration = None
    # keep track of which components have finished
    warning_SPANComponents = warning_SPAN.components
    for thisComponent in warning_SPAN.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "warning_SPAN" ---
    warning_SPAN.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *warning2PAN* updates
        
        # if warning2PAN is starting this frame...
        if warning2PAN.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            warning2PAN.frameNStart = frameN  # exact frame index
            warning2PAN.tStart = t  # local t and not account for scr refresh
            warning2PAN.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(warning2PAN, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'warning2PAN.started')
            # update status
            warning2PAN.status = STARTED
            warning2PAN.setAutoDraw(True)
        
        # if warning2PAN is active this frame...
        if warning2PAN.status == STARTED:
            # update params
            pass
        # *next2PAN* updates
        
        # if next2PAN is starting this frame...
        if next2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next2PAN.frameNStart = frameN  # exact frame index
            next2PAN.tStart = t  # local t and not account for scr refresh
            next2PAN.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next2PAN, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next2PAN.started')
            # update status
            next2PAN.status = STARTED
            win.callOnFlip(next2PAN.buttonClock.reset)
            next2PAN.setAutoDraw(True)
        
        # if next2PAN is active this frame...
        if next2PAN.status == STARTED:
            # update params
            pass
            # check whether next2PAN has been pressed
            if next2PAN.isClicked:
                if not next2PAN.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next2PAN.timesOn.append(next2PAN.buttonClock.getTime())
                    next2PAN.timesOff.append(next2PAN.buttonClock.getTime())
                elif len(next2PAN.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next2PAN.timesOff[-1] = next2PAN.buttonClock.getTime()
                if not next2PAN.wasClicked:
                    # end routine when next2PAN is clicked
                    continueRoutine = False
                if not next2PAN.wasClicked:
                    # run callback code when next2PAN is clicked
                    pass
        # take note of whether next2PAN was clicked, so that next frame we know if clicks are new
        next2PAN.wasClicked = next2PAN.isClicked and next2PAN.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            warning_SPAN.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warning_SPAN.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "warning_SPAN" ---
    for thisComponent in warning_SPAN.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for warning_SPAN
    warning_SPAN.tStop = globalClock.getTime(format='float')
    warning_SPAN.tStopRefresh = tThisFlipGlobal
    thisExp.addData('warning_SPAN.stopped', warning_SPAN.tStop)
    thisExp.addData('next2PAN.numClicks', next2PAN.numClicks)
    if next2PAN.numClicks:
       thisExp.addData('next2PAN.timesOn', next2PAN.timesOn)
       thisExp.addData('next2PAN.timesOff', next2PAN.timesOff)
    else:
       thisExp.addData('next2PAN.timesOn', "")
       thisExp.addData('next2PAN.timesOff', "")
    thisExp.nextEntry()
    # the Routine "warning_SPAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "instructions2PAN" ---
    # create an object to store info about Routine instructions2PAN
    instructions2PAN = data.Routine(
        name='instructions2PAN',
        components=[instructions2PANtext, next2PANinstr],
    )
    instructions2PAN.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next2PANinstr to account for continued clicks & clear times on/off
    next2PANinstr.reset()
    # store start times for instructions2PAN
    instructions2PAN.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    instructions2PAN.tStart = globalClock.getTime(format='float')
    instructions2PAN.status = STARTED
    thisExp.addData('instructions2PAN.started', instructions2PAN.tStart)
    instructions2PAN.maxDuration = None
    # keep track of which components have finished
    instructions2PANComponents = instructions2PAN.components
    for thisComponent in instructions2PAN.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instructions2PAN" ---
    instructions2PAN.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instructions2PANtext* updates
        
        # if instructions2PANtext is starting this frame...
        if instructions2PANtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructions2PANtext.frameNStart = frameN  # exact frame index
            instructions2PANtext.tStart = t  # local t and not account for scr refresh
            instructions2PANtext.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructions2PANtext, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructions2PANtext.started')
            # update status
            instructions2PANtext.status = STARTED
            instructions2PANtext.setAutoDraw(True)
        
        # if instructions2PANtext is active this frame...
        if instructions2PANtext.status == STARTED:
            # update params
            pass
        # *next2PANinstr* updates
        
        # if next2PANinstr is starting this frame...
        if next2PANinstr.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next2PANinstr.frameNStart = frameN  # exact frame index
            next2PANinstr.tStart = t  # local t and not account for scr refresh
            next2PANinstr.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next2PANinstr, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next2PANinstr.started')
            # update status
            next2PANinstr.status = STARTED
            win.callOnFlip(next2PANinstr.buttonClock.reset)
            next2PANinstr.setAutoDraw(True)
        
        # if next2PANinstr is active this frame...
        if next2PANinstr.status == STARTED:
            # update params
            pass
            # check whether next2PANinstr has been pressed
            if next2PANinstr.isClicked:
                if not next2PANinstr.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next2PANinstr.timesOn.append(next2PANinstr.buttonClock.getTime())
                    next2PANinstr.timesOff.append(next2PANinstr.buttonClock.getTime())
                elif len(next2PANinstr.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next2PANinstr.timesOff[-1] = next2PANinstr.buttonClock.getTime()
                if not next2PANinstr.wasClicked:
                    # end routine when next2PANinstr is clicked
                    continueRoutine = False
                if not next2PANinstr.wasClicked:
                    # run callback code when next2PANinstr is clicked
                    pass
        # take note of whether next2PANinstr was clicked, so that next frame we know if clicks are new
        next2PANinstr.wasClicked = next2PANinstr.isClicked and next2PANinstr.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            instructions2PAN.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructions2PAN.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instructions2PAN" ---
    for thisComponent in instructions2PAN.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for instructions2PAN
    instructions2PAN.tStop = globalClock.getTime(format='float')
    instructions2PAN.tStopRefresh = tThisFlipGlobal
    thisExp.addData('instructions2PAN.stopped', instructions2PAN.tStop)
    thisExp.addData('next2PANinstr.numClicks', next2PANinstr.numClicks)
    if next2PANinstr.numClicks:
       thisExp.addData('next2PANinstr.timesOn', next2PANinstr.timesOn)
       thisExp.addData('next2PANinstr.timesOff', next2PANinstr.timesOff)
    else:
       thisExp.addData('next2PANinstr.timesOn', "")
       thisExp.addData('next2PANinstr.timesOff', "")
    thisExp.nextEntry()
    # the Routine "instructions2PAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirES2PAN19 = data.TrialHandler2(
        name='SentirES2PAN19',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimSPAN/Stimuli2PAN19.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirES2PAN19)  # add the loop to the experiment
    thisSentirES2PAN19 = SentirES2PAN19.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirES2PAN19.rgb)
    if thisSentirES2PAN19 != None:
        for paramName in thisSentirES2PAN19:
            globals()[paramName] = thisSentirES2PAN19[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirES2PAN19 in SentirES2PAN19:
        currentLoop = SentirES2PAN19
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirES2PAN19.rgb)
        if thisSentirES2PAN19 != None:
            for paramName in thisSentirES2PAN19:
                globals()[paramName] = thisSentirES2PAN19[paramName]
        
        # --- Prepare to start Routine "SentirES_psychopy" ---
        # create an object to store info about Routine SentirES_psychopy
        SentirES_psychopy = data.Routine(
            name='SentirES_psychopy',
            components=[pregunta, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionsslider, next2PANstim, nose2PAN],
        )
        SentirES_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionsslider.reset()
        # reset next2PANstim to account for continued clicks & clear times on/off
        next2PANstim.reset()
        # reset nose2PAN to account for continued clicks & clear times on/off
        nose2PAN.reset()
        # store start times for SentirES_psychopy
        SentirES_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirES_psychopy.tStart = globalClock.getTime(format='float')
        SentirES_psychopy.status = STARTED
        thisExp.addData('SentirES_psychopy.started', SentirES_psychopy.tStart)
        SentirES_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirES_psychopyComponents = SentirES_psychopy.components
        for thisComponent in SentirES_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirES_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirES2PAN19, data.TrialHandler2) and thisSentirES2PAN19.thisN != SentirES2PAN19.thisTrial.thisN:
            continueRoutine = False
        SentirES_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pregunta* updates
            
            # if pregunta is starting this frame...
            if pregunta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pregunta.frameNStart = frameN  # exact frame index
                pregunta.tStart = t  # local t and not account for scr refresh
                pregunta.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pregunta, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pregunta.started')
                # update status
                pregunta.status = STARTED
                pregunta.setAutoDraw(True)
            
            # if pregunta is active this frame...
            if pregunta.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionsslider* updates
            
            # if interoceptionsslider is starting this frame...
            if interoceptionsslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionsslider.frameNStart = frameN  # exact frame index
                interoceptionsslider.tStart = t  # local t and not account for scr refresh
                interoceptionsslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionsslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionsslider.started')
                # update status
                interoceptionsslider.status = STARTED
                interoceptionsslider.setAutoDraw(True)
            
            # if interoceptionsslider is active this frame...
            if interoceptionsslider.status == STARTED:
                # update params
                pass
            # *next2PANstim* updates
            
            # if next2PANstim is starting this frame...
            if next2PANstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next2PANstim.frameNStart = frameN  # exact frame index
                next2PANstim.tStart = t  # local t and not account for scr refresh
                next2PANstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next2PANstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next2PANstim.started')
                # update status
                next2PANstim.status = STARTED
                win.callOnFlip(next2PANstim.buttonClock.reset)
                next2PANstim.setAutoDraw(True)
            
            # if next2PANstim is active this frame...
            if next2PANstim.status == STARTED:
                # update params
                pass
                # check whether next2PANstim has been pressed
                if next2PANstim.isClicked:
                    if not next2PANstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next2PANstim.timesOn.append(next2PANstim.buttonClock.getTime())
                        next2PANstim.timesOff.append(next2PANstim.buttonClock.getTime())
                    elif len(next2PANstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next2PANstim.timesOff[-1] = next2PANstim.buttonClock.getTime()
                    if not next2PANstim.wasClicked:
                        # end routine when next2PANstim is clicked
                        continueRoutine = False
                    if not next2PANstim.wasClicked:
                        # run callback code when next2PANstim is clicked
                        pass
            # take note of whether next2PANstim was clicked, so that next frame we know if clicks are new
            next2PANstim.wasClicked = next2PANstim.isClicked and next2PANstim.status == STARTED
            # *nose2PAN* updates
            
            # if nose2PAN is starting this frame...
            if nose2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                nose2PAN.frameNStart = frameN  # exact frame index
                nose2PAN.tStart = t  # local t and not account for scr refresh
                nose2PAN.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(nose2PAN, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'nose2PAN.started')
                # update status
                nose2PAN.status = STARTED
                win.callOnFlip(nose2PAN.buttonClock.reset)
                nose2PAN.setAutoDraw(True)
            
            # if nose2PAN is active this frame...
            if nose2PAN.status == STARTED:
                # update params
                pass
                # check whether nose2PAN has been pressed
                if nose2PAN.isClicked:
                    if not nose2PAN.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        nose2PAN.timesOn.append(nose2PAN.buttonClock.getTime())
                        nose2PAN.timesOff.append(nose2PAN.buttonClock.getTime())
                    elif len(nose2PAN.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        nose2PAN.timesOff[-1] = nose2PAN.buttonClock.getTime()
                    if not nose2PAN.wasClicked:
                        # end routine when nose2PAN is clicked
                        continueRoutine = False
                    if not nose2PAN.wasClicked:
                        # run callback code when nose2PAN is clicked
                        pass
            # take note of whether nose2PAN was clicked, so that next frame we know if clicks are new
            nose2PAN.wasClicked = nose2PAN.isClicked and nose2PAN.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirES_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirES_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirES_psychopy" ---
        for thisComponent in SentirES_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirES_psychopy
        SentirES_psychopy.tStop = globalClock.getTime(format='float')
        SentirES_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirES_psychopy.stopped', SentirES_psychopy.tStop)
        SentirES2PAN19.addData('auditionslider.response', auditionslider.getRating())
        SentirES2PAN19.addData('auditionslider.rt', auditionslider.getRT())
        SentirES2PAN19.addData('tasteslider.response', tasteslider.getRating())
        SentirES2PAN19.addData('tasteslider.rt', tasteslider.getRT())
        SentirES2PAN19.addData('hapticslider.response', hapticslider.getRating())
        SentirES2PAN19.addData('hapticslider.rt', hapticslider.getRT())
        SentirES2PAN19.addData('olfactionslider.response', olfactionslider.getRating())
        SentirES2PAN19.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirES2PAN19.addData('visionslider.response', visionslider.getRating())
        SentirES2PAN19.addData('visionslider.rt', visionslider.getRT())
        SentirES2PAN19.addData('interoceptionsslider.response', interoceptionsslider.getRating())
        SentirES2PAN19.addData('interoceptionsslider.rt', interoceptionsslider.getRT())
        SentirES2PAN19.addData('next2PANstim.numClicks', next2PANstim.numClicks)
        if next2PANstim.numClicks:
           SentirES2PAN19.addData('next2PANstim.timesOn', next2PANstim.timesOn)
           SentirES2PAN19.addData('next2PANstim.timesOff', next2PANstim.timesOff)
        else:
           SentirES2PAN19.addData('next2PANstim.timesOn', "")
           SentirES2PAN19.addData('next2PANstim.timesOff', "")
        SentirES2PAN19.addData('nose2PAN.numClicks', nose2PAN.numClicks)
        if nose2PAN.numClicks:
           SentirES2PAN19.addData('nose2PAN.timesOn', nose2PAN.timesOn)
           SentirES2PAN19.addData('nose2PAN.timesOff', nose2PAN.timesOff)
        else:
           SentirES2PAN19.addData('nose2PAN.timesOn', "")
           SentirES2PAN19.addData('nose2PAN.timesOff', "")
        # the Routine "SentirES_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirES2PAN19'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "catch2PAN1" ---
    # create an object to store info about Routine catch2PAN1
    catch2PAN1 = data.Routine(
        name='catch2PAN1',
        components=[catch2PANanimal, Oso, Pez, Ave],
    )
    catch2PAN1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset Oso to account for continued clicks & clear times on/off
    Oso.reset()
    # reset Pez to account for continued clicks & clear times on/off
    Pez.reset()
    # reset Ave to account for continued clicks & clear times on/off
    Ave.reset()
    # store start times for catch2PAN1
    catch2PAN1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch2PAN1.tStart = globalClock.getTime(format='float')
    catch2PAN1.status = STARTED
    thisExp.addData('catch2PAN1.started', catch2PAN1.tStart)
    catch2PAN1.maxDuration = None
    # keep track of which components have finished
    catch2PAN1Components = catch2PAN1.components
    for thisComponent in catch2PAN1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch2PAN1" ---
    catch2PAN1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch2PANanimal* updates
        
        # if catch2PANanimal is starting this frame...
        if catch2PANanimal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch2PANanimal.frameNStart = frameN  # exact frame index
            catch2PANanimal.tStart = t  # local t and not account for scr refresh
            catch2PANanimal.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch2PANanimal, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch2PANanimal.started')
            # update status
            catch2PANanimal.status = STARTED
            catch2PANanimal.setAutoDraw(True)
        
        # if catch2PANanimal is active this frame...
        if catch2PANanimal.status == STARTED:
            # update params
            pass
        # *Oso* updates
        
        # if Oso is starting this frame...
        if Oso.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Oso.frameNStart = frameN  # exact frame index
            Oso.tStart = t  # local t and not account for scr refresh
            Oso.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Oso, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Oso.started')
            # update status
            Oso.status = STARTED
            win.callOnFlip(Oso.buttonClock.reset)
            Oso.setAutoDraw(True)
        
        # if Oso is active this frame...
        if Oso.status == STARTED:
            # update params
            pass
            # check whether Oso has been pressed
            if Oso.isClicked:
                if not Oso.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Oso.timesOn.append(Oso.buttonClock.getTime())
                    Oso.timesOff.append(Oso.buttonClock.getTime())
                elif len(Oso.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Oso.timesOff[-1] = Oso.buttonClock.getTime()
                if not Oso.wasClicked:
                    # end routine when Oso is clicked
                    continueRoutine = False
                if not Oso.wasClicked:
                    # run callback code when Oso is clicked
                    pass
        # take note of whether Oso was clicked, so that next frame we know if clicks are new
        Oso.wasClicked = Oso.isClicked and Oso.status == STARTED
        # *Pez* updates
        
        # if Pez is starting this frame...
        if Pez.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Pez.frameNStart = frameN  # exact frame index
            Pez.tStart = t  # local t and not account for scr refresh
            Pez.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Pez, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Pez.started')
            # update status
            Pez.status = STARTED
            win.callOnFlip(Pez.buttonClock.reset)
            Pez.setAutoDraw(True)
        
        # if Pez is active this frame...
        if Pez.status == STARTED:
            # update params
            pass
            # check whether Pez has been pressed
            if Pez.isClicked:
                if not Pez.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Pez.timesOn.append(Pez.buttonClock.getTime())
                    Pez.timesOff.append(Pez.buttonClock.getTime())
                elif len(Pez.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Pez.timesOff[-1] = Pez.buttonClock.getTime()
                if not Pez.wasClicked:
                    # end routine when Pez is clicked
                    continueRoutine = False
                if not Pez.wasClicked:
                    # run callback code when Pez is clicked
                    pass
        # take note of whether Pez was clicked, so that next frame we know if clicks are new
        Pez.wasClicked = Pez.isClicked and Pez.status == STARTED
        # *Ave* updates
        
        # if Ave is starting this frame...
        if Ave.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ave.frameNStart = frameN  # exact frame index
            Ave.tStart = t  # local t and not account for scr refresh
            Ave.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ave, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Ave.started')
            # update status
            Ave.status = STARTED
            win.callOnFlip(Ave.buttonClock.reset)
            Ave.setAutoDraw(True)
        
        # if Ave is active this frame...
        if Ave.status == STARTED:
            # update params
            pass
            # check whether Ave has been pressed
            if Ave.isClicked:
                if not Ave.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Ave.timesOn.append(Ave.buttonClock.getTime())
                    Ave.timesOff.append(Ave.buttonClock.getTime())
                elif len(Ave.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Ave.timesOff[-1] = Ave.buttonClock.getTime()
                if not Ave.wasClicked:
                    # end routine when Ave is clicked
                    continueRoutine = False
                if not Ave.wasClicked:
                    # run callback code when Ave is clicked
                    pass
        # take note of whether Ave was clicked, so that next frame we know if clicks are new
        Ave.wasClicked = Ave.isClicked and Ave.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch2PAN1.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch2PAN1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch2PAN1" ---
    for thisComponent in catch2PAN1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch2PAN1
    catch2PAN1.tStop = globalClock.getTime(format='float')
    catch2PAN1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch2PAN1.stopped', catch2PAN1.tStop)
    thisExp.addData('Oso.numClicks', Oso.numClicks)
    if Oso.numClicks:
       thisExp.addData('Oso.timesOn', Oso.timesOn)
       thisExp.addData('Oso.timesOff', Oso.timesOff)
    else:
       thisExp.addData('Oso.timesOn', "")
       thisExp.addData('Oso.timesOff', "")
    thisExp.addData('Pez.numClicks', Pez.numClicks)
    if Pez.numClicks:
       thisExp.addData('Pez.timesOn', Pez.timesOn)
       thisExp.addData('Pez.timesOff', Pez.timesOff)
    else:
       thisExp.addData('Pez.timesOn', "")
       thisExp.addData('Pez.timesOff', "")
    thisExp.addData('Ave.numClicks', Ave.numClicks)
    if Ave.numClicks:
       thisExp.addData('Ave.timesOn', Ave.timesOn)
       thisExp.addData('Ave.timesOff', Ave.timesOff)
    else:
       thisExp.addData('Ave.timesOn', "")
       thisExp.addData('Ave.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch2PAN1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirES2SPAN45 = data.TrialHandler2(
        name='SentirES2SPAN45',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimSPAN/Stimuli2PAN45.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirES2SPAN45)  # add the loop to the experiment
    thisSentirES2SPAN45 = SentirES2SPAN45.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN45.rgb)
    if thisSentirES2SPAN45 != None:
        for paramName in thisSentirES2SPAN45:
            globals()[paramName] = thisSentirES2SPAN45[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirES2SPAN45 in SentirES2SPAN45:
        currentLoop = SentirES2SPAN45
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN45.rgb)
        if thisSentirES2SPAN45 != None:
            for paramName in thisSentirES2SPAN45:
                globals()[paramName] = thisSentirES2SPAN45[paramName]
        
        # --- Prepare to start Routine "SentirES_psychopy" ---
        # create an object to store info about Routine SentirES_psychopy
        SentirES_psychopy = data.Routine(
            name='SentirES_psychopy',
            components=[pregunta, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionsslider, next2PANstim, nose2PAN],
        )
        SentirES_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionsslider.reset()
        # reset next2PANstim to account for continued clicks & clear times on/off
        next2PANstim.reset()
        # reset nose2PAN to account for continued clicks & clear times on/off
        nose2PAN.reset()
        # store start times for SentirES_psychopy
        SentirES_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirES_psychopy.tStart = globalClock.getTime(format='float')
        SentirES_psychopy.status = STARTED
        thisExp.addData('SentirES_psychopy.started', SentirES_psychopy.tStart)
        SentirES_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirES_psychopyComponents = SentirES_psychopy.components
        for thisComponent in SentirES_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirES_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirES2SPAN45, data.TrialHandler2) and thisSentirES2SPAN45.thisN != SentirES2SPAN45.thisTrial.thisN:
            continueRoutine = False
        SentirES_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pregunta* updates
            
            # if pregunta is starting this frame...
            if pregunta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pregunta.frameNStart = frameN  # exact frame index
                pregunta.tStart = t  # local t and not account for scr refresh
                pregunta.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pregunta, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pregunta.started')
                # update status
                pregunta.status = STARTED
                pregunta.setAutoDraw(True)
            
            # if pregunta is active this frame...
            if pregunta.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionsslider* updates
            
            # if interoceptionsslider is starting this frame...
            if interoceptionsslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionsslider.frameNStart = frameN  # exact frame index
                interoceptionsslider.tStart = t  # local t and not account for scr refresh
                interoceptionsslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionsslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionsslider.started')
                # update status
                interoceptionsslider.status = STARTED
                interoceptionsslider.setAutoDraw(True)
            
            # if interoceptionsslider is active this frame...
            if interoceptionsslider.status == STARTED:
                # update params
                pass
            # *next2PANstim* updates
            
            # if next2PANstim is starting this frame...
            if next2PANstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next2PANstim.frameNStart = frameN  # exact frame index
                next2PANstim.tStart = t  # local t and not account for scr refresh
                next2PANstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next2PANstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next2PANstim.started')
                # update status
                next2PANstim.status = STARTED
                win.callOnFlip(next2PANstim.buttonClock.reset)
                next2PANstim.setAutoDraw(True)
            
            # if next2PANstim is active this frame...
            if next2PANstim.status == STARTED:
                # update params
                pass
                # check whether next2PANstim has been pressed
                if next2PANstim.isClicked:
                    if not next2PANstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next2PANstim.timesOn.append(next2PANstim.buttonClock.getTime())
                        next2PANstim.timesOff.append(next2PANstim.buttonClock.getTime())
                    elif len(next2PANstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next2PANstim.timesOff[-1] = next2PANstim.buttonClock.getTime()
                    if not next2PANstim.wasClicked:
                        # end routine when next2PANstim is clicked
                        continueRoutine = False
                    if not next2PANstim.wasClicked:
                        # run callback code when next2PANstim is clicked
                        pass
            # take note of whether next2PANstim was clicked, so that next frame we know if clicks are new
            next2PANstim.wasClicked = next2PANstim.isClicked and next2PANstim.status == STARTED
            # *nose2PAN* updates
            
            # if nose2PAN is starting this frame...
            if nose2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                nose2PAN.frameNStart = frameN  # exact frame index
                nose2PAN.tStart = t  # local t and not account for scr refresh
                nose2PAN.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(nose2PAN, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'nose2PAN.started')
                # update status
                nose2PAN.status = STARTED
                win.callOnFlip(nose2PAN.buttonClock.reset)
                nose2PAN.setAutoDraw(True)
            
            # if nose2PAN is active this frame...
            if nose2PAN.status == STARTED:
                # update params
                pass
                # check whether nose2PAN has been pressed
                if nose2PAN.isClicked:
                    if not nose2PAN.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        nose2PAN.timesOn.append(nose2PAN.buttonClock.getTime())
                        nose2PAN.timesOff.append(nose2PAN.buttonClock.getTime())
                    elif len(nose2PAN.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        nose2PAN.timesOff[-1] = nose2PAN.buttonClock.getTime()
                    if not nose2PAN.wasClicked:
                        # end routine when nose2PAN is clicked
                        continueRoutine = False
                    if not nose2PAN.wasClicked:
                        # run callback code when nose2PAN is clicked
                        pass
            # take note of whether nose2PAN was clicked, so that next frame we know if clicks are new
            nose2PAN.wasClicked = nose2PAN.isClicked and nose2PAN.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirES_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirES_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirES_psychopy" ---
        for thisComponent in SentirES_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirES_psychopy
        SentirES_psychopy.tStop = globalClock.getTime(format='float')
        SentirES_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirES_psychopy.stopped', SentirES_psychopy.tStop)
        SentirES2SPAN45.addData('auditionslider.response', auditionslider.getRating())
        SentirES2SPAN45.addData('auditionslider.rt', auditionslider.getRT())
        SentirES2SPAN45.addData('tasteslider.response', tasteslider.getRating())
        SentirES2SPAN45.addData('tasteslider.rt', tasteslider.getRT())
        SentirES2SPAN45.addData('hapticslider.response', hapticslider.getRating())
        SentirES2SPAN45.addData('hapticslider.rt', hapticslider.getRT())
        SentirES2SPAN45.addData('olfactionslider.response', olfactionslider.getRating())
        SentirES2SPAN45.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirES2SPAN45.addData('visionslider.response', visionslider.getRating())
        SentirES2SPAN45.addData('visionslider.rt', visionslider.getRT())
        SentirES2SPAN45.addData('interoceptionsslider.response', interoceptionsslider.getRating())
        SentirES2SPAN45.addData('interoceptionsslider.rt', interoceptionsslider.getRT())
        SentirES2SPAN45.addData('next2PANstim.numClicks', next2PANstim.numClicks)
        if next2PANstim.numClicks:
           SentirES2SPAN45.addData('next2PANstim.timesOn', next2PANstim.timesOn)
           SentirES2SPAN45.addData('next2PANstim.timesOff', next2PANstim.timesOff)
        else:
           SentirES2SPAN45.addData('next2PANstim.timesOn', "")
           SentirES2SPAN45.addData('next2PANstim.timesOff', "")
        SentirES2SPAN45.addData('nose2PAN.numClicks', nose2PAN.numClicks)
        if nose2PAN.numClicks:
           SentirES2SPAN45.addData('nose2PAN.timesOn', nose2PAN.timesOn)
           SentirES2SPAN45.addData('nose2PAN.timesOff', nose2PAN.timesOff)
        else:
           SentirES2SPAN45.addData('nose2PAN.timesOn', "")
           SentirES2SPAN45.addData('nose2PAN.timesOff', "")
        # the Routine "SentirES_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirES2SPAN45'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "catch2SPAN2" ---
    # create an object to store info about Routine catch2SPAN2
    catch2SPAN2 = data.Routine(
        name='catch2SPAN2',
        components=[catch2PANmates, quinze, setentaydos, cien],
    )
    catch2SPAN2.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset quinze to account for continued clicks & clear times on/off
    quinze.reset()
    # reset setentaydos to account for continued clicks & clear times on/off
    setentaydos.reset()
    # reset cien to account for continued clicks & clear times on/off
    cien.reset()
    # store start times for catch2SPAN2
    catch2SPAN2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch2SPAN2.tStart = globalClock.getTime(format='float')
    catch2SPAN2.status = STARTED
    thisExp.addData('catch2SPAN2.started', catch2SPAN2.tStart)
    catch2SPAN2.maxDuration = None
    # keep track of which components have finished
    catch2SPAN2Components = catch2SPAN2.components
    for thisComponent in catch2SPAN2.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch2SPAN2" ---
    catch2SPAN2.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch2PANmates* updates
        
        # if catch2PANmates is starting this frame...
        if catch2PANmates.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch2PANmates.frameNStart = frameN  # exact frame index
            catch2PANmates.tStart = t  # local t and not account for scr refresh
            catch2PANmates.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch2PANmates, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch2PANmates.started')
            # update status
            catch2PANmates.status = STARTED
            catch2PANmates.setAutoDraw(True)
        
        # if catch2PANmates is active this frame...
        if catch2PANmates.status == STARTED:
            # update params
            pass
        # *quinze* updates
        
        # if quinze is starting this frame...
        if quinze.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            quinze.frameNStart = frameN  # exact frame index
            quinze.tStart = t  # local t and not account for scr refresh
            quinze.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(quinze, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'quinze.started')
            # update status
            quinze.status = STARTED
            win.callOnFlip(quinze.buttonClock.reset)
            quinze.setAutoDraw(True)
        
        # if quinze is active this frame...
        if quinze.status == STARTED:
            # update params
            pass
            # check whether quinze has been pressed
            if quinze.isClicked:
                if not quinze.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    quinze.timesOn.append(quinze.buttonClock.getTime())
                    quinze.timesOff.append(quinze.buttonClock.getTime())
                elif len(quinze.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    quinze.timesOff[-1] = quinze.buttonClock.getTime()
                if not quinze.wasClicked:
                    # end routine when quinze is clicked
                    continueRoutine = False
                if not quinze.wasClicked:
                    # run callback code when quinze is clicked
                    pass
        # take note of whether quinze was clicked, so that next frame we know if clicks are new
        quinze.wasClicked = quinze.isClicked and quinze.status == STARTED
        # *setentaydos* updates
        
        # if setentaydos is starting this frame...
        if setentaydos.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            setentaydos.frameNStart = frameN  # exact frame index
            setentaydos.tStart = t  # local t and not account for scr refresh
            setentaydos.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(setentaydos, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'setentaydos.started')
            # update status
            setentaydos.status = STARTED
            win.callOnFlip(setentaydos.buttonClock.reset)
            setentaydos.setAutoDraw(True)
        
        # if setentaydos is active this frame...
        if setentaydos.status == STARTED:
            # update params
            pass
            # check whether setentaydos has been pressed
            if setentaydos.isClicked:
                if not setentaydos.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    setentaydos.timesOn.append(setentaydos.buttonClock.getTime())
                    setentaydos.timesOff.append(setentaydos.buttonClock.getTime())
                elif len(setentaydos.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    setentaydos.timesOff[-1] = setentaydos.buttonClock.getTime()
                if not setentaydos.wasClicked:
                    # end routine when setentaydos is clicked
                    continueRoutine = False
                if not setentaydos.wasClicked:
                    # run callback code when setentaydos is clicked
                    pass
        # take note of whether setentaydos was clicked, so that next frame we know if clicks are new
        setentaydos.wasClicked = setentaydos.isClicked and setentaydos.status == STARTED
        # *cien* updates
        
        # if cien is starting this frame...
        if cien.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            cien.frameNStart = frameN  # exact frame index
            cien.tStart = t  # local t and not account for scr refresh
            cien.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cien, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'cien.started')
            # update status
            cien.status = STARTED
            win.callOnFlip(cien.buttonClock.reset)
            cien.setAutoDraw(True)
        
        # if cien is active this frame...
        if cien.status == STARTED:
            # update params
            pass
            # check whether cien has been pressed
            if cien.isClicked:
                if not cien.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    cien.timesOn.append(cien.buttonClock.getTime())
                    cien.timesOff.append(cien.buttonClock.getTime())
                elif len(cien.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    cien.timesOff[-1] = cien.buttonClock.getTime()
                if not cien.wasClicked:
                    # end routine when cien is clicked
                    continueRoutine = False
                if not cien.wasClicked:
                    # run callback code when cien is clicked
                    pass
        # take note of whether cien was clicked, so that next frame we know if clicks are new
        cien.wasClicked = cien.isClicked and cien.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch2SPAN2.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch2SPAN2.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch2SPAN2" ---
    for thisComponent in catch2SPAN2.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch2SPAN2
    catch2SPAN2.tStop = globalClock.getTime(format='float')
    catch2SPAN2.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch2SPAN2.stopped', catch2SPAN2.tStop)
    thisExp.addData('quinze.numClicks', quinze.numClicks)
    if quinze.numClicks:
       thisExp.addData('quinze.timesOn', quinze.timesOn)
       thisExp.addData('quinze.timesOff', quinze.timesOff)
    else:
       thisExp.addData('quinze.timesOn', "")
       thisExp.addData('quinze.timesOff', "")
    thisExp.addData('setentaydos.numClicks', setentaydos.numClicks)
    if setentaydos.numClicks:
       thisExp.addData('setentaydos.timesOn', setentaydos.timesOn)
       thisExp.addData('setentaydos.timesOff', setentaydos.timesOff)
    else:
       thisExp.addData('setentaydos.timesOn', "")
       thisExp.addData('setentaydos.timesOff', "")
    thisExp.addData('cien.numClicks', cien.numClicks)
    if cien.numClicks:
       thisExp.addData('cien.timesOn', cien.timesOn)
       thisExp.addData('cien.timesOff', cien.timesOff)
    else:
       thisExp.addData('cien.timesOn', "")
       thisExp.addData('cien.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch2SPAN2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "break2PAN" ---
    # create an object to store info about Routine break2PAN
    break2PAN = data.Routine(
        name='break2PAN',
        components=[SentirESbreak, next2PANbreak],
    )
    break2PAN.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset next2PANbreak to account for continued clicks & clear times on/off
    next2PANbreak.reset()
    # store start times for break2PAN
    break2PAN.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    break2PAN.tStart = globalClock.getTime(format='float')
    break2PAN.status = STARTED
    thisExp.addData('break2PAN.started', break2PAN.tStart)
    break2PAN.maxDuration = None
    # keep track of which components have finished
    break2PANComponents = break2PAN.components
    for thisComponent in break2PAN.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "break2PAN" ---
    break2PAN.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *SentirESbreak* updates
        
        # if SentirESbreak is starting this frame...
        if SentirESbreak.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            SentirESbreak.frameNStart = frameN  # exact frame index
            SentirESbreak.tStart = t  # local t and not account for scr refresh
            SentirESbreak.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(SentirESbreak, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'SentirESbreak.started')
            # update status
            SentirESbreak.status = STARTED
            SentirESbreak.setAutoDraw(True)
        
        # if SentirESbreak is active this frame...
        if SentirESbreak.status == STARTED:
            # update params
            pass
        # *next2PANbreak* updates
        
        # if next2PANbreak is starting this frame...
        if next2PANbreak.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            next2PANbreak.frameNStart = frameN  # exact frame index
            next2PANbreak.tStart = t  # local t and not account for scr refresh
            next2PANbreak.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next2PANbreak, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'next2PANbreak.started')
            # update status
            next2PANbreak.status = STARTED
            win.callOnFlip(next2PANbreak.buttonClock.reset)
            next2PANbreak.setAutoDraw(True)
        
        # if next2PANbreak is active this frame...
        if next2PANbreak.status == STARTED:
            # update params
            pass
            # check whether next2PANbreak has been pressed
            if next2PANbreak.isClicked:
                if not next2PANbreak.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    next2PANbreak.timesOn.append(next2PANbreak.buttonClock.getTime())
                    next2PANbreak.timesOff.append(next2PANbreak.buttonClock.getTime())
                elif len(next2PANbreak.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    next2PANbreak.timesOff[-1] = next2PANbreak.buttonClock.getTime()
                if not next2PANbreak.wasClicked:
                    # end routine when next2PANbreak is clicked
                    continueRoutine = False
                if not next2PANbreak.wasClicked:
                    # run callback code when next2PANbreak is clicked
                    pass
        # take note of whether next2PANbreak was clicked, so that next frame we know if clicks are new
        next2PANbreak.wasClicked = next2PANbreak.isClicked and next2PANbreak.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break2PAN.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in break2PAN.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "break2PAN" ---
    for thisComponent in break2PAN.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for break2PAN
    break2PAN.tStop = globalClock.getTime(format='float')
    break2PAN.tStopRefresh = tThisFlipGlobal
    thisExp.addData('break2PAN.stopped', break2PAN.tStop)
    thisExp.addData('next2PANbreak.numClicks', next2PANbreak.numClicks)
    if next2PANbreak.numClicks:
       thisExp.addData('next2PANbreak.timesOn', next2PANbreak.timesOn)
       thisExp.addData('next2PANbreak.timesOff', next2PANbreak.timesOff)
    else:
       thisExp.addData('next2PANbreak.timesOn', "")
       thisExp.addData('next2PANbreak.timesOff', "")
    thisExp.nextEntry()
    # the Routine "break2PAN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirES2SPAN78 = data.TrialHandler2(
        name='SentirES2SPAN78',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimSPAN/Stimuli2PAN78.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirES2SPAN78)  # add the loop to the experiment
    thisSentirES2SPAN78 = SentirES2SPAN78.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN78.rgb)
    if thisSentirES2SPAN78 != None:
        for paramName in thisSentirES2SPAN78:
            globals()[paramName] = thisSentirES2SPAN78[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirES2SPAN78 in SentirES2SPAN78:
        currentLoop = SentirES2SPAN78
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN78.rgb)
        if thisSentirES2SPAN78 != None:
            for paramName in thisSentirES2SPAN78:
                globals()[paramName] = thisSentirES2SPAN78[paramName]
        
        # --- Prepare to start Routine "SentirES_psychopy" ---
        # create an object to store info about Routine SentirES_psychopy
        SentirES_psychopy = data.Routine(
            name='SentirES_psychopy',
            components=[pregunta, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionsslider, next2PANstim, nose2PAN],
        )
        SentirES_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionsslider.reset()
        # reset next2PANstim to account for continued clicks & clear times on/off
        next2PANstim.reset()
        # reset nose2PAN to account for continued clicks & clear times on/off
        nose2PAN.reset()
        # store start times for SentirES_psychopy
        SentirES_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirES_psychopy.tStart = globalClock.getTime(format='float')
        SentirES_psychopy.status = STARTED
        thisExp.addData('SentirES_psychopy.started', SentirES_psychopy.tStart)
        SentirES_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirES_psychopyComponents = SentirES_psychopy.components
        for thisComponent in SentirES_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirES_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirES2SPAN78, data.TrialHandler2) and thisSentirES2SPAN78.thisN != SentirES2SPAN78.thisTrial.thisN:
            continueRoutine = False
        SentirES_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pregunta* updates
            
            # if pregunta is starting this frame...
            if pregunta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pregunta.frameNStart = frameN  # exact frame index
                pregunta.tStart = t  # local t and not account for scr refresh
                pregunta.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pregunta, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pregunta.started')
                # update status
                pregunta.status = STARTED
                pregunta.setAutoDraw(True)
            
            # if pregunta is active this frame...
            if pregunta.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionsslider* updates
            
            # if interoceptionsslider is starting this frame...
            if interoceptionsslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionsslider.frameNStart = frameN  # exact frame index
                interoceptionsslider.tStart = t  # local t and not account for scr refresh
                interoceptionsslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionsslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionsslider.started')
                # update status
                interoceptionsslider.status = STARTED
                interoceptionsslider.setAutoDraw(True)
            
            # if interoceptionsslider is active this frame...
            if interoceptionsslider.status == STARTED:
                # update params
                pass
            # *next2PANstim* updates
            
            # if next2PANstim is starting this frame...
            if next2PANstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next2PANstim.frameNStart = frameN  # exact frame index
                next2PANstim.tStart = t  # local t and not account for scr refresh
                next2PANstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next2PANstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next2PANstim.started')
                # update status
                next2PANstim.status = STARTED
                win.callOnFlip(next2PANstim.buttonClock.reset)
                next2PANstim.setAutoDraw(True)
            
            # if next2PANstim is active this frame...
            if next2PANstim.status == STARTED:
                # update params
                pass
                # check whether next2PANstim has been pressed
                if next2PANstim.isClicked:
                    if not next2PANstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next2PANstim.timesOn.append(next2PANstim.buttonClock.getTime())
                        next2PANstim.timesOff.append(next2PANstim.buttonClock.getTime())
                    elif len(next2PANstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next2PANstim.timesOff[-1] = next2PANstim.buttonClock.getTime()
                    if not next2PANstim.wasClicked:
                        # end routine when next2PANstim is clicked
                        continueRoutine = False
                    if not next2PANstim.wasClicked:
                        # run callback code when next2PANstim is clicked
                        pass
            # take note of whether next2PANstim was clicked, so that next frame we know if clicks are new
            next2PANstim.wasClicked = next2PANstim.isClicked and next2PANstim.status == STARTED
            # *nose2PAN* updates
            
            # if nose2PAN is starting this frame...
            if nose2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                nose2PAN.frameNStart = frameN  # exact frame index
                nose2PAN.tStart = t  # local t and not account for scr refresh
                nose2PAN.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(nose2PAN, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'nose2PAN.started')
                # update status
                nose2PAN.status = STARTED
                win.callOnFlip(nose2PAN.buttonClock.reset)
                nose2PAN.setAutoDraw(True)
            
            # if nose2PAN is active this frame...
            if nose2PAN.status == STARTED:
                # update params
                pass
                # check whether nose2PAN has been pressed
                if nose2PAN.isClicked:
                    if not nose2PAN.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        nose2PAN.timesOn.append(nose2PAN.buttonClock.getTime())
                        nose2PAN.timesOff.append(nose2PAN.buttonClock.getTime())
                    elif len(nose2PAN.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        nose2PAN.timesOff[-1] = nose2PAN.buttonClock.getTime()
                    if not nose2PAN.wasClicked:
                        # end routine when nose2PAN is clicked
                        continueRoutine = False
                    if not nose2PAN.wasClicked:
                        # run callback code when nose2PAN is clicked
                        pass
            # take note of whether nose2PAN was clicked, so that next frame we know if clicks are new
            nose2PAN.wasClicked = nose2PAN.isClicked and nose2PAN.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirES_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirES_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirES_psychopy" ---
        for thisComponent in SentirES_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirES_psychopy
        SentirES_psychopy.tStop = globalClock.getTime(format='float')
        SentirES_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirES_psychopy.stopped', SentirES_psychopy.tStop)
        SentirES2SPAN78.addData('auditionslider.response', auditionslider.getRating())
        SentirES2SPAN78.addData('auditionslider.rt', auditionslider.getRT())
        SentirES2SPAN78.addData('tasteslider.response', tasteslider.getRating())
        SentirES2SPAN78.addData('tasteslider.rt', tasteslider.getRT())
        SentirES2SPAN78.addData('hapticslider.response', hapticslider.getRating())
        SentirES2SPAN78.addData('hapticslider.rt', hapticslider.getRT())
        SentirES2SPAN78.addData('olfactionslider.response', olfactionslider.getRating())
        SentirES2SPAN78.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirES2SPAN78.addData('visionslider.response', visionslider.getRating())
        SentirES2SPAN78.addData('visionslider.rt', visionslider.getRT())
        SentirES2SPAN78.addData('interoceptionsslider.response', interoceptionsslider.getRating())
        SentirES2SPAN78.addData('interoceptionsslider.rt', interoceptionsslider.getRT())
        SentirES2SPAN78.addData('next2PANstim.numClicks', next2PANstim.numClicks)
        if next2PANstim.numClicks:
           SentirES2SPAN78.addData('next2PANstim.timesOn', next2PANstim.timesOn)
           SentirES2SPAN78.addData('next2PANstim.timesOff', next2PANstim.timesOff)
        else:
           SentirES2SPAN78.addData('next2PANstim.timesOn', "")
           SentirES2SPAN78.addData('next2PANstim.timesOff', "")
        SentirES2SPAN78.addData('nose2PAN.numClicks', nose2PAN.numClicks)
        if nose2PAN.numClicks:
           SentirES2SPAN78.addData('nose2PAN.timesOn', nose2PAN.timesOn)
           SentirES2SPAN78.addData('nose2PAN.timesOff', nose2PAN.timesOff)
        else:
           SentirES2SPAN78.addData('nose2PAN.timesOn', "")
           SentirES2SPAN78.addData('nose2PAN.timesOff', "")
        # the Routine "SentirES_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirES2SPAN78'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "catch2PAN3" ---
    # create an object to store info about Routine catch2PAN3
    catch2PAN3 = data.Routine(
        name='catch2PAN3',
        components=[catch2PANfruta, bocadillo, coliflor, manzana],
    )
    catch2PAN3.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset bocadillo to account for continued clicks & clear times on/off
    bocadillo.reset()
    # reset coliflor to account for continued clicks & clear times on/off
    coliflor.reset()
    # reset manzana to account for continued clicks & clear times on/off
    manzana.reset()
    # store start times for catch2PAN3
    catch2PAN3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    catch2PAN3.tStart = globalClock.getTime(format='float')
    catch2PAN3.status = STARTED
    thisExp.addData('catch2PAN3.started', catch2PAN3.tStart)
    catch2PAN3.maxDuration = None
    # keep track of which components have finished
    catch2PAN3Components = catch2PAN3.components
    for thisComponent in catch2PAN3.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "catch2PAN3" ---
    catch2PAN3.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *catch2PANfruta* updates
        
        # if catch2PANfruta is starting this frame...
        if catch2PANfruta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            catch2PANfruta.frameNStart = frameN  # exact frame index
            catch2PANfruta.tStart = t  # local t and not account for scr refresh
            catch2PANfruta.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(catch2PANfruta, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'catch2PANfruta.started')
            # update status
            catch2PANfruta.status = STARTED
            catch2PANfruta.setAutoDraw(True)
        
        # if catch2PANfruta is active this frame...
        if catch2PANfruta.status == STARTED:
            # update params
            pass
        # *bocadillo* updates
        
        # if bocadillo is starting this frame...
        if bocadillo.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            bocadillo.frameNStart = frameN  # exact frame index
            bocadillo.tStart = t  # local t and not account for scr refresh
            bocadillo.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(bocadillo, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'bocadillo.started')
            # update status
            bocadillo.status = STARTED
            win.callOnFlip(bocadillo.buttonClock.reset)
            bocadillo.setAutoDraw(True)
        
        # if bocadillo is active this frame...
        if bocadillo.status == STARTED:
            # update params
            pass
            # check whether bocadillo has been pressed
            if bocadillo.isClicked:
                if not bocadillo.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    bocadillo.timesOn.append(bocadillo.buttonClock.getTime())
                    bocadillo.timesOff.append(bocadillo.buttonClock.getTime())
                elif len(bocadillo.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    bocadillo.timesOff[-1] = bocadillo.buttonClock.getTime()
                if not bocadillo.wasClicked:
                    # end routine when bocadillo is clicked
                    continueRoutine = False
                if not bocadillo.wasClicked:
                    # run callback code when bocadillo is clicked
                    pass
        # take note of whether bocadillo was clicked, so that next frame we know if clicks are new
        bocadillo.wasClicked = bocadillo.isClicked and bocadillo.status == STARTED
        # *coliflor* updates
        
        # if coliflor is starting this frame...
        if coliflor.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            coliflor.frameNStart = frameN  # exact frame index
            coliflor.tStart = t  # local t and not account for scr refresh
            coliflor.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(coliflor, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'coliflor.started')
            # update status
            coliflor.status = STARTED
            win.callOnFlip(coliflor.buttonClock.reset)
            coliflor.setAutoDraw(True)
        
        # if coliflor is active this frame...
        if coliflor.status == STARTED:
            # update params
            pass
            # check whether coliflor has been pressed
            if coliflor.isClicked:
                if not coliflor.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    coliflor.timesOn.append(coliflor.buttonClock.getTime())
                    coliflor.timesOff.append(coliflor.buttonClock.getTime())
                elif len(coliflor.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    coliflor.timesOff[-1] = coliflor.buttonClock.getTime()
                if not coliflor.wasClicked:
                    # end routine when coliflor is clicked
                    continueRoutine = False
                if not coliflor.wasClicked:
                    # run callback code when coliflor is clicked
                    pass
        # take note of whether coliflor was clicked, so that next frame we know if clicks are new
        coliflor.wasClicked = coliflor.isClicked and coliflor.status == STARTED
        # *manzana* updates
        
        # if manzana is starting this frame...
        if manzana.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            manzana.frameNStart = frameN  # exact frame index
            manzana.tStart = t  # local t and not account for scr refresh
            manzana.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(manzana, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'manzana.started')
            # update status
            manzana.status = STARTED
            win.callOnFlip(manzana.buttonClock.reset)
            manzana.setAutoDraw(True)
        
        # if manzana is active this frame...
        if manzana.status == STARTED:
            # update params
            pass
            # check whether manzana has been pressed
            if manzana.isClicked:
                if not manzana.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    manzana.timesOn.append(manzana.buttonClock.getTime())
                    manzana.timesOff.append(manzana.buttonClock.getTime())
                elif len(manzana.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    manzana.timesOff[-1] = manzana.buttonClock.getTime()
                if not manzana.wasClicked:
                    # end routine when manzana is clicked
                    continueRoutine = False
                if not manzana.wasClicked:
                    # run callback code when manzana is clicked
                    pass
        # take note of whether manzana was clicked, so that next frame we know if clicks are new
        manzana.wasClicked = manzana.isClicked and manzana.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            catch2PAN3.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in catch2PAN3.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "catch2PAN3" ---
    for thisComponent in catch2PAN3.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for catch2PAN3
    catch2PAN3.tStop = globalClock.getTime(format='float')
    catch2PAN3.tStopRefresh = tThisFlipGlobal
    thisExp.addData('catch2PAN3.stopped', catch2PAN3.tStop)
    thisExp.addData('bocadillo.numClicks', bocadillo.numClicks)
    if bocadillo.numClicks:
       thisExp.addData('bocadillo.timesOn', bocadillo.timesOn)
       thisExp.addData('bocadillo.timesOff', bocadillo.timesOff)
    else:
       thisExp.addData('bocadillo.timesOn', "")
       thisExp.addData('bocadillo.timesOff', "")
    thisExp.addData('coliflor.numClicks', coliflor.numClicks)
    if coliflor.numClicks:
       thisExp.addData('coliflor.timesOn', coliflor.timesOn)
       thisExp.addData('coliflor.timesOff', coliflor.timesOff)
    else:
       thisExp.addData('coliflor.timesOn', "")
       thisExp.addData('coliflor.timesOff', "")
    thisExp.addData('manzana.numClicks', manzana.numClicks)
    if manzana.numClicks:
       thisExp.addData('manzana.timesOn', manzana.timesOn)
       thisExp.addData('manzana.timesOff', manzana.timesOff)
    else:
       thisExp.addData('manzana.timesOn', "")
       thisExp.addData('manzana.timesOff', "")
    thisExp.nextEntry()
    # the Routine "catch2PAN3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    SentirES2SPAN80 = data.TrialHandler2(
        name='SentirES2SPAN80',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('stimSPAN/Stimuli2PAN80.csv'), 
        seed=None, 
    )
    thisExp.addLoop(SentirES2SPAN80)  # add the loop to the experiment
    thisSentirES2SPAN80 = SentirES2SPAN80.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN80.rgb)
    if thisSentirES2SPAN80 != None:
        for paramName in thisSentirES2SPAN80:
            globals()[paramName] = thisSentirES2SPAN80[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisSentirES2SPAN80 in SentirES2SPAN80:
        currentLoop = SentirES2SPAN80
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisSentirES2SPAN80.rgb)
        if thisSentirES2SPAN80 != None:
            for paramName in thisSentirES2SPAN80:
                globals()[paramName] = thisSentirES2SPAN80[paramName]
        
        # --- Prepare to start Routine "SentirES_psychopy" ---
        # create an object to store info about Routine SentirES_psychopy
        SentirES_psychopy = data.Routine(
            name='SentirES_psychopy',
            components=[pregunta, stimuli, audition, taste, haptic, olfaction, vision, interoception, auditionslider, tasteslider, hapticslider, olfactionslider, visionslider, interoceptionsslider, next2PANstim, nose2PAN],
        )
        SentirES_psychopy.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        stimuli.setText(Word)
        auditionslider.reset()
        tasteslider.reset()
        hapticslider.reset()
        olfactionslider.reset()
        visionslider.reset()
        interoceptionsslider.reset()
        # reset next2PANstim to account for continued clicks & clear times on/off
        next2PANstim.reset()
        # reset nose2PAN to account for continued clicks & clear times on/off
        nose2PAN.reset()
        # store start times for SentirES_psychopy
        SentirES_psychopy.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        SentirES_psychopy.tStart = globalClock.getTime(format='float')
        SentirES_psychopy.status = STARTED
        thisExp.addData('SentirES_psychopy.started', SentirES_psychopy.tStart)
        SentirES_psychopy.maxDuration = None
        # keep track of which components have finished
        SentirES_psychopyComponents = SentirES_psychopy.components
        for thisComponent in SentirES_psychopy.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "SentirES_psychopy" ---
        # if trial has changed, end Routine now
        if isinstance(SentirES2SPAN80, data.TrialHandler2) and thisSentirES2SPAN80.thisN != SentirES2SPAN80.thisTrial.thisN:
            continueRoutine = False
        SentirES_psychopy.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pregunta* updates
            
            # if pregunta is starting this frame...
            if pregunta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pregunta.frameNStart = frameN  # exact frame index
                pregunta.tStart = t  # local t and not account for scr refresh
                pregunta.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pregunta, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pregunta.started')
                # update status
                pregunta.status = STARTED
                pregunta.setAutoDraw(True)
            
            # if pregunta is active this frame...
            if pregunta.status == STARTED:
                # update params
                pass
            
            # *stimuli* updates
            
            # if stimuli is starting this frame...
            if stimuli.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimuli.frameNStart = frameN  # exact frame index
                stimuli.tStart = t  # local t and not account for scr refresh
                stimuli.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimuli, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimuli.started')
                # update status
                stimuli.status = STARTED
                stimuli.setAutoDraw(True)
            
            # if stimuli is active this frame...
            if stimuli.status == STARTED:
                # update params
                pass
            
            # *audition* updates
            
            # if audition is starting this frame...
            if audition.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                audition.frameNStart = frameN  # exact frame index
                audition.tStart = t  # local t and not account for scr refresh
                audition.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(audition, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'audition.started')
                # update status
                audition.status = STARTED
                audition.setAutoDraw(True)
            
            # if audition is active this frame...
            if audition.status == STARTED:
                # update params
                pass
            
            # *taste* updates
            
            # if taste is starting this frame...
            if taste.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                taste.frameNStart = frameN  # exact frame index
                taste.tStart = t  # local t and not account for scr refresh
                taste.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(taste, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'taste.started')
                # update status
                taste.status = STARTED
                taste.setAutoDraw(True)
            
            # if taste is active this frame...
            if taste.status == STARTED:
                # update params
                pass
            
            # *haptic* updates
            
            # if haptic is starting this frame...
            if haptic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                haptic.frameNStart = frameN  # exact frame index
                haptic.tStart = t  # local t and not account for scr refresh
                haptic.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(haptic, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'haptic.started')
                # update status
                haptic.status = STARTED
                haptic.setAutoDraw(True)
            
            # if haptic is active this frame...
            if haptic.status == STARTED:
                # update params
                pass
            
            # *olfaction* updates
            
            # if olfaction is starting this frame...
            if olfaction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfaction.frameNStart = frameN  # exact frame index
                olfaction.tStart = t  # local t and not account for scr refresh
                olfaction.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfaction, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfaction.started')
                # update status
                olfaction.status = STARTED
                olfaction.setAutoDraw(True)
            
            # if olfaction is active this frame...
            if olfaction.status == STARTED:
                # update params
                pass
            
            # *vision* updates
            
            # if vision is starting this frame...
            if vision.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                vision.frameNStart = frameN  # exact frame index
                vision.tStart = t  # local t and not account for scr refresh
                vision.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(vision, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'vision.started')
                # update status
                vision.status = STARTED
                vision.setAutoDraw(True)
            
            # if vision is active this frame...
            if vision.status == STARTED:
                # update params
                pass
            
            # *interoception* updates
            
            # if interoception is starting this frame...
            if interoception.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoception.frameNStart = frameN  # exact frame index
                interoception.tStart = t  # local t and not account for scr refresh
                interoception.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoception, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoception.started')
                # update status
                interoception.status = STARTED
                interoception.setAutoDraw(True)
            
            # if interoception is active this frame...
            if interoception.status == STARTED:
                # update params
                pass
            
            # *auditionslider* updates
            
            # if auditionslider is starting this frame...
            if auditionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                auditionslider.frameNStart = frameN  # exact frame index
                auditionslider.tStart = t  # local t and not account for scr refresh
                auditionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(auditionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'auditionslider.started')
                # update status
                auditionslider.status = STARTED
                auditionslider.setAutoDraw(True)
            
            # if auditionslider is active this frame...
            if auditionslider.status == STARTED:
                # update params
                pass
            
            # *tasteslider* updates
            
            # if tasteslider is starting this frame...
            if tasteslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                tasteslider.frameNStart = frameN  # exact frame index
                tasteslider.tStart = t  # local t and not account for scr refresh
                tasteslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(tasteslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'tasteslider.started')
                # update status
                tasteslider.status = STARTED
                tasteslider.setAutoDraw(True)
            
            # if tasteslider is active this frame...
            if tasteslider.status == STARTED:
                # update params
                pass
            
            # *hapticslider* updates
            
            # if hapticslider is starting this frame...
            if hapticslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                hapticslider.frameNStart = frameN  # exact frame index
                hapticslider.tStart = t  # local t and not account for scr refresh
                hapticslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(hapticslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'hapticslider.started')
                # update status
                hapticslider.status = STARTED
                hapticslider.setAutoDraw(True)
            
            # if hapticslider is active this frame...
            if hapticslider.status == STARTED:
                # update params
                pass
            
            # *olfactionslider* updates
            
            # if olfactionslider is starting this frame...
            if olfactionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                olfactionslider.frameNStart = frameN  # exact frame index
                olfactionslider.tStart = t  # local t and not account for scr refresh
                olfactionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(olfactionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'olfactionslider.started')
                # update status
                olfactionslider.status = STARTED
                olfactionslider.setAutoDraw(True)
            
            # if olfactionslider is active this frame...
            if olfactionslider.status == STARTED:
                # update params
                pass
            
            # *visionslider* updates
            
            # if visionslider is starting this frame...
            if visionslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                visionslider.frameNStart = frameN  # exact frame index
                visionslider.tStart = t  # local t and not account for scr refresh
                visionslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(visionslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'visionslider.started')
                # update status
                visionslider.status = STARTED
                visionslider.setAutoDraw(True)
            
            # if visionslider is active this frame...
            if visionslider.status == STARTED:
                # update params
                pass
            
            # *interoceptionsslider* updates
            
            # if interoceptionsslider is starting this frame...
            if interoceptionsslider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                interoceptionsslider.frameNStart = frameN  # exact frame index
                interoceptionsslider.tStart = t  # local t and not account for scr refresh
                interoceptionsslider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(interoceptionsslider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'interoceptionsslider.started')
                # update status
                interoceptionsslider.status = STARTED
                interoceptionsslider.setAutoDraw(True)
            
            # if interoceptionsslider is active this frame...
            if interoceptionsslider.status == STARTED:
                # update params
                pass
            # *next2PANstim* updates
            
            # if next2PANstim is starting this frame...
            if next2PANstim.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                next2PANstim.frameNStart = frameN  # exact frame index
                next2PANstim.tStart = t  # local t and not account for scr refresh
                next2PANstim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(next2PANstim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'next2PANstim.started')
                # update status
                next2PANstim.status = STARTED
                win.callOnFlip(next2PANstim.buttonClock.reset)
                next2PANstim.setAutoDraw(True)
            
            # if next2PANstim is active this frame...
            if next2PANstim.status == STARTED:
                # update params
                pass
                # check whether next2PANstim has been pressed
                if next2PANstim.isClicked:
                    if not next2PANstim.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        next2PANstim.timesOn.append(next2PANstim.buttonClock.getTime())
                        next2PANstim.timesOff.append(next2PANstim.buttonClock.getTime())
                    elif len(next2PANstim.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        next2PANstim.timesOff[-1] = next2PANstim.buttonClock.getTime()
                    if not next2PANstim.wasClicked:
                        # end routine when next2PANstim is clicked
                        continueRoutine = False
                    if not next2PANstim.wasClicked:
                        # run callback code when next2PANstim is clicked
                        pass
            # take note of whether next2PANstim was clicked, so that next frame we know if clicks are new
            next2PANstim.wasClicked = next2PANstim.isClicked and next2PANstim.status == STARTED
            # *nose2PAN* updates
            
            # if nose2PAN is starting this frame...
            if nose2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                nose2PAN.frameNStart = frameN  # exact frame index
                nose2PAN.tStart = t  # local t and not account for scr refresh
                nose2PAN.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(nose2PAN, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'nose2PAN.started')
                # update status
                nose2PAN.status = STARTED
                win.callOnFlip(nose2PAN.buttonClock.reset)
                nose2PAN.setAutoDraw(True)
            
            # if nose2PAN is active this frame...
            if nose2PAN.status == STARTED:
                # update params
                pass
                # check whether nose2PAN has been pressed
                if nose2PAN.isClicked:
                    if not nose2PAN.wasClicked:
                        # if this is a new click, store time of first click and clicked until
                        nose2PAN.timesOn.append(nose2PAN.buttonClock.getTime())
                        nose2PAN.timesOff.append(nose2PAN.buttonClock.getTime())
                    elif len(nose2PAN.timesOff):
                        # if click is continuing from last frame, update time of clicked until
                        nose2PAN.timesOff[-1] = nose2PAN.buttonClock.getTime()
                    if not nose2PAN.wasClicked:
                        # end routine when nose2PAN is clicked
                        continueRoutine = False
                    if not nose2PAN.wasClicked:
                        # run callback code when nose2PAN is clicked
                        pass
            # take note of whether nose2PAN was clicked, so that next frame we know if clicks are new
            nose2PAN.wasClicked = nose2PAN.isClicked and nose2PAN.status == STARTED
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                SentirES_psychopy.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SentirES_psychopy.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "SentirES_psychopy" ---
        for thisComponent in SentirES_psychopy.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for SentirES_psychopy
        SentirES_psychopy.tStop = globalClock.getTime(format='float')
        SentirES_psychopy.tStopRefresh = tThisFlipGlobal
        thisExp.addData('SentirES_psychopy.stopped', SentirES_psychopy.tStop)
        SentirES2SPAN80.addData('auditionslider.response', auditionslider.getRating())
        SentirES2SPAN80.addData('auditionslider.rt', auditionslider.getRT())
        SentirES2SPAN80.addData('tasteslider.response', tasteslider.getRating())
        SentirES2SPAN80.addData('tasteslider.rt', tasteslider.getRT())
        SentirES2SPAN80.addData('hapticslider.response', hapticslider.getRating())
        SentirES2SPAN80.addData('hapticslider.rt', hapticslider.getRT())
        SentirES2SPAN80.addData('olfactionslider.response', olfactionslider.getRating())
        SentirES2SPAN80.addData('olfactionslider.rt', olfactionslider.getRT())
        SentirES2SPAN80.addData('visionslider.response', visionslider.getRating())
        SentirES2SPAN80.addData('visionslider.rt', visionslider.getRT())
        SentirES2SPAN80.addData('interoceptionsslider.response', interoceptionsslider.getRating())
        SentirES2SPAN80.addData('interoceptionsslider.rt', interoceptionsslider.getRT())
        SentirES2SPAN80.addData('next2PANstim.numClicks', next2PANstim.numClicks)
        if next2PANstim.numClicks:
           SentirES2SPAN80.addData('next2PANstim.timesOn', next2PANstim.timesOn)
           SentirES2SPAN80.addData('next2PANstim.timesOff', next2PANstim.timesOff)
        else:
           SentirES2SPAN80.addData('next2PANstim.timesOn', "")
           SentirES2SPAN80.addData('next2PANstim.timesOff', "")
        SentirES2SPAN80.addData('nose2PAN.numClicks', nose2PAN.numClicks)
        if nose2PAN.numClicks:
           SentirES2SPAN80.addData('nose2PAN.timesOn', nose2PAN.timesOn)
           SentirES2SPAN80.addData('nose2PAN.timesOff', nose2PAN.timesOff)
        else:
           SentirES2SPAN80.addData('nose2PAN.timesOn', "")
           SentirES2SPAN80.addData('nose2PAN.timesOff', "")
        # the Routine "SentirES_psychopy" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'SentirES2SPAN80'
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "fin" ---
    # create an object to store info about Routine fin
    fin = data.Routine(
        name='fin',
        components=[fin_y, fin2PAN],
    )
    fin.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # reset fin2PAN to account for continued clicks & clear times on/off
    fin2PAN.reset()
    # store start times for fin
    fin.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    fin.tStart = globalClock.getTime(format='float')
    fin.status = STARTED
    thisExp.addData('fin.started', fin.tStart)
    fin.maxDuration = None
    # keep track of which components have finished
    finComponents = fin.components
    for thisComponent in fin.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fin" ---
    fin.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *fin_y* updates
        
        # if fin_y is starting this frame...
        if fin_y.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            fin_y.frameNStart = frameN  # exact frame index
            fin_y.tStart = t  # local t and not account for scr refresh
            fin_y.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fin_y, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fin_y.started')
            # update status
            fin_y.status = STARTED
            fin_y.setAutoDraw(True)
        
        # if fin_y is active this frame...
        if fin_y.status == STARTED:
            # update params
            pass
        # *fin2PAN* updates
        
        # if fin2PAN is starting this frame...
        if fin2PAN.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            fin2PAN.frameNStart = frameN  # exact frame index
            fin2PAN.tStart = t  # local t and not account for scr refresh
            fin2PAN.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fin2PAN, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fin2PAN.started')
            # update status
            fin2PAN.status = STARTED
            win.callOnFlip(fin2PAN.buttonClock.reset)
            fin2PAN.setAutoDraw(True)
        
        # if fin2PAN is active this frame...
        if fin2PAN.status == STARTED:
            # update params
            pass
            # check whether fin2PAN has been pressed
            if fin2PAN.isClicked:
                if not fin2PAN.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    fin2PAN.timesOn.append(fin2PAN.buttonClock.getTime())
                    fin2PAN.timesOff.append(fin2PAN.buttonClock.getTime())
                elif len(fin2PAN.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    fin2PAN.timesOff[-1] = fin2PAN.buttonClock.getTime()
                if not fin2PAN.wasClicked:
                    # end routine when fin2PAN is clicked
                    continueRoutine = False
                if not fin2PAN.wasClicked:
                    # run callback code when fin2PAN is clicked
                    pass
        # take note of whether fin2PAN was clicked, so that next frame we know if clicks are new
        fin2PAN.wasClicked = fin2PAN.isClicked and fin2PAN.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            fin.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fin.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fin" ---
    for thisComponent in fin.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for fin
    fin.tStop = globalClock.getTime(format='float')
    fin.tStopRefresh = tThisFlipGlobal
    thisExp.addData('fin.stopped', fin.tStop)
    thisExp.addData('fin2PAN.numClicks', fin2PAN.numClicks)
    if fin2PAN.numClicks:
       thisExp.addData('fin2PAN.timesOn', fin2PAN.timesOn)
       thisExp.addData('fin2PAN.timesOff', fin2PAN.timesOff)
    else:
       thisExp.addData('fin2PAN.timesOn', "")
       thisExp.addData('fin2PAN.timesOff', "")
    thisExp.nextEntry()
    # the Routine "fin" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
